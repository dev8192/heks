const presets = [
    {
        fileSize: 250,
        fileOffset: 50,
        bufferSize: 100,
        bufferOffset: 30,
        windowSize: 50,
    },
    {
        fileSize: 50,
        fileOffset: 0,
        bufferSize: 50,
        bufferOffset: 0,
        windowSize: 100,
    },
    {
        fileSize: 50,
        fileOffset: 20,
        bufferSize: 30,
        bufferOffset: 0,
        windowSize: 100,
    },
]

class App {
    constructor() {
        const preset = presets[0]
        this.offsetWidget = new VisualWindow({
            app: this,
            parentElem: document.body,
            selector: '.visual_window',
            fileSize: preset.fileSize,
            fileOffset: preset.fileOffset,
            bufferSize: preset.bufferSize,
            bufferOffset: preset.bufferOffset,
            windowSize: preset.windowSize,
        })
    }
    createBuffer() {
        const arr = new Uint8Array(this.bufSize)
        for (let i = 0; i < this.bufSize; i++) {
            arr[i] = i % 256
        }
        return arr.buffer
    }
}

const app = new App()
