class App {
    constructor() {
        this.settings = {
            offsetSize: 8,
            get(key) {
                return this[key]
            }
        }
        this.bufSize = 16 * 16 + 48
        this.buffer = this.createBuffer()
        this.currentOffset = 0
        // this.currentOffset = 64
        this.offsetWidget = new OffsetWidget({
            app: this,
            parentElem: this.container,
            getCurrentOffset: () => this.currentOffset,
            getBufSize: () => this.bufSize,
            getViewHeight: () => 16,
        })
        this.offsetWidget.addListener('startOffsetChange', this.onStartOffsetChange.bind(this))
    }
    onStartOffsetChange(offsetValue) {
        this.currentOffset = offsetValue
        console.log(offsetValue)
    }
    createBuffer() {
        const arr = new Uint8Array(this.bufSize)
        for (let i = 0; i < this.bufSize; i++) {
            arr[i] = i % 256
        }
        return arr.buffer
    }
}

const app = new App()
