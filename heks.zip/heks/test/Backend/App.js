class App {
    constructor() {
        this.label = 'heks'

        // this.backendType = 'localStorage'
        // this.backendType = 'fileSystemAccess'
        this.backendType = 'remoteBackend'

        if (this.backendType === 'localStorage') {
            this.backend = new LocalStorageBackend({
                label: this.label,
            })
        } else if (this.backendType === 'fileSystemAccess') {
            this.backend = new FileSystemAccessBackend()
        } else if (this.backendType === 'remoteBackend') {
            this.backend = new RemoteBackend()
        }
    }
    async doRunTest() {
        try {
            // await app.testClearFile()
            await app.testWriteFile()
            // await app.testReadFile()
            // await app.testCreateFile()
            // await app.testRemoveFile()
            // await app.testMoveFile()
            // await app.testListEntries()
            // await app.testUploadFiles()
            // await app.testDownloadFiles()
            // await app.testIsFolder()
            // await app.testCopyFile()
            // await app.testCreateFolder()
        } catch(err) {
            console.log(err)
            // console.log(err.message)
        }
        console.log('done')
    }
    runTest() {
        if (this.backend instanceof FileSystemAccessBackend) {
            const button = this.createButton()
            button.addEventListener('click', this.doRunTest.bind(this))
        } else {
            this.doRunTest()
        }
    }
    createButton(textContent = 'Click me') {
        const button = document.createElement('button')
        button.textContent = textContent
        document.body.appendChild(button)
        button.focus()
        return button
    }
    async testUploadFiles() {
        await this.backend.uploadFiles({
            data: fs1,
            // overwrite: true,
        })
    }
    async testDownloadFiles() {
        const data = await this.backend.downloadFiles({
            // path: 'path/to/folder',
            noData: true,
            showFolders: true,
        })
        console.log(data)
    }
    async testWriteFile() {
        const result = await this.backend.writeFile({
            path: 'hello2.txt',
            // path: 'path/to/file',
            data: 'Hello there',
            // data: "Minimal and efficient solution",
            // data: new Blob(['Hello there']),
            // data: new Blob(['Hello there'], {type: 'text/plain'}),
            // data: 'a'.repeat(6000000),
            // data: 'a'.repeat(5000000),
            // data: '\nhello again',
            // data: 'H',
            // data: Date(),
            // data: Math.floor(Math.random() * 10),
            // data: this.getBinaryData1(),
            // data: new DataView(this.getBinaryData3()),
            // appendMode: true,
            // createIfNotExists: true,
            // offset: 10,
            // keepExistingData: true,
        })

        console.log(result)
    }
    getBinaryData1() {
        const view = new Uint8Array([0, 1, 2, 3, 4])
        return view.buffer
    }
    getBinaryData2() {
        const buffer = new ArrayBuffer(5)
        const view = new Uint8Array(buffer)
        for (let i = 0; i < buffer.byteLength; i++) {
            view[i] = i
        }
        return view.buffer
    }
    getBinaryData3() {
        const str = 'Hello there'
        const encoder = new TextEncoder()
        const view = encoder.encode(str)
        return view.buffer
    }
    testClearFile() {
        this.backend.writeFile('hello.txt', '')
    }
    async testReadFile() {
        const spec = {
            // path: 'file_that_does_not_exist',
            path: 'hello1.txt',
            // path: 'example3.txt',
            // path: 'path/to/file/example2.txt',
            // path: 'folder1/file1',
            // offset: 8,
            // length: 13,
        }
        const data = await this.backend.readFile(spec)
        if (data) {
            if (spec.binary) {
                console.log(data)
            } else {
                const str = Array.from(data).map((byte) => String.fromCharCode(byte)).join('')
                console.log(str)
            }
        } else {
            console.log('File not found')
        }
    }
    async testCreateFolder() {
        const result = await this.backend.createFolder({
            // path: 'path',
            // path: 'path/to',
            path: 'path/to/file',
            recursive: true,
        })
        console.log(result)
    }
    async testCreateFile() {
        const handle = await this.backend.writeFile({
            // path: 'hello/example1.txt',
            // path: 'path/to/example',
            // path: 'path/to/example/one',
            path: 'example2.txt',
            createIfNotExists: true,
        })
        console.log(handle)
    }
    async testRemoveFile() {
        await this.backend.removeFile({
            // path: 'hello.txt',
            // path: 'example2.txt',
            // path: 'file_that_does_not_exist',
            // path: 'path/to/file',
            path: 'fff',
            recursive: true,
        })
    }
    async testParse() {

    }
    async testListEntries() {
        // const result = await this.backend.getEntries()
        const result = await this.backend.getEntryNames()
        console.log(result)
    }
    async testMoveFile() {
        // await this.backend.moveFile('example1.txt', 'example2.txt')

        /*
            Both dir1 and dir2 are existing folders
            Equivalent to: mv dir1 dir2/
            Result: dir1/dir2

            dir1 exists, dir2 doesn't
            Equivalent to: mv dir1 dir2
            Result: Rename dir1 to dir2
       */
       await this.backend.moveFile('dir1', 'dir2')

        // await this.backend.moveFile('example2.txt', 'path')
        // await this.backend.moveFile('example2.txt', 'path/example1.txt')
        // await this.backend.moveFile('path/example2.txt', 'example2.txt')

        // await this.backend.moveFile('hello444', 'hello333')
        // await this.backend.moveFile('hello333', 'hello444')

        // await this.backend.moveFile('path/hello333', 'path/to')
        // await this.backend.moveFile('path/to/hello333', 'path')
        // await this.backend.moveFile('hello.txt', 'hello1.txt')
    }
    testCopyFile() {
        const data = this.backend.readFile('hello.txt')
        this.backend.writeFile('hello2.txt', data)
    }
    testIsFolder() {
        // const result = this.backend.isFolder('path/to/file')
        const result = this.backend.isFolder('path/to')
        console.log(result)
    }
}

const app = new App()

const fs1 = [
    {
        name: 'example1.txt',
        data: 'one two three',
    },
    {
        name: 'example2.txt',
        data: 'abc 123',
    },
    {
        name: 'boom',
        children: [
            {
                name: 'boom_file',
                data: '',
            },
            {
                name: 'inner_boom',
                children: [],
            },
        ],
    },
    {
        name: 'empty.file',
        data: '',
    }
]

app.runTest()



