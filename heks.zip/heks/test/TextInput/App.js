class App {
    constructor() {
        this.textElem = new Text({
            parentElem: this.container,
            text: 'InputEvent.prototype.inputType',
        });
        [
            'insertText',
            'deleteContentBackward',
            'deleteContentForward',
            'deleteByCut',
            'insertFromPaste',
        ]
        this.textInput = new TextInput({
            parentElem: this.container,
        })
        this.textInput.addListener('numberInput', (num) => {
            this.textElem.setText(num)
        })
        // document.body.textContent = 'hello there'
    }
}