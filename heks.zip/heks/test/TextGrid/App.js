class App {
    constructor() {
        this.textElem = new TextGrid({
            parentElem: this.container,
            items: [
                'insertText',
                'deleteContentBackward',
                'deleteContentForward',
                'deleteByCut',
                'insertFromPaste',
            ],
        });
        this.textInput = new TextInput({
            parentElem: this.container,
        })
        this.textInput.addListener('input', (inputType) => {
            this.textElem.highlight(inputType)
        })
    }
}