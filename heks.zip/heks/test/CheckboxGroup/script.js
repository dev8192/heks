
const options = [
    {
        text: 'Option 1',
        checked: true,
    },
    {
        text: 'Option 2',
    },
    {
        text: 'Option 3',
    },
]

function test1() {
    const checkboxGroup = new CheckboxGroup()
}

function test1() {
    const checkboxGroup = new CheckboxGroup({
        options
    })
}

function test1() {
    const checkboxGroup = new CheckboxGroup({
        onMainCheckboxClick: function(checked) {
            if (checked) {
                console.log('checked')
            } else {
                console.log('unchecked')
            }
        }
    })
}

function test1() {
    function onClick(label, checked) {
        if (checked) {
            console.log(label, 'checked')
        } else {
            console.log(label, 'unchecked')
        }
    }
    for (const option of options) {
        option.onClick = function(checked) {
            onClick(option.text, checked)
        }
    }
    const checkboxGroup = new CheckboxGroup({
        options,        
        onMainCheckboxClick: function(checked) {
            onClick('Main', checked)
        }
    })
}

function test1() {
    const container = document.createElement('div')
    document.body.append(container)
    container.classList.add('checkbox_group')
    container.style.backgroundColor = 'thistle'
    
    const checkboxGroup = new CheckboxGroup({
        options,
        container,
    })
}

function test() {
    const parentElem = document.createElement('div')
    document.body.append(parentElem)
    parentElem.style.display = 'flex'
    parentElem.style.gap = '30px'
    
    const group1 = new CheckboxGroup({
        options,
        parentElem,
    })
    const group2 = new CheckboxGroup({
        options,
        parentElem,
    })
    const group3 = new CheckboxGroup({
        options,
        parentElem,
    })
}

test()
