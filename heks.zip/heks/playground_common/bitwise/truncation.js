
function test1() {
    const num = 0x1ffffffff // 8589934591
    console.log(num >> 0) // -1
    console.log(num << 0) // -1
}

/*
    0x00ffffffff
    0xffffffff00

    0xffffff00
    0x000000ff
    0x00000100
*/
function test1() {
    console.log(0xffffffff << 8) // -256
    console.log(0xffffffffn << 8n) // -256
}

/*
    0xfffff000
    0x00001000
*/
function test1() {
    console.log((0xfffff << 4).toString(16))
    console.log((0xfffff << 8).toString(16))
    console.log((0xfffff << 12).toString(16))
    console.log((0xfffff << 16).toString(16))
}

/*
    80000000
    40000000
    20000000
    10000000
     8000000
*/
function test1() {
    console.log((0x80000000 >> 1))
    console.log((0x80000000 >> 2))
    console.log((0x80000000 >> 3))
    console.log((0x80000000 >> 4))

    console.log((0x80000000 >>> 1))
    console.log((0x80000000 >>> 2))
    console.log((0x80000000 >>> 3))
    console.log((0x80000000 >>> 4))
}

/*
    01000000 00000000 00000000 00000000     1073741824

    positive --> negative: flip, then sub
    01000000 00000000 00000000 00000000
    10111111 11111111 11111111 11111111 + 1 =
    11000000 00000000 00000000 00000000

    negative --> positive: sub, then flip
    0b11000000_00000000_00000000_00000000

    11000000 00000000 00000000 00000000 - 1 =
    10111111 11111111 11111111 11111111
    01000000 00000000 00000000 00000000
*/
function test1() {
    console.log((0x80000000 >>> 1)) // 1073741824
    console.log((0x80000000 >> 1)) // -1073741824
}

function test() {
    console.log((~0) >>> 0)
    console.log((~0) >> 0)
}

function test1() {
    const big = 2 ** 40; // 1,099,511,627,776 (needs 40 bits)
    console.log("Original number:", big);

    // Show its binary form (full 64-bit float representation truncated to integer)
    console.log("Binary (full):", big.toString(2));

    // Apply a bitwise OR with 0 (forces conversion to 32-bit signed int)
    const truncated = big | 0;
    console.log("After bitwise OR with 0:", truncated);

    // Show binary of truncated result (only low 32 bits kept)
    console.log("Binary (truncated to 32 bits):", (truncated >>> 0).toString(2));
}

test();
