function test1() {
    setTimeout(() => {
        console.log(123)
    }, 3000)
}

function test2() {
    const promise = new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve(456)
        }, 3000)
    })
    promise.then((num) => {
        console.log(num)
    })
}

async function test() {
    const promise = new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve(789)
        }, 3000)
    })
    const num = await promise
    console.log(num)
}

test()
