function test1() {
    const map = new Map()
    map.set('January', 'Январь')
    map.set('February', 'Февраль')
    map.set('March', 'Март')
    
    for (const item of map) {
        console.log(item)
    }
    
    for (const item of map.entries()) {
        console.log(item)
    }
    
    for (const item of map.keys()) {
        console.log(item)
    }
    
    for (const item of map.values()) {
        console.log(item)
    }
    
    for (const [key, val] of map) {
        console.log(key, val)
    }
}

function test1() {
    const map = new Map()
    const key1 = ['path', 'to', 'file']
    map.set(key1, 'hello')
    console.log(map.get(key1))
    console.log(map.get(['path', 'to', 'file']))
}

function test() {
    const map = new Map()
    const key1 = ['path', 'to', 'file'].join('/')
    console.log(key1)
    map.set(key1, 'hello')
    console.log(map.get(key1))
    console.log(map.get(['path', 'to', 'file'].join('/')))
}

test()
