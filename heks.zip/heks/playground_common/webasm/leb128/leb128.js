/*
    0000 1001  1000 0111  0110 0101      624485
    09         87         65

    10100110  10001110  11100101
    a6 8e e5
*/
function encodeULEB128(val) {
    const bytes = [];
    do {
        let byte = val & 0x7F;
        val >>>= 7;
        if (val !== 0) {
            byte |= 0x80;
        }
        bytes.push(byte);
    } while (val !== 0);
    return Uint8Array.from(bytes);
}

// Decode ULEB128 back into an unsigned integer
function decodeULEB128(bytes) {
    let result = 0;
    let shift = 0;
    let count = 0;
    for (const byte of bytes) {
        result |= (byte & 0x7F) << shift;
        count++;
        if ((byte & 0x80) === 0) break;
        shift += 7;
    }
    return { value: result, length: count };
}

/*
          00000001  11100010  01000000
11111111  11111110  00011101  11000000
1000000
*/
function encodeSLEB128_1(value) {
    const bytes = [];
    let more = true;
    const isNegative = value < 0;

    while (more) {
        let byte = value & 0x7F;
        value >>= 7; // arithmetic shift keeps sign
        const signBit = (byte & 0x40) !== 0;

        if (
            (value === 0 && !signBit) ||
            (value === -1 && signBit)
        ) {
            more = false;
        } else {
            byte |= 0x80;
        }
        bytes.push(byte);
    }
    return Uint8Array.from(bytes);
}

function encodeSLEB128(value) {
    const bytes = [];

    while (true) {
        let byte = value & 0x7F;       // take lowest 7 bits
        value >>= 7;                   // arithmetic shift (preserves sign)
        const signBit = (byte & 0x40) !== 0;

        // termination condition: remaining value matches sign
        if ((value === 0 && !signBit) || (value === -1 && signBit)) {
            bytes.push(byte);
            break;
        } else {
            bytes.push(byte | 0x80);   // set continuation bit
        }
    }

    return Uint8Array.from(bytes);
}

function encodeSLEB128_wiki(value) {
    value = BigInt(value)
    const bytes = []

    const negative = value < 0n;
    const size = 64n; // bit-width of value; choose 64 for int64 semantics
    let more = true;

    while (more) {
        let byte = Number(value & 0x7Fn)
        value >>= 7n;

        if (negative) {
            value |= (~0n << (size - 7n)); // sign-extend the shifted remainder
        }

        // sign bit of the 7-bit chunk is bit 6 (0x40)
        const signBitSet = (byte & 0x40) !== 0;

        if ((value === 0n && !signBitSet) || (value === -1n && signBitSet)) {
            more = false; // this is the final byte
        } else {
            byte |= 0x80; // continuation bit
        }

        bytes.push(byte);
    }

    return Uint8Array.from(bytes);
}

// Decode SLEB128 back into a signed integer
function decodeSLEB128(bytes) {
    let result = 0;
    let shift = 0;
    let count = 0;
    let byte;
    for (byte of bytes) {
        result |= (byte & 0x7F) << shift;
        shift += 7;
        count++;
        if ((byte & 0x80) === 0) break;
    }
    // Sign extend if needed
    if (shift < 32 && (byte & 0x40)) {
        result |= (~0 << shift);
    }
    return { value: result, length: count };
}

function test1() {
    const uValue = 624485;
    const uEncoded = encodeULEB128(uValue);
    const uDecoded = decodeULEB128(uEncoded);
    console.log("Unsigned:", uValue, "->", [...uEncoded], "->", uDecoded.value);
    
    const sValue = -123456;
    const sEncoded = encodeSLEB128(sValue);
    const sDecoded = decodeSLEB128(sEncoded);
    console.log("Signed:", sValue, "->", [...sEncoded], "->", sDecoded.value);
}

/*
    01111111 11111111 11111111 11111111
    0111 1111111 1111111 1111111 1111111
*/
function test1() {
    debugger
    const uEncoded = [0xff, 0xff, 0xff, 0xff, 0x07]
    const uDecoded = decodeULEB128(uEncoded)
    console.log(uDecoded)
    console.log(uDecoded.value.toString(16))
}

/*
    -2147483648
*/
function test() {
    debugger
    const uEncoded = [0x80, 0x80, 0x80, 0x80, 0x78]
    const uDecoded = decodeSLEB128(uEncoded)
    console.log(uDecoded)
    console.log(uDecoded.value.toString(16))
}

test()
