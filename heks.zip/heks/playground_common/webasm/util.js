

atob('str').split('').map(c => '0x' + c.charCodeAt(0).toString(16).padStart(2, 0)).join(', ').split('0x6e, 0x61, 0x6d, 0x65')[0].slice(0, -19)


[bytes].map(b => String.fromCharCode(b)).join('')


