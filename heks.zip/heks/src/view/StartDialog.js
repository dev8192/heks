class StartDialog extends View {
    constructor(opts) {
        opts.viewId = 'start_dialog'
        super(opts)

        const openFileButton = this.container.querySelector('.open_file')
        openFileButton.addEventListener('click', this.openFile.bind(this))

        const openFolderButton = this.container.querySelector('.open_folder')
        openFolderButton.addEventListener('click', this.openFolder.bind(this))

        const newFileButton = this.container.querySelector('.new_file')
        newFileButton.addEventListener('click', this.onNewFileButtonClick.bind(this))

        const settingsButton = this.container.querySelector('.settings')
        settingsButton.addEventListener('click', this.openSettings.bind(this))

        const explorerButton = this.container.querySelector('.file_explorer')
        explorerButton.addEventListener('click', this.openExplorer.bind(this))
    }
    openExplorer() {
        this.app.fileExplorer.show()
    }
    updateButtonVisibility() {
        
    }
    async openFile() {
        await this.app.openFile()
    }
    openFolder() {

    }
    onNewFileButtonClick() {
        this.app.newFileDialog.show()
        this.app.newFileDialog.fromBuffer = true
    }
    openSettings() {
        this.app.settingsView.show()
    }
}
