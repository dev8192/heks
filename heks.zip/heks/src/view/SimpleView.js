class SimpleView extends View {
    constructor(opts) {
        super(opts)

        if (opts.selector) {
            this.contentElem = this.container.querySelector('.content')
            this.controlsElem = this.container.querySelector('.controls')
            this.okButton = this.container.querySelector('.ok')
            this.cancelButton = this.container.querySelector('.cancel')
        } else {
            this.build()
        }

        this.okButton.addEventListener('click', this.onOkButtonClick.bind(this))
        this.cancelButton.addEventListener('click', this.onCancelButtonClick.bind(this))
    }
    build() {
        this.contentElem = document.createElement('div')
        this.contentElem.classList.add('content')
        this.container.append(this.contentElem)

        this.controlsElem = document.createElement('div')
        this.controlsElem.classList.add('controls')
        this.container.append(this.controlsElem)

        this.okButton = document.createElement('button')
        this.okButton.textContent = 'Ok'
        this.okButton.classList.add('ok')
        this.controlsElem.append(this.okButton)

        this.cancelButton = document.createElement('button')
        this.cancelButton.textContent = 'Cancel'
        this.cancelButton.classList.add('cancel')
        this.controlsElem.append(this.cancelButton)
    }
    onOkButtonClick() {
        this.showPrev()
    }
    onCancelButtonClick() {
        this.showPrev()
    }
}

class DialogWithCountdown extends SimpleView {
    constructor(opts) {
        super(opts)
        if (opts.timeout) {
            this.timeout = opts.timeout
        } else {
            this.timeout = 5
        }
        this.intervalId = null
        this.showPrevAfterTimeout = this.showPrevAfterTimeout.bind(this)
    }
    show() {
        this.contentElem.textContent = 'Press OK to start countdown'
        super.show()
    }
    showPrevAfterTimeout() {
        const str = `Returning back to previous view in ${this.timeout} seconds...`
        this.contentElem.textContent = str
        this.timeout--
        if (this.timeout >= 0) {
            return
        }
        clearInterval(this.intervalId)
        this.showPrev()
    }
    onOkButtonClick() {
        this.showPrevAfterTimeout()
        this.intervalId = setInterval(this.showPrevAfterTimeout, 1000)
    }
}
