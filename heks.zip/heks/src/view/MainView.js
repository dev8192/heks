class MainView extends View {
    static settingContributions = [
        {
            id: 'showAddCellButton',
            yesText: 'Show "Add Cell" Button',
            noText: 'Hide "Add Cell" Button',
            type: 'toggle_input',
            defaultValue: false,
            order: 500,
            globalOpt: true,
        },
        {
            id: 'upperCase',
            yesText: 'Hex upper case',
            noText: 'Hex lower case',
            type: 'toggle_input',
            defaultValue: false,
            order: 500,
        },
        {
            id: 'maxRows',
            type: 'number_input',
            defaultValue: 16,
            order: 500,
            globalOpt: true,
        },
        {
            id: 'showCols',
            yesText: 'Show columns',
            noText: 'Hide columns',
            type: 'toggle_input',
            defaultValue: true,
            order: 500,
            globalOpt: true,
        },
        {
            id: 'showRows',
            yesText: 'Show rows',
            noText: 'Hide rows',
            type: 'toggle_input',
            defaultValue: true,
            order: 500,
            globalOpt: true,
        },
        {
            id: 'bgColor',
            title: 'Background color',
            type: 'color_input',
            defaultValue: 'aqua',
            order: 100,
            validate: AppSettings.isValidColor,
        },
        {
            id: 'selColor',
            title: 'Selection color',
            type: 'color_input',
            defaultValue: 'orange',
            order: 200,
            validate: AppSettings.isValidColor,
        },
        {
            id: 'defaultOffset',
            title: 'Default offset',
            type: 'number_input',
            defaultValue: 0,
            order: 50,
        },
        {
            id: 'offsetSize',
            title: 'Offset size',
            type: 'number_input',
            defaultValue: 8,
            order: 50,
        },
        {
            id: 'kbdMode',
            title: 'Keyboard mode',
            type: 'text_input',
            defaultValue: 'arrows',
            globalOpt: true,
            order: 50,
        },
        {
            id: 'navPreset',
            title: 'Navigation preset',
            type: 'text_input',
            defaultValue: 'arrows',
            globalOpt: true,
            order: 50,
        },
        {
            id: 'maxOpenEditors',
            title: 'Max open editors',
            type: 'number_input',
            defaultValue: 15,
            order: 300,
            validate(num) {
                if (Number.isNaN(num)) {
                    console.log('NaN is not allowed')
                    return false
                }
                if (num > 10) {
                    console.log('Cannot open more than 10 editors')
                    return false
                }
                return true
            }
        },
    ]
    constructor(opts) {
        opts.viewId = 'main_view'
        super(opts)

        this.settings = opts.settings
        this.settings.contribute(this.constructor.settingContributions)

        this.controlsElem = this.container.querySelector('.menu')

        this.fileExplorerButton = this.controlsElem.querySelector('.file_explorer')
        this.fileExplorerButton.addEventListener('click', this.onFileExplorerButtonClick.bind(this))

        this.newFileButton = this.controlsElem.querySelector('.new_file')
        this.newFileButton.addEventListener('click', this.onNewFileButtonClick.bind(this))

        this.openFileButton = this.controlsElem.querySelector('.open_file')
        this.openFileButton.addEventListener('click', this.openFile.bind(this))

        this.saveButton = this.controlsElem.querySelector('.save_file')
        this.saveButton.addEventListener('click', this.saveFile.bind(this))

        this.saveAllButton = this.controlsElem.querySelector('.save_all')
        this.saveAllButton.addEventListener('click', this.onSaveAllButtonClick.bind(this))

        this.closeAllButton = this.controlsElem.querySelector('.close_all')
        this.closeAllButton.addEventListener('click', this.onCloseAllButtonClick.bind(this))

        this.settingsButton = this.container.querySelector('.settings')
        this.settingsButton.addEventListener('click', this.openSettings.bind(this))

        this.focusEditorView = this.focusEditorView.bind(this)
        this.onBitsWidgetValueChange = this.onBitsWidgetValueChange.bind(this)

        this.tabsWidget = new TabsWidget({
            parentElem: this.container,
            app: this.app,
        })
        this.tabsWidget.addListener('tabClosed', this.onTabClosed.bind(this))
        this.tabsWidget.addListener('tabOpened', this.onTabOpened.bind(this))

        this.offsetWidget = new OffsetWidget({
            app: this.app,
            parentElem: this.container,
            getBufferOffset: () => {
                return this.app.currentEditor.buffer.bufferOffset
            },
            getBufSize: () => {
                return this.app.currentEditor.buffer.bufSize
            },
            getViewHeight: () => {
                return this.settings.get('maxRows')
            },
            tabsWidget: this.tabsWidget,
        })
        this.onStartOffsetChange = this.onStartOffsetChange.bind(this) 
        this.offsetWidget.addListener('bufferOffsetChange', this.onStartOffsetChange)

        this.kbdMgr = new KeyboardManager({
            container: this.tabsWidget.tabContentElem,
        })
        
        // this.kbdMgr.addHandler('KeyS', this.saveFile.bind(this))
        this.kbdMgr.addHandler('Escape', this.clearSelection.bind(this))

        this.bufSizeWidget = new BufSizeWidget({
            app: this.app,
            parentElem: this.container.querySelector('.runtime_controls'),
        })
        this.bufSizeWidget.hide()

        this.app.addListener('optionsProcessed', this.init.bind(this))
    }
    init() {
        this.editorView = new EditorView({
            parentElem: this.tabsWidget.tabContentElem,
            app: this.app,
            settings: this.settings,
        })
        this.app.styleMgr.addListener('cellSelected',
            this.onCellSelected.bind(this))
        this.app.styleMgr.addListener('selectionCleared',
            this.onSelectionCleared.bind(this))
        this.initKbd()
        this.detailsPane = new DetailsPane({
            app: this.app,
            parentElem: this.container,
            selector: '.details_pane',
        })
        this.detailsPane.addListener('numberFormatChanged', this.focusEditorView)
        this.bitsWidget = new BitsWidget({
            app: this.app,
            parentElem: this.container,
            selector: '.bits_widget',
        })
        this.bitsWidget.addListener('valueChanged', this.onBitsWidgetValueChange)
    }
    onBitsWidgetValueChange(event) {
        this.app.currentEditor.buffer.setUint8({
            index: this.app.currentEditor.currentCellIdx,
            value: event.value,
            origin: event.origin,
        })
        this.focusEditorView()
    }
    initKbd() {
        this.mvMgr = new MovementManager({
            app: this.app,
            posMgr: this.editorView.posMgr,
            kbdMgr: this.kbdMgr,
            printMessage: this.printMessage,
        })
        this.mvMgr.addListener('bufferOffsetChange', this.onStartOffsetChange)
        this.kbdInputModes = new ButtonGroup({
            parentElem: this.container,
            selector: '.keyboard_input_modes',
            onClick: this.changeKbdMode.bind(this),
        })
        this.navPresetsToggle = new ButtonGroup({
            parentElem: this.container,
            selector: '.nav_presets',
            onClick: this.changeNavPreset.bind(this),
            items: MovementManager.kbdPresets,
        })
        this.cellEditor = new CellEditor({
            app: this.app,
            kbdMgr: this.kbdMgr,
            editorView: this.editorView,
            printMessage: this.printMessage,
        })
        this.cellEditor.disable()
        this.mvMgr.enable()
    }
    changeKbdMode(kbdInputMode) {
        if (kbdInputMode === 'edit') {
            this.navPresetsToggle.disableAll()
            this.mvMgr.disable()
            this.cellEditor.enable()
        } else {
            this.navPresetsToggle.enableAll()
            this.cellEditor.disable()
            this.mvMgr.enable()
        }
        this.focusEditorView()
    }
    focusEditorView() {
        if (this.app.currentEditor === undefined) {
            return
        }
        if (this.app.currentEditor.currentCellIdx === null) {
            return
        }
        this.tabsWidget.tabContentElem.focus()
    }
    changeNavPreset(presetName) {
        this.settings.set('navPreset', presetName)
        this.mvMgr.setHandlers(presetName)
        this.focusEditorView()
    }
    
    onStartOffsetChange(changeObj) {
        this.app.currentEditor.buffer.bufferOffset = changeObj.offset
        this.app.currentEditor.populate()
        if (changeObj.origin === this.mvMgr) {
            this.offsetWidget.update()
        }
    }
    markAllEditorsAsDirty() {
        for (const editor of this.app.openEditors) {
            editor.dirty = true
        } 
    }
    show(tabElem) {
        // console.log('MainView.show')
        if (tabElem) {
            this.tabsWidget.switchToTab(tabElem)
        }
        const success = super.show()
        if (success) {
            this.updateButtonVisibility()
        }
        for (const editor of this.app.openEditors) {
            if (editor.dirty) {
                editor.build()
                editor.populate()
                editor.dirty = false
            }
        }
    }
    updateButtonVisibility() {
        if (this.app.openEditors.length < this.settings.get('maxOpenEditors')) {
            this.newFileButton.disabled = false
            this.openFileButton.disabled = false
        } else {
            this.newFileButton.disabled = true
            this.openFileButton.disabled = true
        }
        if (this.app.openEditors.every((editor) => !editor.isModified)) {
            this.saveButton.disabled = false
            this.saveAllButton.disabled = false
        } else {
            this.saveButton.disabled = true
            this.saveAllButton.disabled = true
        }
        if (this.app.openEditors.length > 0) {
            this.closeAllButton.disabled = false
        } else {
            this.closeAllButton.disabled = true
        }
    }
    onFileExplorerButtonClick() {
        this.app.fileExplorer.show()
    }
    onNewFileButtonClick() {
        this.app.newFileDialog.show()
    }
    async openFile() {
        await this.app.openFile()
    }
    saveFile() {
        // if (!this.app.currentEditor) {
        //     this.printMessage('No open editors')
        //     return
        // }
        // if (!this.app.currentEditor.isModified) {
        //     this.printMessage('Nothing to save in the current editor')
        //     return
        // }
        this.app.saveFileDialog.show()
    }
    onSaveAllButtonClick() {
        console.log('Not implemented')
    }
    onCloseAllButtonClick() {
        console.log('Not implemented')
    }
    openSettings() {
        this.app.settingsView.show()
    }
    getEditor(tab) {
        for (const editor of this.app.openEditors) {
            if (editor.tab === tab) {
                return editor
            }
        }
    }
    removeEditor(obj) {
        const arr = []
        for (const editor of this.app.openEditors) {
            if (editor !== obj) {
                arr.push(editor)
            }
        }
        this.app.openEditors = arr
    }
    clearSelection(event) {
        this.editorView.selectionMgr.clearSelection()
        event.stopPropagation()
    }
    onTabClosed(tab) {
        if (this.app.currentEditor.currentCellIdx !== null) {
            const posMgr = this.app.mainView.editorView.posMgr
            const elem = posMgr.getElem(this.app.currentEditor.currentCellIdx)
            this.app.styleMgr.clearSelection(elem)
        }
    }
    onTabOpened(tab) {
        for (const editor of this.app.openEditors) {
            if (editor.tab === tab) {
                // this.tabsWidget.tabContentElem.innerHTML = ''
                // this.tabsWidget.tabContentElem.append(editor.container)
                this.app.currentEditor = editor
                // editor.build()
                editor.populate()
                editor.dirty = false
                break
            }
        }
    }
    moveSelectionUp() {
        
    }
    moveSelectionDown() {
        
    }
    moveSelectionLeft() {
        
    }
    moveSelectionRight() {
        
    }
    onCellSelected() {
        this.detailsPane.show()
        this.bitsWidget.show()
    }
    onSelectionCleared() {
        this.detailsPane.hide()
        this.bitsWidget.hide()
    }
}