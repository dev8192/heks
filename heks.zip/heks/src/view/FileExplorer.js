class FileExplorer extends View {
    constructor(opts) {
        opts.viewId = 'file_explorer'
        super(opts)

        this.workspaceInfo = new WorkspaceInfo({
            app: this.app,
            parentElem: this.container,
            selector: '.workspace_info',
        })

        this.workspaceControls = this.container.querySelector(':scope > .menu.workspace_controls')

        this.renameWorkspaceButton = this.workspaceControls.querySelector('.rename_workspace')
        this.renameWorkspaceButton.addEventListener('click', this.onRenameWorkspaceButtonClick.bind(this))

        this.cloneWorkspaceButton = this.workspaceControls.querySelector('.clone_workspace')
        this.cloneWorkspaceButton.addEventListener('click', this.onCloneWorkspaceButtonClick.bind(this))

        this.removeWorkspaceButton = this.workspaceControls.querySelector('.remove_workspace')
        this.removeWorkspaceButton.addEventListener('click', this.onRemoveWorkspaceButtonClick.bind(this))

        this.closeWorkspaceButton = this.workspaceControls.querySelector('.close_workspace')
        this.closeWorkspaceButton.addEventListener('click', this.onCloseWorkspaceButtonClick.bind(this))

        this.workspaceDialog = new WorkspaceDialog({
            app: this.app,
            parentElem: this.container,
            selector: '.workspace_dialog',
            replacePlaceholder: true,
        })

        // this.pathToObjectMap = new Map()
        // this.populatePathToObjectMap(this.data, '<root>')
        
        // this.useNestedTreeView = true
        if (this.useNestedTreeView) {
            this.treeView = new TreeViewNested({
                app: this.app,
                parentElem: this.container,
                selector: '.tree_view',
            })
        } else {
            this.treeView = new TreeViewFlat({
                app: this.app,
                parentElem: this.container,
                selector: '.tree_view',
            })
        }
        this.treeView.addListener('itemSelected', this.onItemSelected.bind(this))
        this.treeView.addListener('selectionCleared', this.onSelectionCleared.bind(this))
        this.treeView.addListener('renameStarted', this.onRenameStarted.bind(this))
        this.treeView.addListener('renameFinished', this.onRenameFinished.bind(this))
        this.treeView.addListener('nameInput', this.onNameInput.bind(this))
        this.treeView.addListener('itemCreated', this.onItemCreated.bind(this))
        this.treeView.addListener('actionCanceled', this.onActionCanceled.bind(this))
        this.treeView.addListener('itemDeleted', this.onItemDeleted.bind(this))

        this.breadcrumbsWidget = new BreadcrumbsWidget({
            parentElem: this.container,
            selector: '.breadcrumbs',
            app: this.app,
        })
        this.breadcrumbsWidget.addListener('itemSelectionChanged',
                this.onItemSelectionChanged.bind(this))

        this.fileControls = this.container.querySelector(':scope > .menu.file_controls')

        this.renameButton = this.fileControls.querySelector('.rename')
        this.onRenameButtonClick = this.onRenameButtonClick.bind(this)
        this.renameButton.addEventListener('click', this.onRenameButtonClick)

        this.removeButton = this.fileControls.querySelector('.remove')
        this.onRemoveButtonClick = this.onRemoveButtonClick.bind(this)
        this.removeButton.addEventListener('click', this.onRemoveButtonClick)

        this.moveToButton = this.fileControls.querySelector('.move_to')
        this.onMoveToButtonClick = this.onMoveToButtonClick.bind(this)
        this.moveToButton.addEventListener('click', this.onMoveToButtonClick)

        this.newFileButton = this.fileControls.querySelector('.new_file')
        this.onNewFileButtonClick = this.onNewFileButtonClick.bind(this)
        this.newFileButton.addEventListener('click', this.onNewFileButtonClick)

        this.newFolderButton = this.fileControls.querySelector('.new_folder')
        this.onNewFolderButtonClick = this.onNewFolderButtonClick.bind(this)
        this.newFolderButton.addEventListener('click', this.onNewFolderButtonClick)

        this.collapseChildrenButton = this.fileControls.querySelector('.collapse_children')
        this.onCollapseChildren = this.onCollapseChildren.bind(this)
        this.collapseChildrenButton.addEventListener('click', this.onCollapseChildren)

        this.expandRecursivelyButton = this.fileControls.querySelector('.expand_recursively')
        this.onExpandRecursively = this.onExpandRecursively.bind(this)
        this.expandRecursivelyButton.addEventListener('click', this.onExpandRecursively)

        this.openFileButton = this.fileControls.querySelector('.open_file')
        this.openFileButton.addEventListener('click', this.onOpenFileButtonClick.bind(this))
    }
    onRenameWorkspaceButtonClick() {

    }
    onCloneWorkspaceButtonClick() {

    }
    onRemoveWorkspaceButtonClick() {

    }
    onCloseWorkspaceButtonClick() {
        this.app.workspaceMgr.currentWorkspace = null
        this.app.workspaceView.show()
    }
    async show() {
        const workspace = this.app.workspaceMgr.currentWorkspace
        if (!workspace) {
            return
        }
        if (workspace.backend === 'LocalStorage') {

        } else if (workspace.backend === 'FileSystemAccess') {

        } else {
            throw new Error('Backend is not supported')
        }
        this.treeView.container.focus()
        this.data = await workspace.getEntries()
        this.treeView.populateRows(this.data)
        this.workspaceInfo.populate(workspace)
        super.show()
        this.emit('ready')
    }
    populatePathToObjectMap(obj, path) {
        this.pathToObjectMap.set(path, obj)
        if (obj.children) {
            for (const childObj of obj.children) {
                const newPath = path + '/' + childObj.name
                this.populatePathToObjectMap(childObj, newPath)
            }
        }
    }
    onExpandRecursively() {
        this.treeView.expandRecursively()
    }
    onCollapseChildren() {
        this.treeView.collapseChildren()
    }
    onRenameStarted() {
        this.renameButton.disabled = true
        this.treeView.pauseEvents()
        this.breadcrumbsWidget.pauseEvents()
    }
    findFile(obj, segments, index) {
        if (segments.length === index) {
            return obj
        }
        for (const childObj of obj.children) {
            if (segments[index] === childObj.name) {
                return this.findFile(childObj, segments, index + 1)
            }
        }
    }
    async onRenameFinished(event) {
        event.from = event.from.split('/').slice(1).join('/')
        event.to = event.to.split('/').slice(1).join('/')
        const pathSegments = event.to.split('/')
        const newName = pathSegments[pathSegments.length - 1]
        const backend = this.app.workspaceMgr.currentWorkspace
        backend.moveFile(event.from, event.to)
        this.breadcrumbsWidget.renameLastSegment(newName)
        this.renameButton.disabled = false
        this.treeView.resumeEvents()
        this.breadcrumbsWidget.resumeEvents()
    }
    onActionCanceled(event) {
        this.breadcrumbsWidget.renameLastSegment(event.value)
        this.renameButton.disabled = false
        this.treeView.resumeEvents()
        this.breadcrumbsWidget.resumeEvents()
    }
    onNameInput(value) {
        this.breadcrumbsWidget.renameLastSegment(value)
    }
    onItemSelectionChanged(path) {
        this.treeView.selectItem(path)
    }
    canRenameItem(event) {
        return event.path !== '<root>'
    }
    canRemoveItem(event) {
        return event.path !== '<root>'
    }
    canMoveItem(event) {
        return event.path !== '<root>'
    }
    async canCollapseAndExpand(event) {
        // console.log('canCollapseAndExpand', event)
        if (!event.isDir) {
            return false
        }
        if (event.temp) {
            return false
        }
        const backend = this.app.workspaceMgr.currentWorkspace
        return await backend.getChildCount(event.path) > 0
    }
    pathToDataInternal(obj, pathSegments, index, data = []) {
        data.push({
            segment: obj.name,
            type: obj.children ? 'dir_item' : 'file_item',
        })
        if (!obj.children) {
            return
        }
        for (const childObj of obj.children) {
            if (childObj.name === pathSegments[index]) {
                this.pathToDataInternal(childObj, pathSegments, index + 1, data)
                return
            }
        }
    }
    pathToData(path) {
        const pathSegments = path.split('/')
        const dataArray = []
        this.pathToDataInternal(this.data, pathSegments, 1, dataArray)
        dataArray[0].segment = '<root>'
        return dataArray
    }
    async onItemSelected(event) {
        // const data = this.pathToData(event.path)
        this.breadcrumbsWidget.show(event)
        this.renameButton.disabled = !this.canRenameItem(event)
        this.removeButton.disabled = !this.canRemoveItem(event)
        this.moveToButton.disabled = !this.canMoveItem(event)
        
        if (await this.canCollapseAndExpand(event)) {
            this.expandRecursivelyButton.disabled = false
            this.collapseChildrenButton.disabled = false
        } else {
            this.expandRecursivelyButton.disabled = true
            this.collapseChildrenButton.disabled = true
        }

        this.newFileButton.disabled = !event.isDir
        this.newFolderButton.disabled = !event.isDir
    }
    onSelectionCleared() {
        this.breadcrumbsWidget.hide()
        this.renameButton.disabled = true
        this.removeButton.disabled = true
        this.moveToButton.disabled = true
        this.newFileButton.disabled = true
        this.newFolderButton.disabled = true
    }
    onOpenFileButtonClick() {
        this.app.newFileDialog.show()
    }
    onRenameButtonClick() {
        this.treeView.startItemRenaming()
    }
    onRemoveButtonClick() {
        this.treeView.removeItem()
    }
    onMoveToButtonClick() {
        
    }
    onNewFileButtonClick() {
        this.treeView.startItemCreating('file_item')
    }
    onNewFolderButtonClick() {
        this.treeView.startItemCreating('dir_item')
    }
    async onItemCreated(event) {
        event.path = event.path.split('/').slice(1).join('/')
        const backend = this.app.workspaceMgr.currentWorkspace
        if (event.isDir) {
            await backend.createFolder({
                path: event.path,
            })
        } else {
            await backend.writeFile({
                path: event.path,
                createIfNotExists: true,
            })
        }
    }
    async onItemDeleted(event) {
        event.path = event.path.split('/').slice(1).join('/')
        const backend = this.app.workspaceMgr.currentWorkspace
        await backend.removeFile({
            path: event.path,
            // recursive: true,
        })
    }
}
