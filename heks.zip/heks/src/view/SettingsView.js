class SettingsView extends View {
    static ctors = {
        text_input: SettingsTextInput,
        number_input: NumberInput,
        checkbox_input: CheckboxInput,
        toggle_input: ToggleInput,
        color_input: ColorInput,
    }
    constructor(opts) {
        opts.viewId = 'settings_view'
        super(opts)
        this.settings = opts.settings
        this.printMessage = opts.printMessage

        this.items = this.container.querySelector('.items')

        const okButton = this.container.querySelector('.ok')
        okButton.addEventListener('click', this.onOkButtonClick.bind(this))

        const cancelButton = this.container.querySelector('.cancel')
        cancelButton.addEventListener('click', this.closeDialog.bind(this))

        const resetButton = this.container.querySelector('.reset')
        resetButton.addEventListener('click', this.resetSettings.bind(this))

        this.settingItems = []
        this.settingElem = null
        const ctorOpts = {
            settingsView: this,
            settingObj: null,
            app: this.app,
            parentElem: this.items,
            // colorPicker: new ColorPicker({
            //     selector: '.color_picker',
            //     app: this.app,
            // }),
        }
        // const widget = document.querySelector('.color_picker')
        // widget.remove()

        this.settings.iterateSettings((settingObj) => {
            const ctor = SettingsView.ctors[settingObj.type]
            if (ctor) {
                ctorOpts.settingObj = settingObj
                const inputObj = new ctor(ctorOpts)
                this.settingItems.push({
                    inputObj,
                    settingObj,
                })
            } else {
                this.printMessage(`Cannot find ${settingObj.type}`)
            }
        })
    }
    show() {
        super.show()
        for (const item of this.settingItems) {
            if (item.inputObj.value === null) {
                item.inputObj.setValue(item.settingObj.value)
            }
            item.inputObj.prepare()
        }
    }
    onOkButtonClick() {
        let dirty
        for (const item of this.settingItems) {
            const value = item.inputObj.getValue()
            if (item.settingObj.value === value) {
                continue
            }
            dirty = true
            if (item.settingObj.validate) {
                if (!item.settingObj.validate(value)) {
                    continue
                }
            }
            this.app.settings.set(item.settingObj.id, value)
        }
        if (dirty) {
            this.app.settings.writeSettings()
            this.app.mainView.markAllEditorsAsDirty()
        }
        this.closeDialog()
    }
    resetSettings() {
        for (const item of this.settingItems) {
            item.inputObj.setValue(item.settingObj.defaultValue)
            item.inputObj.prepare()
        }
    }
    closeDialog() {
        for (const item of this.settingItems) {
            item.inputObj.setValue(null)
        }
        if (this.app.openEditors.length > 0) {
            this.app.mainView.show()
        } else {
            this.app.startDialog.show()
        }
    }
}
