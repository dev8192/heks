class View extends Widget {
    constructor(opts) {
        super(opts)
        if (!opts.viewId) {
            throw new Error('View ID must be specified')
        }
        this.title = opts.title
        this.viewId = opts.viewId
        this.app.views[this.viewId] = this
    }
    show() {
        if (this === this.app.currentView) {
            return false
        }
        this.container.classList.remove('hidden')
        if (this.app.currentView) {
            this.app.currentView.hide()
        }
        this.app.previousView = this.app.currentView
        this.app.currentView = this

        this.showTitle()

        return true
    }
    showTitle() {
        if (this.title) {
            document.title = `${this.app.title} - ${this.title}`
        } else {
            document.title = this.app.title
        }
    }
    showPrev() {
        if (!this.app.previousView) {
            console.log('No previous view')
            return
        }
        this.app.currentView.hide()
        this.app.previousView.container.classList.remove('hidden')
        this.app.currentView = this.app.previousView
        this.app.previousView = null
    }
}
