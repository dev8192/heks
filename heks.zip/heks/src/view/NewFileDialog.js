
class NewFileDialog extends View {
    constructor(opts) {
        opts.viewId = 'new_file_dialog'
        super(opts)

        this.fileNameInput = this.container.querySelector('.file_name')
        this.fileSizeDiv = this.container.querySelector('.file_size')
        this.bufSizeInput = this.container.querySelector('.buffer_size')
        this.startOffsetInput = this.container.querySelector('.start_offset')

        const okButton = this.container.querySelector('.ok')
        okButton.addEventListener('click', this.onOkButtonClick.bind(this))

        const cancelButton = this.container.querySelector('.cancel')
        cancelButton.addEventListener('click', this.onCancelButtonClick.bind(this))
    }
    show() {
        super.show()
        if (this.app.fileInfo) {
            this.fileNameInput.value = this.app.fileInfo.getFileName()
            this.fileSizeDiv.value = this.app.fileInfo.getFileSize()
            this.bufSizeInput.value = this.app.fileInfo.getFileSize()
            this.startOffsetInput.value = this.app.fileInfo.getOffset()
        } else {
            this.fileNameInput.value = this.app.settings.get('defaultFileName')
            this.fileSizeDiv.value = this.app.settings.get('defaultBufSize')
            this.bufSizeInput.value = this.app.settings.get('defaultBufSize')
            this.startOffsetInput.value = this.app.settings.get('defaultOffset')
        }
    }
    isBufSizeValid(bufSize) {
        if (Number.isNaN(bufSize)) {
            console.log('Not a number')
            return false
        }
        if (bufSize < 0) {
            console.log('Buffer size cannot be negative')
            return false
        }
        const maxBufSize = this.app.settings.get('maxBufSize')
        if (bufSize > maxBufSize) {
            console.log('Buffer cannot be larger than ', maxBufSize)
            return false
        }
        return true
    }
    isStartOffsetValid(startOffset, bufSize) {
        if (startOffset % 16 !== 0) {
            console.log('Start offset must be divisible by 16')
            return false
        }
        if (startOffset > bufSize) {
            console.log('Invalid start offset')
            return false
        }
        return true
    }
    async onOkButtonClick() {
        const spec = {}
        spec.fileName = this.fileNameInput.value
        if (!AppSettings.isFileNameValid(fileName)) {
            return
        }
        spec.bufSize = Number(this.bufSizeInput.value)
        if (!this.isBufSizeValid(bufSize)) {
            return
        }
        spec.startOffset = Number(this.startOffsetInput.value)
        if (!this.isStartOffsetValid(startOffset, bufSize)) {
            return
        }
        if (this.app.fileInfo) {
            await this.app.createEditorFromFile(spec)
            this.app.fileInfo = null
        } else {
            await this.app.createEditorFromBuffer(spec)
        }
    }
    onCancelButtonClick() {
        this.app.fileInfo = null
        this.showPrev()
    }
}
