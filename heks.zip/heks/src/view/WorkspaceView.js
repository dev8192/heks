class WorkspaceView extends View {
    constructor(opts) {
        opts.viewId = 'workspace_view'
        opts.title = 'Workspaces'
        super(opts)

        this.editingMode = null

        this.workspacesTbl = new TableWidget({
            parentElem: this.container,
            selector: '.workspaces',
            items: opts.workspaces,
        })
        this.onRowSelected = this.onRowSelected.bind(this)
        this.workspacesTbl.onRowSelected = this.onRowSelected

        this.selectedObject = null

        this.newWorkspaceButton = this.container.querySelector('.new_workspace')
        this.newWorkspaceButton.addEventListener('click', this.onNewWorkspaceButtonClick.bind(this))

        this.openWorkspaceButton = this.container.querySelector('.open_workspace')
        this.openWorkspaceButton.disabled = true
        this.openWorkspaceButton.addEventListener('click', this.onOpenWorkspaceButtonClick.bind(this))

        this.renameWorkspaceButton = this.container.querySelector('.rename_workspace')
        this.renameWorkspaceButton.disabled = true
        this.renameWorkspaceButton.addEventListener('click', this.onRenameWorkspaceButtonClick.bind(this))

        this.removeWorkspaceButton = this.container.querySelector('.remove_workspace')
        this.removeWorkspaceButton.disabled = true
        this.removeWorkspaceButton.addEventListener('click', this.onRemoveWorkspaceButtonClick.bind(this))

        this.resetWorkspacesButton = this.container.querySelector('.reset_workspaces')
        this.resetWorkspacesButton.addEventListener('click', this.onResetWorkspacesButtonClick.bind(this))

        this.workspaceDialog = new WorkspaceDialog({
            app: this.app,
            parentElem: this.container,
            selector: '.workspace_dialog',
            replacePlaceholder: true,
        })
        this.workspaceDialog.addListener('ok', this.onWorkspaceDialogOk.bind(this))
        this.workspaceDialog.addListener('cancel', this.onWorkspaceDialogCancel.bind(this))
    }
    async show() {
        await this.app.workspaceMgr.startManager()
        super.show()
        this.showWorkspaces()
        this.selectedObject = null
        this.updateButtonVisibility()
    }
    async showWorkspaces() {
        // this.app.workspaceMgr.iterateWorkspaces()
        const workspaces = await this.app.workspaceMgr.getAllWorkspaces()
        const rows = []
        for (const item of workspaces) {
            rows.push({
                name: item.name,
                backend: item.backend,
                type: item.system ? 'system' : 'user',
            })
        }
        const data = {
            format: 2,
            headers: [
                {title: 'Name', key: 'name'},
                {title: 'Backend', key: 'backend'},
                {title: 'Type', key: 'type'},
            ],
            rows
        }
        this.workspacesTbl.show(data)
    }
    onRowSelected(obj) {
        if (this.selectedObject) {
            this.workspacesTbl.removeRowHighlight(this.selectedObject)
            if (this.selectedObject === obj) {
                this.selectedObject = null
            } else {
                this.workspacesTbl.addRowHighlight(obj)
                this.selectedObject = obj
            }
        } else {
            this.workspacesTbl.addRowHighlight(obj)
            this.selectedObject = obj
        }
        this.updateButtonVisibility()
    }
    updateButtonVisibility() {
        if (this.selectedObject) {
            this.newWorkspaceButton.disabled = true
            this.openWorkspaceButton.disabled = false
            if (this.selectedObject.type === 'system') {
                this.renameWorkspaceButton.disabled = true
                this.removeWorkspaceButton.disabled = true
            } else {
                this.renameWorkspaceButton.disabled = false
                this.removeWorkspaceButton.disabled = false
            }
        } else {
            this.newWorkspaceButton.disabled = false
            this.openWorkspaceButton.disabled = true
            this.renameWorkspaceButton.disabled = true
            this.removeWorkspaceButton.disabled = true
        }
    }
    onNewWorkspaceButtonClick() {
        this.editingMode = 'create_workspace'
        this.workspaceDialog.setName('New workspace')
        this.workspaceDialog.setWorkspaceType('LocalStorage')
        this.workspaceDialog.enableButtons()
        this.workspaceDialog.show()
        this.newWorkspaceButton.disabled = true
        this.workspacesTbl.onRowSelected = null
    }
    async onOpenWorkspaceButtonClick() {
        await this.app.workspaceMgr.openWorkspace(this.selectedObject)
    }
    async onRenameWorkspaceButtonClick() {
        this.editingMode = 'rename_workspace'
        this.workspaceDialog.setName(this.selectedObject.name)
        this.workspaceDialog.setWorkspaceType(this.selectedObject.backend)
        this.workspaceDialog.disableButtons()
        this.workspaceDialog.show()
        this.renameWorkspaceButton.disabled = true
        this.workspacesTbl.onRowSelected = null
    }
    async onRemoveWorkspaceButtonClick() {
        await this.app.workspaceMgr.removeWorkspace(this.selectedObject)
        this.selectedObject = null
        this.showWorkspaces()
        this.openWorkspaceButton.disabled = true
        this.renameWorkspaceButton.disabled = true
        this.removeWorkspaceButton.disabled = true
    }
    async onResetWorkspacesButtonClick() {
        await this.app.workspaceMgr.resetWorkspaces()
        this.showWorkspaces()
    }
    async onWorkspaceDialogOk(event) {
        if (this.editingMode === 'create_workspace') {
            if (event.type === 'LocalStorage') {
                await this.app.workspaceMgr.createLocalStorageWorkspace(event.name)
            } else if (event.type === 'IndexedDB') {
                await this.app.workspaceMgr.createIndexedDBWorkspace(event.name)
            } else if (event.type === 'FileSystem') {
                await this.app.workspaceMgr.createFileSystemWorkspace(event.name)
            } else {
                throw new Error('Unknown workspace type')
            }
        } else if (this.editingMode === 'rename_workspace') {
            const oldName = this.selectedObject.name
            const newName = event.name
            await this.app.workspaceMgr.renameWorkspace(oldName, newName)
        } else {
            throw new Error('Unknown editing mode')
        }
        this.editingMode = null
        this.newWorkspaceButton.disabled = false
        this.workspacesTbl.onRowSelected = this.onRowSelected
        this.showWorkspaces()
    }
    onWorkspaceDialogCancel() {
        this.newWorkspaceButton.disabled = false
        this.workspacesTbl.onRowSelected = this.onRowSelected
    }
}
