class ColorPicker extends View {
    static cssColors = [
        'aqua',
        'orange',
        'beige',
        'coral',
        'deepskyblue',
        'greenyellow',
        'lightpink',
        'pink',
        'powderblue',
        'salmon',
        'skyblue',
        'thistle',
        'wheat',
    ]
    build() {
        this.container.classList.add('view')
        this.container.classList.add('simple_view')
        this.container.classList.add('color_picker')
        this.container.classList.add('hidden')
        const colorsElem = document.createElement('div')
        colorsElem.classList.add('colors')
        this.container.append(colorsElem)
        const controlsElem = document.createElement('div')
        controlsElem.classList.add('menu')
        this.container.append(controlsElem)
        const okButton = document.createElement('button')
        okButton.textContent = 'Ok'
        okButton.classList.add('ok')
        controlsElem.append(okButton)
        const cancelButton = document.createElement('button')
        cancelButton.textContent = 'Cancel'
        cancelButton.classList.add('cancel')
        controlsElem.append(cancelButton)
    }
    constructor(opts) {
        opts.viewId = 'color_picker'
        opts.title = 'Color picker'
        super(opts)
        this.onInput = opts.onInput

        if (!opts.selector) {
            this.build()
        }

        this.elemToColorNameMap = new Map()
        this.colorsContainer = this.container.querySelector('.colors')
        for (const colorName of ColorPicker.cssColors) {
            const colorElem = document.createElement('div')
            colorElem.classList.add('color_item')
            colorElem.style.backgroundColor = colorName
            this.colorsContainer.append(colorElem)
            this.elemToColorNameMap.set(colorElem, colorName)
        }
        this.colorsContainer.addEventListener('click', this.onColorClick.bind(this))
        
        const okButton = this.container.querySelector('.ok')
        okButton.addEventListener('click', this.onOkButtonClick.bind(this))

        const cancelButton = this.container.querySelector('.cancel')
        cancelButton.addEventListener('click', this.onCancelButtonClick.bind(this))
    }
    show(colorName) {
        for (const colorElem of this.colorsContainer.children) {
            if (colorElem.style.backgroundColor === colorName) {
                colorElem.classList.add('selected')
            } else {
                colorElem.classList.remove('selected')
            }
        }
        super.show()
    }
    onColorClick(event) {
        if (!event.target.classList.contains('color_item')) {
            return
        }
        const selectedColorElem = this.container.querySelector('.selected')
        if (event.target === selectedColorElem) {
            return
        }
        selectedColorElem.classList.remove('selected')
        event.target.classList.add('selected')
        this.colorName = this.elemToColorNameMap.get(event.target)
    }
    onOkButtonClick() {
        if (this.onInput) {
            this.onInput(this.colorName)
        }
        this.app.settingsView.show()
    }
    onCancelButtonClick() {
        this.app.settingsView.show()
    }
}