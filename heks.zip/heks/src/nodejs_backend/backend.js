const http = require('http')
const path = require('path')
const fs = require('fs')

const headers = {
    'Access-Control-Allow-Origin': '*',
}

const workingDirectory = 'C:/heks_workspace'

function extractPayload(req) {
    return new Promise((resolve, reject) => {
        let data = ''
        req.on('data', (chunk) => {
            data += chunk
        })
        req.on('end', () => {
            const payload = JSON.parse(data)
            resolve(payload)
        })
    })
}

const routes = {
    read_file: async (req, res) => {
        const payload = await extractPayload(req)
        const filePath = path.join(workingDirectory, payload.path)
        console.log(filePath)
        fs.readFile(filePath, (err, data) => {
            if (err) {
                console.log(err)
                res.writeHead(500, { ...headers, 'Content-Type': 'text/html' })
                res.end('<h1>err</h1>')
                return
            }
            res.writeHead(200, { ...headers, 'Content-Type': 'text/html' })
            res.end(data)
        })
    },
    write_file: async (req, res) => {
        const payload = await extractPayload(req)
        const filePath = path.join(workingDirectory, payload.path)
        console.log(filePath)
        fs.writeFile(filePath, payload.data, (err, data) => {
            if (err) {
                console.log(err)
                res.writeHead(500, { ...headers, 'Content-Type': 'text/html' })
                res.end('<h1>err</h1>')
                return
            }
            res.writeHead(200, { ...headers, 'Content-Type': 'text/html' })
            res.end('<h1>write_file: ok</h1>')
        })
    },
    create_entry: (req, res) => {
        res.writeHead(200, { 'Content-Type': 'text/html' })
        res.end('<h1>create_entry</h1>')
    },
    remove_entry: (req, res) => {
        res.writeHead(200, { 'Content-Type': 'text/html' })
        res.end('<h1>remove_entry</h1>')
    },
}

function notFoundHandler(req, res) {
    res.writeHead(404, { 'Content-Type': 'text/html' })
    res.end('<h1>404 Not found</h1>')
}

const server = http.createServer((req, res) => {
    const handler = routes[req.url.slice(1)]
    if (handler) {
        handler(req, res)
    } else {
        notFoundHandler(req, res)
    } 
})

server.listen(3333)
