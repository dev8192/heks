const http = require('http')
const path = require('path')
const fs = require('fs')

const commonHeaders = {
    'Access-Control-Allow-Origin': '*',
}

const workingDirectory = 'C:/heks_workspace'

function extractPayload(req) {
    return new Promise((resolve, reject) => {
        let data = ''
        req.on('data', (chunk) => {
            data += chunk
        })
        req.on('end', () => {
            const payload = JSON.parse(data)
            resolve(payload)
        })
    })
}

const routes = {
    read_file: async (req, res) => {
        const payload = await extractPayload(req)
        const filePath = path.join(workingDirectory, payload.path)
        console.log(filePath)
        fs.readFile(filePath, (err, data) => {
            const headers = { ...commonHeaders, 'Content-Type': 'text/html' }
            if (err) {
                console.log(err)
                res.writeHead(500, headers)
                res.end('<h1>err</h1>')
                return
            }
            res.writeHead(200, headers)
            res.end(data)
        })
    },
    write_file: async (req, res) => {
        const payload = await extractPayload(req)
        const filePath = path.join(workingDirectory, payload.path)
        console.log(filePath)
        fs.writeFile(filePath, payload.data, (err, data) => {
            const headers = { ...commonHeaders, 'Content-Type': 'text/html' }
            if (err) {
                console.log(err)
                res.writeHead(500, headers)
                res.end('<h1>err</h1>')
                return
            }
            res.writeHead(200, headers)
            res.end('<h1>write_file: ok</h1>')
        })
    },
    create_entry: (req, res) => {
        res.writeHead(200, { 'Content-Type': 'text/html' })
        res.end('<h1>create_entry</h1>')
    },
    remove_entry: (req, res) => {
        res.writeHead(200, { 'Content-Type': 'text/html' })
        res.end('<h1>remove_entry</h1>')
    },
    is_folder: async (req, res) => {
        const payload = await extractPayload(req)
        const filePath = path.join(workingDirectory, payload.path)
        console.log(filePath)
        res.writeHead(200, { ...commonHeaders, 'Content-Type': 'application/json' })
        fs.stat(filePath, (err, stats) => {
            if (err) {
                if (err.code === 'ENOENT') {
                    res.end(JSON.stringify({
                        success: false,
                        msg: 'File not found',
                    }))
                } else {
                    res.end(JSON.stringify({
                        success: false,
                        msg: 'Internal server error',
                    }))
                }
                return
            }
            res.end(JSON.stringify({
                success: true,
                isFolder: stats.isDirectory()
            }))
        })

    }
}

function notFoundHandler(req, res) {
    const headers = { ...commonHeaders, 'Content-Type': 'application/json' }
    res.writeHead(200, headers)
    res.end(JSON.stringify({
        success: false,
        msg: 'Not implemented',
    }))
}

const server = http.createServer((req, res) => {
    const handler = routes[req.url.slice(1)]
    if (handler) {
        handler(req, res)
    } else {
        notFoundHandler(req, res)
    } 
})

server.listen(3333)
