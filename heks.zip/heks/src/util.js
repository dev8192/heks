const encodings = {
    'Windows-1251': {
        0xA8: 'Ё', 0xB8: 'ё',
        0xC0: 'А', 0xC1: 'Б', 0xC2: 'В', 0xC3: 'Г', 0xC4: 'Д', 0xC5: 'Е', 0xC6: 'Ж', 0xC7: 'З',
        0xC8: 'И', 0xC9: 'Й', 0xCA: 'К', 0xCB: 'Л', 0xCC: 'М', 0xCD: 'Н', 0xCE: 'О', 0xCF: 'П',
        0xD0: 'Р', 0xD1: 'С', 0xD2: 'Т', 0xD3: 'У', 0xD4: 'Ф', 0xD5: 'Х', 0xD6: 'Ц', 0xD7: 'Ч',
        0xD8: 'Ш', 0xD9: 'Щ', 0xDA: 'Ъ', 0xDB: 'Ы', 0xDC: 'Ь', 0xDD: 'Э', 0xDE: 'Ю', 0xDF: 'Я',
        0xE0: 'а', 0xE1: 'б', 0xE2: 'в', 0xE3: 'г', 0xE4: 'д', 0xE5: 'е', 0xE6: 'ж', 0xE7: 'з',
        0xE8: 'и', 0xE9: 'й', 0xEA: 'к', 0xEB: 'л', 0xEC: 'м', 0xED: 'н', 0xEE: 'о', 0xEF: 'п',
        0xF0: 'р', 0xF1: 'с', 0xF2: 'т', 0xF3: 'у', 0xF4: 'ф', 0xF5: 'х', 0xF6: 'ц', 0xF7: 'ч',
        0xF8: 'ш', 0xF9: 'щ', 0xFA: 'ъ', 0xFB: 'ы', 0xFC: 'ь', 0xFD: 'э', 0xFE: 'ю', 0xFF: 'я',
    }
}

function copyObject(obj) {
    return JSON.parse(JSON.stringify(obj))
}

function wait(delay) {
    return new Promise((res) => {
        setTimeout(() => {
            res()
        }, delay)
    } )
}


function runAfterDelay(callback, delay) {
    return new Promise((res) => {
        setTimeout(() => {
            callback()
            res()
        }, delay)
    })
}


function createLatinAlphabet() {
    return Uint8Array.from({ length: 26 }, (_, i) => 97 + i).buffer
}

function createAsciiTable() {
    // const bufSize = 128
    const bufSize = 256
    const arr = new Uint8Array(bufSize)
    for (let i = 0; i < bufSize; i++) {
        arr[i] = i
    }
    return arr.buffer
}

function strToArrayBuffer(str) {
    const strArray = str.split(' ')
    const hexArray = []
    for (const byte of strArray) {
        hexArray.push(parseInt(byte, 16))
    }
    const typedArr = new Uint8Array(hexArray)
    return typedArr.buffer
}
