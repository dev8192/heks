class LocalStorageBackend extends BaseBackend {
    constructor(opts) {
        super(opts)
        this.backend = 'LocalStorage'
        this.type = opts.type
        this.name = opts.name
        this.label = 'heks_' + this.name
        this.useBase64 = true
    }
    getLength(item) {
        if (this.useBase64) {
            return atob(item.data).length
        } else {
            return item.data.length
        }
    }
    getData(item) {
        if (this.useBase64) {
            return atob(item.data)
        } else {
            return item.data
        }
    }
    setData(item, value) {
        if (this.useBase64) {
            item.data = btoa(value)
        } else {
            item.data = value
        }
    }
    readRootFolder() {
        const data = localStorage.getItem(this.label)
        if (data) {
            this.rootFolder = JSON.parse(data)
        } else {
            this.rootFolder = {
                children: [],
            }
        }
    }
    writeRootFolder() {
        try {
            const data = JSON.stringify(this.rootFolder)
            localStorage.setItem(this.label, data)
        } catch(err) {
            if (err.name === 'QuotaExceededError') {
                throw new Error('BackendError: QuotaExceededError')
            }
        }
    }
    _getFile(fsItem, filePath, index) {
        if (index < filePath.length) {
            if (fsItem === undefined) {
                throw new Error('BackendError: File not found')
            }
            let newFsItem
            for (const item of fsItem.children) {
                if (item.name === filePath[index]) {
                    newFsItem = item
                    break
                }
            }
            return this._getFile(newFsItem, filePath, index + 1)
        }
        return fsItem
    }
    async readFile(spec) {
        this.readRootFolder()
        const filePath = spec.path.split('/')
        const file = this._getFile(this.rootFolder, filePath, 0)
        if (file) {
            if (spec.offset === undefined) {
                spec.offset = 0
            }
            if (spec.length === undefined) {
                spec.length = this.getLength(file)
            }
            const binStr = this.getData(file)
            return this.binaryStringToArrayBuffer(binStr, spec)
        }
    }
    doWriteFile(fsItem, pathSegments, index, spec) {
        if (index < pathSegments.length) {
            let newFsItem
            for (const item of fsItem.children) {
                if (item.name === pathSegments[index]) {
                    newFsItem = item
                    break
                }
            }
            if (newFsItem === undefined) {
                if (index === (pathSegments.length - 1)) {
                    if (spec.createIfNotExists) {
                        newFsItem = {
                            name: pathSegments[index],
                            data: '',
                        }
                        fsItem.children.push(newFsItem)
                    } else {
                        return false
                    }
                } else {
                    const filePath = pathSegments.slice(0, index + 1).join('/')
                    throw new Error(`BackendError: Not found: "${filePath}"`)
                }
            }
            return this.doWriteFile(newFsItem, pathSegments, index + 1, spec)
        }
        if (spec.data instanceof ArrayBuffer) {
            spec.data = this.arrayBufferToBinaryString(spec.data)
            if (spec.appendMode) {
                this.setData(fsItem, this.getData(fsItem) + spec.data)
            } else {
                if (spec.keepExistingData) {
                    const binStr = this.getData(fsItem)
                    const chunk1 = binStr.slice(0, spec.offset)
                    const chunk2 = binStr.slice(spec.offset + spec.data.length)
                    this.setData(fsItem, chunk1 + spec.data + chunk2)
                } else {
                    this.setData(fsItem, '\0'.repeat(spec.offset) + spec.data)
                }
            }
        }
        this.writeRootFolder()
    }
    arrayBufferToBinaryString(buffer) {
        let binStr = ''
        const view = new Uint8Array(buffer)
        for (let i = 0; i < buffer.byteLength; i++) {
            binStr += String.fromCharCode(view[i])
        }
        return binStr
    }
    binaryStringToArrayBuffer(binStr, spec) {
        const buffer = new ArrayBuffer(spec.length)
        const bytes = new Uint8Array(buffer)
        for (let i = 0; i < spec.length; i++) {
            bytes[i] = binStr.charCodeAt(spec.offset + i)
        }
        return buffer
    }
    dataViewToBinaryString(dataView) {
        let binStr = ''
        for (let i = 0; i < dataView.byteLength; i++) {
            binStr += String.fromCharCode(dataView.getUint8(i))
        }
        return binStr
    }
    isDataValid(data) {
        if (data instanceof ArrayBuffer) return true
        if (data === null) return true
        if (data === undefined) return true
        return false
    }
    async writeFile(spec) {
        if (!this.isDataValid(spec.data)) {
            throw new Error('data must be ArrayBuffer, null, or undefined')
        }
        //     spec.binary = true
        // } else if (ArrayBuffer.isView(spec.data)) {
        //     spec.data = this.arrayBufferToBinaryString(spec.data.buffer)
        //     spec.binary = true
        // } else if (spec.data instanceof DataView) {
        //     spec.data = this.dataViewToBinaryString(spec.data.buffer)
        //     spec.binary = true
        // } else if (spec.data instanceof Blob) {
        //     const buffer = await spec.data.arrayBuffer()
        //     spec.data = this.arrayBufferToBinaryString(buffer)
        //     spec.binary = true
        // } else if (typeof spec.data === 'string') {
        //     // do nothing
        // } else if (spec.data === undefined) {
        //     spec.data = ''
        // } else {
        //     throw new Error('data must be ' +
        //         'ArrayBuffer, TypedArray, DataView, Blob, or string')
        // }
        if (spec.offset === undefined) {
            spec.offset = 0
        }
        this.readRootFolder()
        const pathSegments = spec.path.split('/')
        return this.doWriteFile(this.rootFolder, pathSegments, 0, spec)
    }
    doRemoveFile(folder, pathSegments, index, spec) {
        if (index < (pathSegments.length - 1)) {
            let newFolder
            for (const item of folder.children) {
                if (item.name === pathSegments[index]) {
                    newFolder = item
                    break
                }
            }
            if (newFolder === undefined) {
                throw new Error('BackendError: File not found')
            }
            return this.doRemoveFile(newFolder, pathSegments, index + 1)
        } else {
            let fsItem
            for (const item of folder.children) {
                if (item.name === pathSegments[index]) {
                    fsItem = item
                    break
                }
            }
            if (fsItem === undefined) {
                throw new Error('BackendError: File not found')
            }
            if (fsItem.children && fsItem.children.length > 0 && spec.recursive !== true) {
                throw new Error('BackendError: Directory is not empty')
            }
            const tempFolder = []
            for (const item of folder.children) {
                if (item.name !== pathSegments[index]) {
                    tempFolder.push(item)
                }
            }
            folder.children = tempFolder
            return true
        }
    }
    async removeFile(spec) {
        this.readRootFolder()
        const pathSegments = spec.path.split('/')
        const result = this.doRemoveFile(this.rootFolder, pathSegments, 0, spec)
        this.writeRootFolder()
        return result
    }
    _getParentFolder(filePath) {
        return this._getFile(this.rootFolder, filePath.slice(0, -1), 0)
    }
    async moveFile(oldPath, newPath) {
        this.readRootFolder()
        oldPath = oldPath.split('/')
        newPath = newPath.split('/')
        const oldFile = this._getFile(this.rootFolder, oldPath, 0)
        if (oldFile === undefined) {
            throw new Error('BackendError: File not found')
        }
        const newFile = this._getFile(this.rootFolder, newPath, 0)
        if (newFile) {
            if (this._isFolder(newFile)) {
                newFile.children.push(oldFile)
                this.doRemoveFile(this.rootFolder, oldPath, 0, {})
                this.writeRootFolder()
                return true
            } else {
                throw new Error('BackendError: File already exists')
            }
        } else {
            const folder = this._getParentFolder(newPath)
            this.doRemoveFile(this.rootFolder, oldPath, 0, {})
            folder.children.push(oldFile)
            oldFile.name = newPath.slice(-1)[0]
            this.writeRootFolder()
            return true
        }
    }
    doCreateFolder(folder, pathSegments, index, spec) {
        let newFolder
        for (const item of folder.children) {
            if (item.name === pathSegments[index]) {
                newFolder = item
                break
            }
        }
        if (newFolder === undefined) {
            if (index < (pathSegments.length - 1) && spec.recursive !== true) {
                throw new Error('BackendError: File not found')
            }
            newFolder = {
                name: pathSegments[index],
                children: [],
            }
            folder.children.push(newFolder)
        }
        if (index < (pathSegments.length - 1)) {
            return this.doCreateFolder(newFolder, pathSegments, index + 1, spec)
        }
        this.writeRootFolder()
        return newFolder
    }
    async createFolder(spec) {
        this.readRootFolder()
        const filePath = spec.path.split('/')
        const dirHandle = this.doCreateFolder(this.rootFolder, filePath, 0, spec)
        // return new HeksFileHandle(dirHandle)
    }
    _isFolder(file) {
        return file.children !== undefined
    }
    isFolder(filePath) {
        this.readRootFolder()
        filePath = filePath.split('/')
        const file = this._getFile(this.rootFolder, filePath, 0)
        if (file) {
            return this._isFolder(file)
        }
    }
    async uploadFiles(spec) {
        const data = localStorage.getItem(this.label)
        if (data && !spec.overwrite) {
            throw new Error('Entry is not empty')
        }
        localStorage.setItem(this.label, JSON.stringify(spec.data))
    }
    iterateDirectory(entry, result, spec, path = '') {
        if (path && spec.showFolders) {
            result.push(path + '/')
        }
        for (const item of entry.children) {
            let childPath
            if (path) {
                childPath = `${path}/${item.name}`
            } else {
                childPath = item.name
            }
            if (item.children) {
                this.iterateDirectory(item, result, spec, childPath)
            } else {
                result.push(childPath)
            }
        }
    }
    traverse(inputObj, outputObj) {
        if (inputObj.children) {
            outputObj.children = []
            for (const inputChild of inputObj.children) {
                const outputChild = {
                    name: inputChild.name
                }
                outputObj.children.push(outputChild)
                this.traverse(inputChild, outputChild)
            }
        }
    }
    async downloadFiles(spec) {
        this.readRootFolder()
        const result = []
        this.iterateDirectory(this.rootFolder, result, spec)
        return result
    }
    async getEntries() {
        this.readRootFolder()
        // debugger
        const data = {}
        this.traverse(this.rootFolder, data)
        return data
    }
    async getChildCount(path) {
        this.readRootFolder()
        const filePath = path.split('/')
        const file = this._getFile(this.rootFolder, filePath, 1)
        return file.children.length
    }
    static async createFromData(name, data) {
        const str = JSON.stringify(data)
        localStorage.setItem('heks_' + name, str)
    }
}
