class FileSystemEntry {
    constructor(handle, parentEntry) {
        this.handle = handle
        this.parentEntry = parentEntry
    }
    writeFile() { throw new Error('Not implemented') }
    readFile() { throw new Error('Not implemented') }
    clearFile() { throw new Error('Not implemented') }
    createFile() { throw new Error('Not implemented') }
    removeFile() { throw new Error('Not implemented') }
    moveFile() { throw new Error('Not implemented') }
    isFolder() { throw new Error('Not implemented') }
    copyFile() { throw new Error('Not implemented') }
    createFolder() { throw new Error('Not implemented') }
}

class BaseBackend {
    constructor() {

    }
}
