class SlowBackend extends BaseBackend {
    constructor(opts) {
        super(opts)
        this.delay = opts.delay
    }
}
