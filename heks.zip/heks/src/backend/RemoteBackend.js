class RemoteBackend extends BaseBackend {
    constructor(opts) {
        super(opts)
    }
    writeFile(opts) {
        fetch('http://localhost:3333/write_file', {
            method: 'POST',
            body: JSON.stringify(opts)
        })
    }
    async readFile(opts) {
        const res = await fetch('http://localhost:3333/read_file', {
            method: 'POST',
            body: JSON.stringify(opts)
        })
        return res.bytes()
    }
    async isFolder(opts) {
        const res = await fetch('http://localhost:3333/is_folder', {
            method: 'POST',
            body: JSON.stringify(opts)
        })
        return res.json()
    }
}
