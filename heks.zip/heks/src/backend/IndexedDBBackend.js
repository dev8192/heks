class IndexedDBBackend extends BaseBackend {
    constructor(opts) {
        super(opts)
    }
}
