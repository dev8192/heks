class InMemoryBackend extends BaseBackend {
    constructor(opts) {
        super(opts)
    }
}
