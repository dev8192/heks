class FileSystemAccessBackend extends BaseBackend {
    constructor(opts) {
        super(opts)
        this.backend = 'FileSystemAccess'
        this.type = opts.type
        this.name = opts.name
        this.rootHandle = opts.handle
    }
    async doCreateFolder(handle, pathSegments, index, spec) {
        if (index < (pathSegments.length - 1)) {
            const newHandle = await handle.getDirectoryHandle(pathSegments[index], {
                create: !!spec.recursive,
            })
            console.log('found', pathSegments[index])
            return await this.doCreateFolder(newHandle, pathSegments, index + 1, spec)
        }
        console.log('creating', pathSegments[index])
        return await handle.getDirectoryHandle(pathSegments[index], {
            create: true,
        })
    }
    async createFolder(spec) {
        try {
            const pathSegments = spec.path.split('/')
            const dirHandle = await this.doCreateFolder(this.rootHandle, pathSegments, 0, spec)
            // return new HeksFileHandle(dirHandle)
        } catch (err) {
            if (err.name === 'AbortError') {
                throw new Error('BackendError: Other error')
            } else if (err.name === 'NotFoundError') {
                throw new Error('BackendError: File not found')
            }
            console.log(err)
            throw new Error('BackendError: New error')
        }
    }
    async doRemoveFile(handle, pathSegments, index, spec) {
        if (index < (pathSegments.length - 1)) {
            const newHandle = await handle.getDirectoryHandle(pathSegments[index])
            console.log('found', pathSegments[index])
            return await this.doRemoveFile(newHandle, pathSegments, index + 1, spec)
        }
        console.log('removing', pathSegments[index])
        await handle.removeEntry(pathSegments[index], {
            recursive: spec.recursive,
        })
    }
    async removeFile(spec) {
        try {
            const pathSegments = spec.path.split('/')
            await this.doRemoveFile(this.rootHandle, pathSegments, 0, spec)
        } catch (err) {
            if (err.name === 'AbortError') {
                throw new Error('BackendError: Other error')
            } else if (err.name === 'NotFoundError') {
                throw new Error('BackendError: File not found')
            } else if (err.name === 'InvalidModificationError') {
                throw new Error('BackendError: Directory is not empty')
            }
            console.log(err)
            throw new Error('BackendError: New error')
        }
    }
    async doWriteFile(handle, pathSegments, index, spec) {
        if (index < (pathSegments.length - 1)) {
            const newHandle = await handle.getDirectoryHandle(pathSegments[index])
            console.log('found', pathSegments[index])
            return await this.doWriteFile(newHandle, pathSegments, index + 1, spec)
        } else if (index === (pathSegments.length - 1)) {
            const newHandle = await handle.getFileHandle(pathSegments[index], {
                create: !!spec.createIfNotExists,
            })
            return await this.doWriteFile(newHandle, pathSegments, index + 1, spec)
        }
        if (spec.data === undefined) {
            return
        }
        if (spec.appendMode) {
            const writable = await handle.createWritable({
                keepExistingData: true,
            })
            const file = await handle.getFile()
            await writable.seek(file.size)
            await writable.write(spec.data)
            await writable.close()
        } else {
            const writable = await handle.createWritable({
                keepExistingData: !!spec.keepExistingData,
            })
            if (spec.offset) {
                await writable.seek(spec.offset)
            }
            await writable.write(spec.data)
            await writable.close()
        }
        return handle
    }
    async writeFile(spec) {
        if (spec.data instanceof ArrayBuffer) {
            // do nothing
        } else if (typeof spec.data === 'string') {
            // do nothing
        } else if (spec.data === undefined) {
            spec.data = ''
        } else {
            throw new Error('data must be string or ArrayBuffer')
        }
        try {
            const pathSegments = spec.path.split('/')
            return await this.doWriteFile(this.rootHandle, pathSegments, 0, spec)
        } catch(err) {
            if (err.name === 'AbortError') {
                throw new Error('BackendError: Other error')
            } else if (err.name === 'NotFoundError') {
                throw new Error('BackendError: File not found')
                // const filePath = pathSegments.slice(0, index + 1).join('/')
                // throw new Error(`BackendError: Not found: "${filePath}"`)
            } else if (err.name === 'InvalidModificationError') {
                throw new Error('BackendError: Directory is not empty')
            }
            console.log(err)
            throw new Error('BackendError: New error')
        }
    }
    async doReadFile(handle, pathSegments, index, spec) {
        if (index < (pathSegments.length - 1)) {
            const newHandle = await handle.getDirectoryHandle(pathSegments[index])
            console.log('found', pathSegments[index])
            return await this.doReadFile(newHandle, pathSegments, index + 1, spec)
        } else if (index === (pathSegments.length - 1)) {
            const newHandle = await handle.getFileHandle(pathSegments[index])
            return await this.doReadFile(newHandle, pathSegments, index + 1, spec)
        }
        let file = await handle.getFile()
        console.log(file)
        if (spec.offset === undefined) {
            spec.offset = 0
        }
        if (spec.length === undefined) {
            spec.length = file.size
        }
        if (spec.offset > 0 || spec.length < file.size) {
            console.log('slicing a file')
            file = file.slice(spec.offset, spec.offset + spec.length)
        }
        console.log(file)
        if (spec.binary) {
            return await file.arrayBuffer()
        } else {
            return await file.text()
        }
    }
    async readFile(spec) {
        try {
            const pathSegments = spec.path.split('/')
            return await this.doReadFile(this.rootHandle, pathSegments, 0, spec)
        } catch(err) {
            if (err.name === 'AbortError') {
                throw new Error('BackendError: Other error')
            } else if (err.name === 'NotFoundError') {
                throw new Error('BackendError: File not found')
                // const filePath = pathSegments.slice(0, index + 1).join('/')
                // throw new Error(`BackendError: Not found: "${filePath}"`)
            } else if (err.name === 'InvalidModificationError') {
                throw new Error('BackendError: Directory is not empty')
            }
            console.log(err)
            throw new Error('BackendError: New error')
        }
    }
    async extractHandle(entry, pathSegments, index) {
        if (index < (pathSegments.length - 1)) {
            const newHandle = await entry.handle.getDirectoryHandle(pathSegments[index])
            const newEntry = new FileSystemEntry(newHandle, entry)
            return await this.extractHandle(newEntry, pathSegments, index + 1)
        }
        let newHandle
        try {
            newHandle = await entry.handle.getFileHandle(pathSegments[index])
        } catch(err) {
            try {
                newHandle = await entry.handle.getDirectoryHandle(pathSegments[index])
            } catch(err) {
            }
        }
        return new FileSystemEntry(newHandle, entry)
    }
    async getParentFolder(handle, pathSegments, index = 0) {
        console.log('getParentFolder', pathSegments, index)
        if (index < (pathSegments.length - 1)) {
            const newHandle = await handle.getDirectoryHandle(pathSegments[index])
            console.log('found', pathSegments[index])
            return await this.getParentFolder(newHandle, pathSegments, index + 1)
        }
        return handle
    }
    async moveFile(srcPath, dstPath) {
        try {
            const rootEntry = new FileSystemEntry(this.rootHandle)
            srcPath = srcPath.split('/')
            dstPath = dstPath.split('/')
            const srcFileEntry = await this.extractHandle(rootEntry, srcPath, 0)
            if (srcFileEntry.handle === undefined) {
                throw new Error('BackendError: File not found')
            }
            const dstFileEntry = await this.extractHandle(rootEntry, dstPath, 0)
            if (dstFileEntry.handle && dstFileEntry.handle.kind === 'file') {
                throw new Error('BackendError: File already exists')
            }
            let dstHandle
            let dstName
            if (dstFileEntry.handle) {
                if (dstFileEntry.handle.kind === 'file') {
                    throw new Error('BackendError: File already exists')
                } else {
                    dstHandle = dstFileEntry.handle
                    dstName = srcPath[srcPath.length - 1]
                }
            } else {
                dstHandle = dstFileEntry.parentEntry.handle
                dstName = dstPath[dstPath.length - 1]
            }
            if (srcFileEntry.handle.kind === 'file') {
                const newFileHandle = await dstHandle.getFileHandle(dstName, {
                    create: true,
                })
                const srcFileObject = await srcFileEntry.handle.getFile()
                const contents = await srcFileObject.arrayBuffer()
                const writable = await newFileHandle.createWritable()
                await writable.write(contents)
                await writable.close()
            } else {
                const newDirHandle = await newFileParent.getDirectoryHandle(dstName, {
                    create: true,
                })
                await this.doCopyDirectory(srcFileEntry.handle, newDirHandle)
            }
            let srcParentHandle = srcFileEntry.parentEntry.handle
            await srcParentHandle.removeEntry(srcPath[srcPath.length - 1], {
                recursive: true,
            })
        } catch(err) {
            if (err.name === 'AbortError') {
                throw new Error('BackendError: Other error')
            } else if (err.name === 'NotFoundError') {
                throw new Error('BackendError: File not found')
            } else if (err.name === 'InvalidModificationError') {
                throw new Error('BackendError: Directory is not empty')
            }
            console.log(err)
            throw new Error('BackendError: New error')
        }
    }
    clearFile() {

    }
    createFile() {

    }
    isFolder() {

    }
    copyFile() {

    }
    async getEntriesInternal(parentHandle, parentObj) {
        parentObj.children = []
        for await (const childHandle of parentHandle.values()) {
            // console.log('childHandle', childHandle)
            const childObj = {
                name: childHandle.name
            }
            if (childHandle.kind === 'directory') {
                await this.getEntriesInternal(childHandle, childObj)
            }
            parentObj.children.push(childObj)
        }
    }
    async getEntries() {
        const data = {}
        await this.getEntriesInternal(this.rootHandle, data)
        // console.log(data)
        return data
    }
    async getEntryNames1() {
        const result = []
        for await (const key of this.rootHandle.keys()) {
            result.push(key)
        }
        return result
    }
    async getEntryNames() {
        const result = []
        const iterator = this.rootHandle.keys()
        let entry = await iterator.next()
        while (!entry.done) {
            result.push(entry.value)
            entry = await iterator.next()
        }
        return result
    }
    async doCopyDirectory(srcHandle, dstHandle) {
        for await (const [name, handle] of srcHandle.entries()) {
            if (handle.kind === 'file') {
                const file = await handle.getFile()
                const dstFileHandle = await dstHandle.getFileHandle(name, {
                    create: true,
                })
                const contents = await file.arrayBuffer()
                const writable = await dstFileHandle.createWritable()
                await writable.write(contents)
                await writable.close()
            } else {
                const newDestDir = await dstHandle.getDirectoryHandle(name, {
                    create: true,
                })
                await this.doCopyDirectory(handle, newDestDir)
            }
        }
    }
    async copyDirectory(srcPath, dstPath) {
        try {
            const rootEntry = new FileSystemEntry(this.rootHandle)
            srcPath = srcPath.split('/')
            dstPath = dstPath.split('/')
            const oldFileEntry = await this.extractHandle(rootEntry, srcPath, 0)
            if (oldFileEntry.handle === undefined) {
                throw new Error('BackendError: File not found')
            }
            const newDirHandle = await newFileParent.getDirectoryHandle(newFileName, {
                create: true,
            })
            await this.doCopyDirectory(oldFileEntry.handle, newDirHandle)
        } catch(err) {
            if (err.name === 'AbortError') {
                throw new Error('BackendError: Other error')
            } else if (err.name === 'NotFoundError') {
                throw new Error('BackendError: File not found')
            } else if (err.name === 'InvalidModificationError') {
                throw new Error('BackendError: Directory is not empty')
            }
            console.log(err)
            throw new Error('BackendError: New error')
        }
    }
    async uploadFiles(spec) {
    }
    async downloadFiles(spec) {
    }
    async getChildCount(path) {
        let parts = String(path).split('/').filter(Boolean)
        if (parts[0] === '<root>') {
            parts = parts.slice(1)
        }
        let dir = this.rootHandle
        // console.log(parts)
        for (const part of parts) {
            // console.log('getting part', part)
            dir = await dir.getDirectoryHandle(part, { create: false })
        }
        if (typeof Array.fromAsync === 'function') {
            const arr = await Array.fromAsync(dir.values())
            return arr.length
        } else {
            let count = 0
            for await (const _ of dir.values()) {
                count++
            }
            return count
        }
    }
}
