class Dialog extends Widget {
    constructor(opts) {
        super(opts)
        
        this.okButton = this.container.querySelector('.ok')
        this.okButton.addEventListener('click', this.onOkClick.bind(this))

        this.cancelButton = this.container.querySelector('.cancel')
        this.cancelButton.addEventListener('click', this.onCancelClick.bind(this))
    }
    onOkClick() {
        this.hide()
        this.emit('ok')
    }
    onCancelClick() {
        this.hide()
        this.emit('cancel')
    }
}
