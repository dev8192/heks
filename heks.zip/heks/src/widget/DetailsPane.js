
/*
Uint8   Uint16BE  Uint32BE  Uint64BE
        Uint16LE  Uint32LE  Uint64LE
Int8    Int16BE   Int32BE   Int64BE
        Int16LE   Int32LE   Int64LE
        Float16   Float32   Float64
*/
class DetailsPane extends Widget {
    constructor(opts) {
        super(opts)
        this.numberFormat = 'Uint8'
        this.contentElem = this.container.querySelector('.content')
        this.numberFormatBtnGrp = new ButtonGroup({
            parentElem: this.container,
            selector: '.number_format',
            onClick: this.changeNumberFormat.bind(this),
        })
        this.app.addListener('bufferValueChanged', this.onBufferValueChanged.bind(this))

        this.buttons = {
            Uint8: {elem: this.container.querySelector('.Uint8'), disabled: false},
            Uint16BE: {elem: this.container.querySelector('.Uint16BE'), disabled: false},
            Uint32BE: {elem: this.container.querySelector('.Uint32BE'), disabled: false},
            Uint64BE: {elem: this.container.querySelector('.Uint64BE'), disabled: false},
            Uint16LE: {elem: this.container.querySelector('.Uint16LE'), disabled: false},
            Uint32LE: {elem: this.container.querySelector('.Uint32LE'), disabled: false},
            Uint64LE: {elem: this.container.querySelector('.Uint64LE'), disabled: false},
            Int8: {elem: this.container.querySelector('.Int8'), disabled: false},
            Int16BE: {elem: this.container.querySelector('.Int16BE'), disabled: false},
            Int32BE: {elem: this.container.querySelector('.Int32BE'), disabled: false},
            Int64BE: {elem: this.container.querySelector('.Int64BE'), disabled: false},
            Int16LE: {elem: this.container.querySelector('.Int16LE'), disabled: false},
            Int32LE: {elem: this.container.querySelector('.Int32LE'), disabled: false},
            Int64LE: {elem: this.container.querySelector('.Int64LE'), disabled: false},
            Float32BE: {elem: this.container.querySelector('.Float32BE'), disabled: false},
            Float64BE: {elem: this.container.querySelector('.Float64BE'), disabled: false},
            Float32LE: {elem: this.container.querySelector('.Float32LE'), disabled: false},
            Float64LE: {elem: this.container.querySelector('.Float64LE'), disabled: false},
        }
    }
    onBufferValueChanged(event) {
        if (event.origin === this) {
            return
        }
        this.show()
    }
    changeNumberFormat(value) {
        console.log(value)
        this.numberFormat = value
        this.emit('numberFormatChanged')
        this.show()
    }
    computeAlignment(index) {
        for (const item of Object.values(this.buttons)) {
            item.disabled = true
        }
        if (index % 8 === 0) {
            this.buttons.Uint64BE.disabled = false
            this.buttons.Uint64LE.disabled = false
            this.buttons.Int64BE.disabled = false
            this.buttons.Int64LE.disabled = false
            this.buttons.Float64BE.disabled = false
            this.buttons.Float64LE.disabled = false
        }
        if (index % 4 === 0) {
            this.buttons.Uint32BE.disabled = false
            this.buttons.Uint32LE.disabled = false
            this.buttons.Int32BE.disabled = false
            this.buttons.Int32LE.disabled = false
            this.buttons.Float32BE.disabled = false
            this.buttons.Float32LE.disabled = false
        }
        if (index % 2 === 0) {
            this.buttons.Uint16BE.disabled = false
            this.buttons.Uint16LE.disabled = false
            this.buttons.Int16BE.disabled = false
            this.buttons.Int16LE.disabled = false
        }
        this.buttons.Uint8.disabled = false
        this.buttons.Int8.disabled = false
        for (const item of Object.values(this.buttons)) {
            item.elem.disabled = item.disabled
        }
    }
    show() {
        const index = this.app.currentEditor.currentCellIdx
        this.computeAlignment(index)
        const currentEditor = this.app.currentEditor
        
        let value
        if (this.numberFormat === 'Uint8') {
            value = currentEditor.buffer.getUint8(index)
            value = this.formatNumber(value)
        } else if (this.numberFormat === 'Uint16BE') {
            value = currentEditor.buffer.getUint16(index)
            value = this.formatNumber(value)
        } else if (this.numberFormat === 'Uint32BE') {
            value = currentEditor.buffer.getUint32(index)
            value = this.formatNumber(value)
        } else if (this.numberFormat === 'Uint64BE') {
            value = currentEditor.buffer.getUint64(index)
            value = this.formatNumber(value)
        } else if (this.numberFormat === 'Uint16LE') {
            value = currentEditor.buffer.getUint16(index, true)
            value = this.formatNumber(value)
        } else if (this.numberFormat === 'Uint32LE') {
            value = currentEditor.buffer.getUint32(index, true)
            value = this.formatNumber(value)
        } else if (this.numberFormat === 'Uint64LE') {
            value = currentEditor.buffer.getUint64(index, true)
            value = this.formatNumber(value)
        } else if (this.numberFormat === 'Int8') {
            value = currentEditor.buffer.getInt8(index)
            value = this.formatNumber(value)
        } else if (this.numberFormat === 'Int16BE') {
            value = currentEditor.buffer.getInt16(index)
            value = this.formatNumber(value)
        } else if (this.numberFormat === 'Int32BE') {
            value = currentEditor.buffer.getInt32(index)
            value = this.formatNumber(value)
        } else if (this.numberFormat === 'Int64BE') {
            value = currentEditor.buffer.getInt64(index)
            value = this.formatNumber(value)
        } else if (this.numberFormat === 'Int16LE') {
            value = currentEditor.buffer.getInt16(index, true)
            value = this.formatNumber(value)
        } else if (this.numberFormat === 'Int32LE') {
            value = currentEditor.buffer.getInt32(index, true)
            value = this.formatNumber(value)
        } else if (this.numberFormat === 'Int64LE') {
            value = currentEditor.buffer.getInt64(index, true)
            value = this.formatNumber(value)

        } else if (this.numberFormat === 'Float32BE') {
            value = currentEditor.buffer.getFloat32(index)
        } else if (this.numberFormat === 'Float64BE') {
            value = currentEditor.buffer.getFloat64(index)
        } else if (this.numberFormat === 'Float32LE') {
            value = currentEditor.buffer.getFloat32(index, true)
        } else if (this.numberFormat === 'Float64LE') {
            value = currentEditor.buffer.getFloat64(index, true)
        } else {
            throw new Error('Unknown number format')
        }

        this.contentElem.textContent = value
        super.show()
    }
    formatNumber(number) {
        const str = number.toString()
        let result = []
        for (let i = str.length - 1, j = 1; i >= 0; i--, j++) {
            result.push(str[i])
            if (j % 3 === 0 && i !== 0) {
                result.push(' ')
            }
        }
        result.reverse()
        return result.join('')
    }
}
