
class MessageWidget extends Widget {
    constructor(opts = {}) {
        opts.selector = opts.selector || '.message_box'
        opts.parentElem = opts.parentElem || document.body
        super(opts)
        if (opts.timeout) {
            this.timeout = opts.timeout
        } else {
            this.timeout = 1000
        }
        this.timeoutId = null
    }
    print(msg) {
        if (msg === undefined) {
            console.log('msg is undefined')
            return
        }
        if (msg.trim().length === 0) {
            console.log('Printing empty message?')
            return
        }
        this.container.textContent = msg
        if (this.timeoutId) {
            clearTimeout(this.timeoutId)
        }
        this.timeoutId = setTimeout(() => {
            this.container.textContent = ''
            this.timeoutId = null
        }, this.timeout)
    }
}
