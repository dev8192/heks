class SaveFileDialog extends SimpleView {
    constructor(opts) {
        opts.viewId = 'save_file_dialog'
        super(opts)

        this.fileNameInput = this.controlsElem.querySelector('.file_name')
        this.bufSizeInput = this.controlsElem.querySelector('.buffer_size')
        this.startOffsetInput = this.controlsElem.querySelector('.offset')
    }
    show() {
        super.show()
        const fileInfo = this.app.currentEditor.fileInfo
        this.fileNameInput.value = fileInfo.getFileName()
        // this.fileSizeDiv.value = fileInfo.getFileSize()
        this.bufSizeInput.value = fileInfo.getFileSize()
        this.startOffsetInput.value = fileInfo.getOffset()
    }
    async onOkButtonClick() {
        // await this.app.currentEditor.saveFile()
        // this.showPrev()
    }
    build() {
        super.build()
        throw new Error('Not implemented')
    }
}