/*
file offset vs buffer offset
why both of them are needed

                File        Buffer      Window
File size:      100 - 500
Buffer bytes:   150 - 350   50 - 200
Window bytes:   100 - 150   

File offset: 100
Buffer size: 200
Buffer offset: 50
Window size: 50
*/
class VisualWindow extends Widget {
    constructor(opts) {
        super(opts)

        this.contentElem = this.container.querySelector('.content')
        this.fileElem = this.contentElem.querySelector('.file')
        this.bufferElem = this.fileElem.querySelector('.buffer')
        this.windowElem = this.bufferElem.querySelector('.window')
        
        const contentElemWidth = getComputedStyle(this.contentElem).width
        this.maxFileSize = Number(contentElemWidth.slice(0, -2))

        this.setFileSize(opts.fileSize)
        this.setFileOffset(opts.fileOffset)
        this.setBufferSize(opts.bufferSize)
        this.setBufferOffset(opts.bufferOffset)
        this.setWindowSize(opts.windowSize)

        this.fileSizeInput = this.container.querySelector('.file_size')
        this.fileSizeInput.addEventListener('input', this.onFileSizeInput.bind(this))
        this.fileSizeInput.value = opts.fileSize

        this.fileOffsetInput = this.container.querySelector('.file_offset')
        this.fileOffsetInput.addEventListener('input', this.onFileOffsetInput.bind(this))
        this.fileOffsetInput.value = opts.fileOffset

        this.bufferSizeInput = this.container.querySelector('.buffer_size')
        this.bufferSizeInput.addEventListener('input', this.onBufferSizeInput.bind(this))
        this.bufferSizeInput.value = opts.bufferSize

        this.bufferOffsetInput = this.container.querySelector('.buffer_offset')
        this.bufferOffsetInput.addEventListener('input', this.onBufferOffsetInput.bind(this))
        this.bufferOffsetInput.value = opts.bufferOffset

        this.windowSizeInput = this.container.querySelector('.window_size')
        this.windowSizeInput.addEventListener('input', this.onWindowSizeInput.bind(this))
        this.windowSizeInput.value = opts.windowSize
    }
    onFileSizeInput() {
        try {
            const value = Number(this.fileSizeInput.value)
            this.setFileSize(value)
        } catch (err) {
            this.fileSizeInput.value = this.fileSize
        }
    }
    setFileSize(value) {
        if (value < 0) {
            throw new Error('File size cannot be negative')
        }
        if (value > this.maxFileSize) {
            throw new Error('File size cannot be larger than max file size')
        }
        this.fileSize = value
        this.fileElem.style.width = value + 'px'
    }

    onFileOffsetInput() {
        try {
            const value = Number(this.fileOffsetInput.value)
            this.setFileOffset(value)
        } catch (err) {
            this.fileOffsetInput.value = this.fileOffset
        }
    }
    setFileOffset(value) {
        if (value < 0) {
            throw new Error('File offset cannot be negative')
        }
        this.fileOffset = value
        this.bufferElem.style.marginLeft = value + 'px'
    }

    onBufferSizeInput() {
        try {
            const value = Number(this.bufferSizeInput.value)
            this.setBufferSize(value)
        } catch (err) {
            this.bufferSizeInput.value = this.bufferSize
        }
    }
    setBufferSize(value) {
        if (value < 0) {
            throw new Error('Buffer size cannot be negative')
        }
        if ((value + this.fileOffset) > this.maxFileSize) {
            throw new Error('Buffer size cannot be larger than max file size')
        }
        this.bufferSize = value
        this.bufferElem.style.width = value + 'px'
    }

    onBufferOffsetInput() {
        try {
            const value = Number(this.bufferOffsetInput.value)
            this.setBufferOffset(value)
        } catch (err) {
            this.bufferOffsetInput.value = this.bufferOffset
        }
    }
    setBufferOffset(value) {
        if (value < 0) {
            throw new Error('Buffer offset cannot be negative')
        }
        this.bufferOffset = value
        this.windowElem.style.marginLeft = value + 'px'
    }

    onWindowSizeInput() {
        try {
            const value = Number(this.windowSizeInput.value)
            this.setWindowSize(value)
        } catch (err) {
            this.windowSizeInput.value = this.windowSize
        }
    }
    setWindowSize(value) {
        if (value < 0) {
            throw new Error('Window size cannot be negative')
        }
        // console.log
        if ((value + this.fileOffset + this.bufferOffset) > this.maxFileSize) {
            throw new Error('Window size cannot be larger than max file size')
        }
        this.windowSize = value
        this.windowElem.style.width = value + 'px'
    }
}
