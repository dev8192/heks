
class CheckboxGroup extends Widget {
    constructor(opts = {}) {
        super(opts)
        this.mainCheckbox = this.createCheckbox('main', 'Select All')
        this.mainCheckbox.addEventListener('change', this.onMainCheckboxChange.bind(this))
        this.childCheckboxes = []
        this.checkedCount = 0
        if (opts.options) {
            for (const option of opts.options) {
                const checkbox = this.createCheckbox('main', option.text, option.checked)
                checkbox.addEventListener('change', (event) => {
                    this.onChildCheckboxChange(event.target.checked, option.onClick)
                })
                this.childCheckboxes.push(checkbox)
                if (option.checked) {
                    this.checkedCount++
                }
            }
            this.updateMainCheckbox()
        }
    }
    onMainCheckboxChange() {
        for (const checkbox of this.childCheckboxes) {
            checkbox.checked = this.mainCheckbox.checked
        }
        if (this.mainCheckbox.checked) {
            this.checkedCount = this.childCheckboxes.length
        } else {
            this.checkedCount = 0
        }
        this.mainCheckbox.indeterminate = false
        if (this.opts.onMainCheckboxClick) {
            this.opts.onMainCheckboxClick(this.mainCheckbox.checked)
        }
    }
    updateMainCheckbox() {
        if (this.checkedCount === this.childCheckboxes.length) {
            this.mainCheckbox.checked = true
            this.mainCheckbox.indeterminate = false
        } else if (this.checkedCount === 0) {
            this.mainCheckbox.checked = false
            this.mainCheckbox.indeterminate = false
        } else {
            this.mainCheckbox.indeterminate = true
        }
    }
    onChildCheckboxChange(checked, callback) {
        if (checked) {
            this.checkedCount++
        } else {
            this.checkedCount--
        }
        this.updateMainCheckbox()
        if (callback) {
            callback(checked)
        }
    }
    createCheckbox(className, textContent, checked) {
        const labelElem = document.createElement('label')
        labelElem.style.display = 'flex'
        labelElem.style.gap = '10px'
        this.container.append(labelElem)

        const inputElem = document.createElement('input')
        inputElem.type = 'checkbox'
        inputElem.className = className
        inputElem.checked = checked
        labelElem.append(inputElem)

        const spanElem = document.createElement('span')
        spanElem.textContent = textContent
        labelElem.append(spanElem)

        return inputElem
    }
}

