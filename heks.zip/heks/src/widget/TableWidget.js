class TableBase extends Widget {
    constructor(opts) {
        super(opts)
    }
}

class TableWidget extends TableBase {
    constructor(opts) {
        super(opts)
        this.buildInternal()

        this.onClick = this.onClick.bind(this)
        this.container.addEventListener('click', this.onClick)

        this.rowToObjectMap = new Map()
        this.objectToRowMap = new Map()
    }
    buildInternal() {
        this.tableElem = document.createElement('table')
        this.container.append(this.tableElem)

        this.colgroupElem = document.createElement('colgroup')
        this.tableElem.append(this.colgroupElem)

        this.theadElem = document.createElement('thead')
        this.tableElem.append(this.theadElem)

        this.tbodyElem = document.createElement('tbody')
        this.tableElem.append(this.tbodyElem)
    }
    show(data) {
        super.show()
        this.theadElem.innerHTML = ''
        this.tbodyElem.innerHTML = ''

        if (data.format === 1) {
            this.populateFormat1(data)
        } else if (data.format === 2) {
            this.populateFormat2(data)
        } else {
            throw new Error('Unknown format')
        }
    }
    populateFormat1(data) {
        const rowElem = document.createElement('tr')
        this.theadElem.append(rowElem)
        for (let i = 0; i < data.headers.length; i++) {
            const colElem = document.createElement('th')
            colElem.textContent = data.headers[i]
            rowElem.append(colElem)
        }

        for (let i = 0; i < data.rows.length; i++) {
            const rowElem = document.createElement('tr')
            this.tbodyElem.append(rowElem)
            for (let j = 0; j < data.rows[i].length; j++) {
                const colElem = document.createElement('td')
                colElem.textContent = data.rows[i][j]
                rowElem.append(colElem)
            }
            this.rowToObjectMap.set(rowElem, data.rows[i])
            this.objectToRowMap.set(data.rows[i], rowElem)
        }
    }
    populateFormat2(data) {
        const rowElem = document.createElement('tr')
        this.theadElem.append(rowElem)
        for (const headerObj of data.headers) {
            const colElem = document.createElement('col')
            colElem.textContent = headerObj.title
            colElem.classList.add(headerObj.key)
            this.colgroupElem.append(colElem)

            const thElem = document.createElement('th')
            thElem.textContent = headerObj.title
            rowElem.append(thElem)
        }

        for (const rowObj of data.rows) {
            const rowElem = document.createElement('tr')
            this.tbodyElem.append(rowElem)
            for (const headerObj of data.headers) {
                const colElem = document.createElement('td')
                colElem.textContent = rowObj[headerObj.key]
                rowElem.append(colElem)
            }
            this.rowToObjectMap.set(rowElem, rowObj)
            this.objectToRowMap.set(rowObj, rowElem)
        }
    }
    onClick(event) {
        if (this.onRowSelected && event.target.tagName === 'TD') {
            const row = event.target.parentElement
            const obj = this.rowToObjectMap.get(row)
            this.onRowSelected(obj)
        }
    }
    addRowHighlight(obj) {
        const row = this.objectToRowMap.get(obj)
        row.style.backgroundColor = '#ab80db'
    }
    removeRowHighlight(obj) {
        const row = this.objectToRowMap.get(obj)
        row.style.backgroundColor = ''
    }
}
