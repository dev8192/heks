class Text extends Widget {
    constructor(opts) {
        super(opts)
        this.container.textContent = opts.text
    }
    setText(text) {
        this.container.textContent = text
    }
    getText() {
        return this.container.textContent
    }
}
