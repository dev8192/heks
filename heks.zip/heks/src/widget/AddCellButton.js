
class AddCellButton extends Widget {
    constructor(opts) {
        super(opts)
        this.editorView = opts.editorView
        this.container.addEventListener('click', this.onClick.bind(this))
    }
    build() {
        this.container = document.createElement('button')
        this.container.classList.add('cell')
        this.container.classList.add('add_cell')
        this.container.textContent = '+'
    }
    insert() {
        let bufSize = this.app.currentEditor.buffer.bufSize
        bufSize -= this.app.currentEditor.buffer.bufferOffset

        const colIdx = bufSize % 16
        let rowIdx = (bufSize - colIdx) / 16
        rowIdx += this.app.settings.get('showCols') ? 1 : 0
        // rowIdx += colIdx === 0 ? 1 : 0
        const row = this.editorView.gridElem.children[rowIdx]
        if (!row) {
            return
        }
        const emptyCell = row.children[colIdx]
        if (!emptyCell) {
            return
        }
        emptyCell.append(this.container)
    }
    onClick(event) {
        const cell = this.container.parentElement
        this.container.remove()
        cell.textContent = (0).toString(16).padStart(2, '0')
        this.app.styleMgr.setBgColor(cell)

        const idx = this.editorView.posMgr.getIndex(cell)
        this.app.currentEditor.buffer.setUint8({
            index: idx,
            origin: this.app.mainView.editorView,
            value: 0,
        })
        this.app.currentEditor.buffer.bufSize++

        if (cell.parentElement.lastElementChild === cell) {
            this.app.currentEditor.buffer.extendBuffer()
            if (this.editorView.gridElem.lastElementChild === cell.parentElement) {
                this.app.mainView.offsetWidget.goToNext()
                this.container.focus()
                event.stopPropagation()
                return
            } else {
                let offset = this.app.currentEditor.fileInfo.startOffset
                let idx = this.editorView.posMgr.getY(cell)
                idx += 1
                offset += 16 * idx
                const offSize = this.app.settings.get('offsetSize')
                const addr = '0x' + offset.toString(16).padStart(offSize, '0')
                idx += 1
                const elem = this.app.mainView.editorView.offsetsElem.children[idx]
                elem.textContent = addr
                this.app.styleMgr.setBgColor(elem)
            }
            const nextRow = cell.parentElement.nextElementSibling
            nextRow.firstElementChild.append(this.container)
        } else {
            cell.nextElementSibling.append(this.container)
        }
        
        this.container.focus()
        event.stopPropagation()
    }
}
