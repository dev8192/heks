class TextInput extends Widget {
    constructor(opts) {
        super(opts)

        this.onInput = this.onInput.bind(this)
        this.onOkButtonClick = this.onOkButtonClick.bind(this)
        this.onCancelButtonClick = this.onCancelButtonClick.bind(this)

        this.inputElem = this.container.querySelector('input')
        this.okButton = this.container.querySelector('.ok')
        this.cancelButton = this.container.querySelector('.cancel')

        this.container.addEventListener('input', this.onInput)
        this.okButton.addEventListener('click', this.onOkButtonClick)
        this.cancelButton.addEventListener('click', this.onCancelButtonClick)
        
        this.kbdMgr = new KeyboardManager({
            container: this.inputElem,
            stopPropagation: true,
        })
        this.kbdMgr.addHandler('Enter', this.onOkButtonClick)
        this.kbdMgr.addHandler('Escape', this.onCancelButtonClick)
    }
    onOkButtonClick(event) {
        event.stopPropagation()
        this.emit('ok')
    }
    onCancelButtonClick(event) {
        event.stopPropagation()
        this.emit('cancel')
    }
    build1() {
        super.build()

        this.container.classList.add('text_input')

        this.inputElem = document.createElement('input')
        this.container.append(this.inputElem)

        this.okButton = document.createElement('button')
        this.okButton.textContent = 'Ok'
        this.okButton.classList.add('ok')
        this.container.append(this.okButton)

        this.cancelButton = document.createElement('button')
        this.cancelButton.textContent = 'Cancel'
        this.cancelButton.classList.add('cancel')
        this.container.append(this.cancelButton)
    }
    focus() {
        this.inputElem.focus()
    }
    getValue() {
        return this.inputElem.value
    }
    setValue(value) {
        this.inputElem.value = value
    }
    onInput() {
        this.emit('input', this.inputElem.value)
    }
}
