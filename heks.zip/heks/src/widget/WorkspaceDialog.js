class WorkspaceDialog extends Dialog {
    constructor(opts) {
        super(opts)

        this.workspaceTypes = new ButtonGroup({
            parentElem: this.container,
            selector: '.backend_type',
            onClick: () => {},
            items: [
                {id: 'LocalStorage', title: 'LocalStorage', selected: true},
                {id: 'IndexedDB', title: 'IndexedDB'},
                {id: 'FileSystem', title: 'FileSystem'},
            ],
        })

        this.nameInput = this.container.querySelector('.workspace_name')
    }
    show() {
        super.show()
        this.nameInput.focus()
        this.nameInput.select()
    }
    setName(value) {
        this.nameInput.value = value
    }
    setWorkspaceType(type) {
        this.workspaceTypes.setValue(type)
    }
    enableButtons() {
        this.workspaceTypes.enableAll()
    }
    disableButtons() {
        this.workspaceTypes.disableAll()
    }
    onOkClick() {
        const name = this.nameInput.value
        if (!this.app.workspaceMgr.validateName(name)) {
            return
        }
        this.nameInput.value = ''
        const type = this.workspaceTypes.getValue()
        this.hide()
        this.emit('ok', { name, type })
    }
}
