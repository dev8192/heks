class Widget extends EventEmitter {
    constructor(opts = {}) {
        super()
        this.opts = opts
        this.app = opts.app

        if (opts.useTemplate) {
            
        }
        if (opts.replacePlaceholder) {
            const placeholder = opts.parentElem.querySelector(opts.selector)
            const template = document.querySelector(".widgets")
            const clone = template.content.cloneNode(true)
            this.container = clone.firstElementChild
            placeholder.replaceWith(this.container)
            if (placeholder.classList.contains('hidden')) {
                this.container.classList.add('hidden')
            }
            return
        }

        if (opts.container) {
            this.container = opts.container
        } else {
            if (opts.parentElem) {
                this.parentElem = opts.parentElem
                if (opts.selector) {
                    this.container = this.parentElem.querySelector(opts.selector)
                } else {
                    this.build()
                    this.parentElem.append(this.container)
                }
            } else {
                this.build()
            }
        }
    }
    isVisible() {
        return !this.container.classList.contains('hidden')
    }
    build() {
        this.container = document.createElement('div')
    }
    show() {
        this.container.classList.remove('hidden')
    }
    hide() {
        this.container.classList.add('hidden')
    }
}
