class TextGrid extends Widget {
    constructor(opts) {
        super(opts)
        this.items = opts.items
        this.container.textContent = opts.text
        this.build()
    }
    build() {
        for (let i = 0; i < this.items.length; i++) {
            const div = document.createElement('div')
            div.textContent = this.items[i]
            this.container.append(div)
        }
    }
    highlight(text) {
        for (let i = 0; i < this.container.childElementCount; i++) {
            if (this.container.children[i].textContent === text) {
                this.container.children[i].style.backgroundColor = 'aqua'
            } else {
                this.container.children[i].style.backgroundColor = ''
            }
        }
    }
}
