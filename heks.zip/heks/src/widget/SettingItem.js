class SettingItem extends Widget {
    constructor(opts) {
        opts.container = document.createElement('label')
        opts.parentElem.append(opts.container)
        super(opts)
        this.settingsView = opts.settingsView
        this.settingObj = opts.settingObj
        this.value = this.settingObj.value
        this.build()
    }
    build() {
        if (this.settingObj.title) {
            const spanElem = document.createElement('span')
            spanElem.textContent = this.settingObj.title + ':'
            this.container.append(spanElem)
        }
    }
    getValue() {
        return this.value
    }
    setValue(value) {
        this.value = value
    }
}

class SettingsTextInput extends SettingItem {
    constructor(opts) {
        super(opts)
    }
    build() {
        super.build()
        this.inputElem = document.createElement('input')
        this.inputElem.type = 'text'
        this.inputElem.value = this.settingObj.value
        this.inputElem.addEventListener('input', this.onInput.bind(this))
        this.container.append(this.inputElem)
    }
    onInput() {
        this.setValue(this.inputElem.value)
    }
    prepare() {
        this.inputElem.value = this.value
    }
}

class NumberInput extends SettingItem {
    constructor(opts) {
        super(opts)
    }
    build() {
        super.build()
        this.inputElem = document.createElement('input')
        this.inputElem.type = 'number'
        this.inputElem.value = this.settingObj.value
        this.inputElem.addEventListener('input', this.onInput.bind(this))
        this.container.append(this.inputElem)
    }
    onInput() {
        console.log(this.inputElem.value)
        this.setValue(this.inputElem.value)
    }
    getValue() {
        if (this.value === '') {
            return NaN
        }
        return Number(this.value)
    }
    prepare() {
        this.inputElem.value = this.value
    }
}

class CheckboxInput extends SettingItem {
    constructor(opts) {
        super(opts)
    }
    build() {
        super.build()
        this.inputElem = document.createElement('input')
        this.inputElem.type = 'checkbox'
        this.inputElem.value = this.settingObj.value
        this.inputElem.addEventListener('input', this.onInput.bind(this))
        this.container.append(this.inputElem)
    }
    onInput() {
        this.setValue(this.inputElem.checked)
    }
    prepare() {
        this.inputElem.checked = this.value
    }
}

class ToggleInput extends SettingItem {
    constructor(opts) {
        super(opts)
    }
    build() {
        super.build()
        this.toggleElem = document.createElement('div')
        this.toggleElem.classList.add('toggle_input')
        this.setText()
        this.toggleElem.addEventListener('click', this.onClick.bind(this))
        this.container.append(this.toggleElem)
    }
    setText() {
        if (this.value) {
            this.toggleElem.textContent = this.settingObj.yesText
            this.toggleElem.classList.add('yes')
            this.toggleElem.classList.remove('no')
        } else {
            this.toggleElem.textContent = this.settingObj.noText
            this.toggleElem.classList.add('no')
            this.toggleElem.classList.remove('yes')
        }
    }
    onClick() {
        this.setValue(!this.value)
        this.setText()
    }
    prepare() {
        this.toggleElem.checked = this.value
    }
}

class ColorInput extends SettingItem {
    constructor(opts) {
        super(opts)
        if (opts.colorPicker) {
            this.colorPicker = opts.colorPicker
        } else {
            this.colorPicker = new ColorPicker({
                app: this.app,
                onInput: this.onInput.bind(this),
            })
        }
    }
    build() {
        super.build()
        this.colorNameElem = document.createElement('div')
        this.colorNameElem.classList.add('color_name')
        this.colorNameElem.textContent = this.value
        this.container.append(this.colorNameElem)
        this.colorElem = document.createElement('div')
        this.colorElem.classList.add('color_item')
        this.colorElem.classList.add('selected')
        this.colorElem.style.backgroundColor = this.settingObj.value
        this.colorElem.addEventListener('click', this.onColorInputClick.bind(this))
        this.container.append(this.colorElem)
    }
    onInput(value) {
        this.setValue(value)
    }
    onColorInputClick() {
        this.colorPicker.show(this.value)
    }
    prepare() {
        this.colorElem.style.backgroundColor = this.value
        this.colorNameElem.textContent = this.value
    }
}
