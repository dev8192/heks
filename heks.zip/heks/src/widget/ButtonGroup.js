class ButtonGroup extends Widget {
    static BaseValueStore = class {}
    static DatasetValueStore = class extends ButtonGroup.BaseValueStore {
        constructor() {
            super()
        }
        setValue(elem, value) {
            elem.dataset.value = value
        }
        getValue(elem) {
            if (elem.dataset.value) {
                return elem.dataset.value
            } else {
                return elem.textContent
            }
        }
    }
    static MapValueStore = class extends ButtonGroup.BaseValueStore {
        constructor() {
            super()
            this.map = new Map()
        }
        setValue(elem, value) {
            this.map.set(elem, value)
        }
        getValue(elem) {
            const value = this.map.get(elem)
            if (value) {
                return value
            } else {
                return elem.textContent
            }
        }
    }
    constructor(opts) {
        super(opts)
        this.valueToElementMap = new Map()
        this.itemsArr = []
        if (opts.items) {
            this.valueStore = new ButtonGroup.MapValueStore()
            this.build(opts.items)
        } else {
            this.valueStore = new ButtonGroup.DatasetValueStore()
        }
        for (const elem of this.container.children) {
            this.itemsArr.push(elem)
        }
        if (!opts.onClick) {
            throw new Error('ButtonGroup: callback must be specified')
        }
        this.onClickExternal = opts.onClick
        this.container.addEventListener('click', this.onClick.bind(this))
    }
    build(items) {
        this.container.innerHTML = ''
        for (const item of items) {
            const elem = document.createElement('button')
            elem.classList.add('option')
            elem.textContent = item.title
            this.valueStore.setValue(elem, item.id)
            this.container.append(elem)
            if (item.selected) {
                elem.classList.add('selected')
            }
            this.valueToElementMap.set(item.id, elem)
            this.itemsArr.push(elem)
        }
    }
    onClick(event) {
        if (!event.target.classList.contains('option')) {
            return
        }
        for (const item of this.itemsArr) {
            if (item === event.target) {
                item.classList.add('selected')
            } else {
                item.classList.remove('selected')
            }
        }
        const value = this.valueStore.getValue(event.target)
        this.onClickExternal(value)
    }
    disableAll() {
        for (const item of this.itemsArr) {
            item.disabled = true
        }
    }
    enableAll() {
        for (const item of this.itemsArr) {
            item.disabled = false
        }
    }
    getValue() {
        const elem = this.container.querySelector('.selected')
        return this.valueStore.getValue(elem)
    }
    setValue(value) {
        const oldElem = this.container.querySelector('.selected')
        if (oldElem) {
            oldElem.classList.remove('selected')
        }
        if (value) {
            const newElem = this.valueToElementMap.get(value)
            newElem.classList.add('selected')
            this.valueStore.setValue(newElem)
        }
    }
}
