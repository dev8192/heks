class BreadcrumbsWidget extends Widget {
    constructor(opts) {
        super(opts)

        this.onClick = this.onClick.bind(this)
        this.resumeEvents()
    }
    resumeEvents() {
        this.container.addEventListener('click', this.onClick)
    }
    pauseEvents() {
        this.container.removeEventListener('click', this.onClick)
    }
    show(event) {
        this.items = event.path.split('/')
        super.show()
        // debugger
        this.container.textContent = ''
        for (let i = 0; i < this.items.length; i++) {
            const segmentElem = document.createElement('div')
            segmentElem.textContent = this.items[i]
            segmentElem.classList.add('title')
            segmentElem.classList.add('dir_item')
            this.container.append(segmentElem)
            if (i !== (this.items.length - 1)) {
                const separatorElem = document.createElement('div')
                separatorElem.textContent = '/'
                separatorElem.classList.add('separator')
                this.container.append(separatorElem)
            }
        }
        this.container.lastElementChild.classList.add('selected')
        if (!event.isDir) {
            this.container.lastElementChild.classList.remove('dir_item')
            this.container.lastElementChild.classList.add('file_item')
        }
    }
    renameLastSegment(newName) {
        this.items[this.items.length - 1] = newName
        this.container.lastElementChild.textContent = newName
    }
    onClick(event) {
        let item = event.target
        if (!item.classList.contains('title')) {
            return
        }
        if (!item.nextElementSibling) {
            return
        }
        while (item.nextElementSibling) {
            item.nextElementSibling.remove()
            item.nextElementSibling.remove()
            this.items.pop()
        }
        const pathSegments = []
        for (const item of this.items) {
            pathSegments.push(item)
        }
        this.container.lastElementChild.classList.add('selected')
        this.emit('itemSelectionChanged', pathSegments.join('/'))
    }
}
