class TabsWidget extends Widget {
    constructor(opts = {}) {
        opts.selector = opts.selector || '.tabs_container'
        super(opts)
        
        this.tabContentElem = this.parentElem.querySelector('.tab_content')
        this.tabContentElem.addEventListener('click', this.onTabContentElemClick.bind(this))

        this.container.addEventListener('click', this.onTabsClick.bind(this))        
    }
    onTabContentElemClick(event) {
        // console.log('onTabContentElemClick')
        // if (event.target.classList.contains('cell')) {
        //     this.app.currentEditor.selectCell(event.target)
        // }
    }
    createTab(fileName, activate = false) {
        const tabElem = document.createElement('div')
        tabElem.classList.add('tab')
        tabElem.tabIndex = 0
        this.container.append(tabElem)

        if (activate) {
            const activeTab = this.container.querySelector('.active')
            if (activeTab) {
                activeTab.classList.remove('active')
            }
            tabElem.classList.add('active')
        }

        const fileNameElem = document.createElement('span')
        fileNameElem.classList.add('file_name')
        const maxFileNameLength = 15
        if (fileName.length > maxFileNameLength) {
            fileName = fileName.slice(0, maxFileNameLength - 3) + '...'
        }
        fileNameElem.textContent = fileName
        tabElem.append(fileNameElem)

        const closeFileButton = document.createElement('button')
        closeFileButton.classList.add('close')
        closeFileButton.textContent = 'x'
        tabElem.append(closeFileButton)
        return tabElem
    }
    onTabsClick(event) {
        if (event.target === this.container) {
            return
        }
        if (event.target.classList.contains('close')) {
            const tabElem = event.target.parentElement
            const editor = this.app.mainView.getEditor(tabElem)
            if (editor.isModified) {
                editor.printMessage('Cannot close tab')
                return
            }
            if (this.app.currentEditor === editor) {
                const tab = editor.tab.previousElementSibling
                this.switchToTab(tab)
            }
            this.app.mainView.removeEditor(editor)
            editor.tab.remove()
            if (!this.app.currentEditor) {
                this.tabContentElem.innerHTML = ''
                this.app.startDialog.show()
            }
            return
        }
        const tab = event.target.closest('.tab')
        this.switchToTab(tab)
    }
    switchToTab(newActive) {
        if (!newActive) {
            return null
        }
        const currentEditor = this.app.currentEditor
        if (currentEditor) {
            if (this.app.mainView.cellEditor) {
                if (this.app.mainView.cellEditor.currentPos !== 0) {
                    this.printMessage('Editing the cell value is not finished')
                    return false
                }
            }
            if (newActive === currentEditor.tab) {
                return newActive
            }
            currentEditor.tab.classList.remove('active')
            this.emit('tabClosed', newActive)
        }
        newActive.classList.add('active')
        this.emit('tabOpened', newActive)
    }
}
