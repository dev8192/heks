class OffsetView extends Widget {
    constructor(opts) {
        super(opts)
        this.offsetWidget = opts.offsetWidget
        this.currentOffsetStr = null
    }
    getOffsetSize() {
        return this.app.settings.get('offsetSize')
    }
    setCurrentValue(value) {
        const offSize = this.getOffsetSize()
        this.currentOffsetStr = '0x' + value.toString(16).padStart(offSize, '0')
    }
    updateView() {

    }
}

class OffsetInput extends OffsetView {
    constructor(opts) {
        super(opts)
        this.container.addEventListener('change', this.onChange.bind(this))
        this.kbdMgr = new KeyboardManager({
            container: this.container,
        })
        this.kbdMgr.addHandler('ArrowUp', this.onArrowUp.bind(this))
        this.kbdMgr.addHandler('ArrowDown', this.onArrowDown.bind(this))
    }
    onArrowUp(event) {
        this.offsetWidget.goToNext()
        event.preventDefault()
        event.stopPropagation()
    }
    onArrowDown(event) {
        this.offsetWidget.goToPrev()
        event.preventDefault()
        event.stopPropagation()
    }
    onChange() {
        const valueStr = this.container.value
        const valueStrLength = this.getOffsetSize() + 2
        if (valueStr.length !== valueStrLength) {
            this.resetView(`Expected ${valueStrLength} chars. Got ${valueStr.length}`)
            return
        }
        if (valueStr.slice(0, 2) !== '0x') {
            this.resetView('Must start with "0x" (hex value)')
            return
        }
        const valueNum = Number(valueStr)
        if (Number.isNaN(valueNum)) {
            this.resetView(`"${valueStr}" is not a valid hex value`)
            return
        }
        if (valueNum % 16 !== 0) {
            this.resetView('Must be a multiple of 16')
            return
        }
        this.currentOffsetStr = valueStr
        this.offsetWidget.updateButtonVisibility(valueNum)
        this.offsetWidget.emit('bufferOffsetChange', {
            origin: this.offsetWidget,
            offset: valueNum,
        })
    }
    resetView(msg) {
        this.printMessage(msg)
        this.container.value = this.currentOffsetStr
    }
    updateView(value) {
        this.setCurrentValue(value)
        this.container.value = this.currentOffsetStr
    }
}

class OffsetSpan extends OffsetView {
    constructor(opts) {
        super(opts)
    }
    updateView(value) {
        this.setCurrentValue(value)
        this.container.textContent = this.currentOffsetStr
    }
}

class OffsetWidget extends Widget {
    constructor(opts) {
        opts.selector = '.offset_widget'
        super(opts)

        this.getBufferOffsetExternal = opts.getBufferOffset
        this.getBufSizeExternal = opts.getBufSize
        this.getViewHeightExternal = opts.getViewHeight
        this.tabsWidget = opts.tabsWidget

        this.prevButton = this.container.querySelector('.scroll_to_prev')
        this.nextButton = this.container.querySelector('.scroll_to_next')
        this.startButton = this.container.querySelector('.scroll_to_start')
        this.endButton = this.container.querySelector('.scroll_to_end')

        this.offsetView = this.createOffsetView()

        this.goToPrev = this.goToPrev.bind(this)
        this.goToNext = this.goToNext.bind(this)
        this.goToStart = this.goToStart.bind(this)
        this.goToEnd = this.goToEnd.bind(this)

        this.prevButton.addEventListener('click', this.goToPrev)
        this.nextButton.addEventListener('click', this.goToNext)
        this.startButton.addEventListener('click', this.goToStart)
        this.endButton.addEventListener('click', this.goToEnd)

        this.tabsWidget.addListener('tabOpened', this.update.bind(this))
    }
    getBufferOffset() {
        const value = this.getBufferOffsetExternal()
        if (value % 16 !== 0) {
            throw new Error('Offset must be multiple of 16')
        }
        return value
    }
    getBufSize() {
        const value = this.getBufSizeExternal()
        const remainder = value % 16
        if (value % 16 === 0) {
            return value
        } else {
            return value - remainder + 16
        }
    }
    getViewHeight() {
        const value = this.getViewHeightExternal()
        return value
    }
    createOffsetView() {
        const offsetElem = this.container.querySelector('.offset_view')
        const opts = {
            app: this.app,
            container: offsetElem,
            offsetWidget: this,
        }
        if (offsetElem.tagName === 'INPUT') {
            return new OffsetInput(opts)
        } else {
            return new OffsetSpan(opts)
        }
    }
    goToPrev() {
        let value = this.getBufferOffset()
        if (value === 0) {
            return
        }
        value -= 16
        this.offsetView.updateView(value)
        this.updateButtonVisibility(value)
        this.emit('bufferOffsetChange', {
            origin: this,
            offset: value,
        })
    }
    goToNext() {
        let value = this.getBufferOffset()
        const lastPage = this.app.mainView.editorView.computeLastPage()
        if (value === lastPage) {
            return
        }
        value += 16
        this.offsetView.updateView(value)
        this.updateButtonVisibility(value)
        this.emit('bufferOffsetChange', {
            origin: this,
            offset: value,
        })
    }
    goToStart() {
        let value = this.getBufferOffset()
        if (value === 0) {
            return
        }
        value = 0
        this.offsetView.updateView(value)
        this.updateButtonVisibility(value)
        this.emit('bufferOffsetChange', {
            origin: this,
            offset: value,
        })
    }
    goToEnd() {
        let value = this.getBufferOffset()
        const lastPage = this.app.mainView.editorView.computeLastPage()
        if (value === lastPage) {
            return
        }
        value = lastPage
        this.offsetView.updateView(value)
        this.updateButtonVisibility(value)
        this.emit('bufferOffsetChange', {
            origin: this,
            offset: value,
        })
    }
    updateButtonVisibility(value) {
        if (value === 0) {
            this.prevButton.disabled = true
            this.startButton.disabled = true
        } else {
            this.prevButton.disabled = false
            this.startButton.disabled = false
        }
        if (value === this.app.mainView.editorView.computeLastPage()) {
            this.nextButton.disabled = true
            this.endButton.disabled = true
        } else {
            this.nextButton.disabled = false
            this.endButton.disabled = false
        }
    }
    update() {
        const value = this.getBufferOffset()
        this.offsetView.updateView(value)
        this.updateButtonVisibility(value)
    }
}
