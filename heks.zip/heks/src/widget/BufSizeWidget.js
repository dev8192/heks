class BufSizeWidget extends Widget {
    constructor(opts) {
        opts.selector = opts.selector || '.buffer_size_widget'
        super(opts)
        // this.container.textContent = opts.text
    }
    setText(text) {
        this.container.textContent = text
    }
    getText() {
        return this.container.textContent
    }
}
