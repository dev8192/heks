class CellEditor {
    static hexDigits = {
        'Digit0': '0',
        'Digit1': '1',
        'Digit2': '2',
        'Digit3': '3',
        'Digit4': '4',
        'Digit5': '5',
        'Digit6': '6',
        'Digit7': '7',
        'Digit8': '8',
        'Digit9': '9',
        'KeyA': 'A',
        'KeyB': 'B',
        'KeyC': 'C',
        'KeyD': 'D',
        'KeyE': 'E',
        'KeyF': 'F',
    }
    constructor(opts) {
        this.app = opts.app
        this.editorView = opts.editorView
        this.kbdMgr = opts.kbdMgr
        this.printMessage = opts.printMessage

        this.enabled = true
        this.currentPos = 0

        this.onArrowUp = this.onArrowUp.bind(this)
        this.onArrowDown = this.onArrowDown.bind(this)
        this.onKeyDown = this.onKeyDown.bind(this)

        this.commonHandlers = {
            'ArrowUp': this.onArrowUp,
            'ArrowDown': this.onArrowDown,
        }
        for (const key of Object.keys(this.constructor.hexDigits)) {
            this.commonHandlers[key] = this.onKeyDown
        }
    }
    iterateCommonHandlers(callback) {
        for (const [name, handler] of Object.entries(this.commonHandlers)) {
            callback(name, handler)
        }
    }
    enable() {
        this.enabled = true
        this.iterateCommonHandlers((name, handler) => {
            this.kbdMgr.addHandler(name, handler)
        })
    }
    disable() {
        this.enabled = false
        this.iterateCommonHandlers((name) => {
            this.kbdMgr.removeHandler(name)
        })
    }
    onArrowUp() {
        const editor = this.app.currentEditor
        if (editor.currentCellIdx === null) {
            return
        }
        let byte = editor.buffer.getUint8(editor.currentCellIdx)
        if (byte === 255) {
            this.printMessage('Value cannot be more than 255')
            return
        }
        byte++
        editor.buffer.setUint8({
            index: editor.currentCellIdx,
            value: byte,
            origin: this.app.mainView.editorView,
        })
        const elem = this.editorView.posMgr.getElem(editor.currentCellIdx)
        elem.textContent = byte.toString(16).padStart(2, '0')
        editor.isModified = true
    }
    onArrowDown() {
        const editor = this.app.currentEditor
        if (editor.currentCellIdx === null) {
            return
        }
        let byte = editor.buffer.getUint8(editor.currentCellIdx)
        if (byte === 0) {
            this.printMessage('Value cannot be less than 0')
            return
        }
        byte--
        editor.buffer.setUint8({
            index: editor.currentCellIdx,
            value: byte,
            origin: this.app.mainView.editorView,
        })
        const elem = this.editorView.posMgr.getElem(editor.currentCellIdx)
        elem.textContent = byte.toString(16).padStart(2, '0')
        editor.isModified = true
    }
    onKeyDown(event) {
        console.log(444)
        if (!this.enabled) return
        this.setValue(event.code)
        event.stopPropagation()
    }
    setValue(code) {
        const index = this.app.currentEditor.currentCellIdx
        if (index === null) {
            return
        }
        const posMgr = this.app.mainView.editorView.posMgr
        const elem = posMgr.getElem(index)
        const digit = this.constructor.hexDigits[code]
        if (this.currentPos === 0) {
            this.doSetValue(elem, digit, elem.textContent[1])
            this.currentPos = 1
        } else {
            this.doSetValue(elem, elem.textContent[0], digit)
            this.currentPos = 0
            const val = parseInt(elem.textContent, 16).toString()
            this.app.currentEditor.buffer.setUint8({
                index,
                value: val,
                origin: this.app.mainView.editorView,
            })
        }
    }
    doSetValue(elem, digit1, digit2) {
        elem.textContent = digit1 + digit2
        if (this.app.settings.get('upperCase')) {
            elem.textContent = elem.textContent.toUpperCase()
        } else {
            elem.textContent = elem.textContent.toLowerCase()
        }
    }
}