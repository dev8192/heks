class WorkspaceInfo extends Widget {
    constructor(opts) {
        super(opts)
        
        this.nameElem = this.container.querySelector('.name')
        this.backendElem = this.container.querySelector('.backend')
        this.typeElem = this.container.querySelector('.type')
    }
    populate(workspaceObj) {
        this.nameElem.textContent = workspaceObj.name
        this.backendElem.textContent = workspaceObj.backend
        this.typeElem.textContent = workspaceObj.type
    }
}
