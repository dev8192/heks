class FileInfo {
    constructor(opts) {
        this.app = opts.app
        this.type = null
    }
    getFileName() {
        return this.app.settings.get('defaultFileName')
    }
    getFileSize() {
        return this.app.settings.get('defaultBufSize')
    }
    getOffset() {
        return this.app.settings.get('defaultOffset')
    }
}

class OnDiskFile extends FileInfo {
    constructor(opts) {
        super(opts)
        this.type = 'on_disk'
        this.fileHandle = opts.fileHandle
        this.fileObj = null
    }
    async init() {
        this.fileObj = await this.fileHandle.getFile()
        return this
    }
    getFileName() {
        if (this.fileObj) {
            return this.fileObj.name
        }
        super.getFileName()
    }
    getFileSize() {
        if (this.fileObj) {
            return this.fileObj.size
        }
        super.getFileSize()
    }
}

class InMemoryFile extends FileInfo {
    constructor(opts) {
        super(opts)
        this.type = 'in_memory'
        if (opts.bufSize === undefined) {
            if (opts.buffer) {
                this.bufSize = opts.buffer.byteLength
            }
        } else {
            this.bufSize = opts.bufSize
        }
        this.fileName = opts.fileName
        this.startOffset = opts.startOffset
        if (opts.startOffset === undefined) {
            this.startOffset = this.getOffset()
        } else {
            this.startOffset = opts.startOffset
        }
    }
}
