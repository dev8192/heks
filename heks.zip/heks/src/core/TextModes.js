
class TextModes {
    addStyle(modeId, color) {
        this.app.styleMgr.addStyle(`
            .editor_view .cell.${color} {
                background-color: ${color};
            }
        `)
    }
    constructor(opts) {
        this.app = opts.app
        this.textModes = opts.textModes
        this.textModeMaps = []
        const options = []
        for (const textMode of this.textModes) {
            this.addStyle(textMode.id, textMode.color)
            const map = {}
            options.push({
                text: textMode.name,
                onClick: (checked) => {
                    this.onTextModeChange(checked, map)
                }
            })
            for (const value of textMode.values) {
                if (typeof value === 'number') {
                    map[value] = this.createMapping(textMode, value)
                } else if (Array.isArray(value)) {
                    for (let i = value[0]; i <= value[1]; i++) {
                        map[i] = this.createMapping(textMode, i)
                    }
                } else {
                    throw new Error('Invalid value in text mode')
                }
            }
            this.textModeMaps.push(map)
        }
        this.textModesWidget = new CheckboxGroup({
            options,
            container: opts.parentElem.querySelector('.text_modes'),
            onMainCheckboxClick: (checked) => {
                for (const map of this.textModeMaps) {
                    this.onTextModeChange(checked, map)
                }
            }
        })
    }
    createMapping(textMode, byte) {
        if (encodings[textMode.charset] && encodings[textMode.charset][byte]) {
            return {
                value: encodings[textMode.charset][byte],
                color: textMode.color,
            }
        }
        return {
            value: String.fromCharCode(byte),
            color: textMode.color,
        }
    }
    onTextModeChange(checked, map) {
        if (checked) {
            this.app.mainView.editorView.iterateCells((cell, index) => {
                const byte = this.app.currentEditor.buffer.getUint8(index)
                let found = map[byte]
                if (found) {
                    cell.textContent = found.value
                    this.app.styleMgr.selectCell(cell, found.color)
                }
            })
        } else {
            this.app.mainView.editorView.iterateCells((cell, index) => {
                const byte = this.app.currentEditor.buffer.getUint8(index)
                if (map[byte]) {
                    cell.textContent = byte.toString(16).padStart(2, '0')
                    this.app.styleMgr.clearSelection(cell, map[byte].color)
                }
            })
        }
    }
}
