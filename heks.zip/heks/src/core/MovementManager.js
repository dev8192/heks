class MovementManager extends EventEmitter {
    static kbdPresets = [
        {
            id: 'arrows',
            title: 'Arrows',
            keys: {
                up: 'ArrowUp',
                down: 'ArrowDown',
                left: 'ArrowLeft',
                right: 'ArrowRight',
            },
        },
        {
            id: 'numpad',
            title: 'Numpad',
            keys: {
                up: 'Numpad8',
                down: 'Numpad2',
                left: 'Numpad4',
                right: 'Numpad6',
            },
        },
        {
            id: 'wasd',
            title: 'WASD',
            keys: {
                up: 'KeyW',
                down: 'KeyS',
                left: 'KeyA',
                right: 'KeyD',
            },
        },
        {
            id: 'none',
            title: 'None',
        },
    ]
    constructor(opts) {
        super()
        this.app = opts.app
        this.posMgr = opts.posMgr
        this.kbdMgr = opts.kbdMgr
        this.printMessage = opts.printMessage

        this.moveCursorUp = this.moveCursorUp.bind(this)
        this.moveCursorDown = this.moveCursorDown.bind(this)
        this.moveCursorLeft = this.moveCursorLeft.bind(this)
        this.moveCursorRight = this.moveCursorRight.bind(this)

        this.currentPreset = null

        const presetName = this.app.settings.get('navPreset')
        this.setHandlers(presetName)

        this.onHomeKeyDown = this.onHomeKeyDown.bind(this)
        this.onEndKeyDown = this.onEndKeyDown.bind(this)

        this.commonHandlers = {
            'Home': this.onHomeKeyDown,
            'End': this.onEndKeyDown,
        }
        this.iterateCommonHandlers((name, handler) => {
            this.kbdMgr.addHandler(name, handler)
        })
    }
    iterateCommonHandlers(callback) {
        for (const [name, handler] of Object.entries(this.commonHandlers)) {
            callback(name, handler)
        }
    }
    addHandlers(keys) {
        if (!keys) return
        this.kbdMgr.addHandler(keys.up, this.moveCursorUp)
        this.kbdMgr.addHandler(keys.down, this.moveCursorDown)
        this.kbdMgr.addHandler(keys.left, this.moveCursorLeft)
        this.kbdMgr.addHandler(keys.right, this.moveCursorRight)
    }
    removeHandlers(keys) {
        if (!keys) return
        this.kbdMgr.removeHandler(keys.up)
        this.kbdMgr.removeHandler(keys.down)
        this.kbdMgr.removeHandler(keys.left)
        this.kbdMgr.removeHandler(keys.right)
    }
    enable() {
        if (this.currentPreset) {
            this.addHandlers(this.currentPreset.keys)
        }
        this.iterateCommonHandlers((name, handler) => {
            this.kbdMgr.addHandler(name, handler)
        })
    }
    disable() {
        if (this.currentPreset) {
            this.removeHandlers(this.currentPreset.keys)
        }
        this.iterateCommonHandlers((name) => {
            this.kbdMgr.removeHandler(name)
        })
    }
    getPreset(presetName) {
        for (const preset of this.constructor.kbdPresets) {
            if (preset.id === presetName) {
                preset.selected = true
                return preset
            }
        }
    }
    setHandlers(presetName) {
        const newPreset = this.getPreset(presetName)
        if (!this.kbdMgr) {
            return
        }
        if (this.currentPreset) {
            this.removeHandlers(this.currentPreset.keys)
        }
        this.currentPreset = newPreset
        this.addHandlers(this.currentPreset.keys)
    }
    canMoveCursor() {
        const editor = this.app.currentEditor
        if (editor.currentCellIdx === null) {
            this.printMessage('You first need to select a cell')
            return false
        }
        return true
    }
    isAddCellButton(elem) {
        return elem.firstElementChild && elem.firstElementChild.classList.contains('add_cell')
    }
    isOccupied(elem) {
        return elem.classList.contains('occupied')
    }
    isFirstRow(cell) {
        const row = cell.parentElement
        const gridElem = row.parentElement
        const idx = this.app.settings.get('showCols') ? 1 : 0
        return row === gridElem.children[idx]
    }
    isLastRow(cell) {
        const row = cell.parentElement
        const gridElem = row.parentElement
        return row === gridElem.lastElementChild
    }
    isLastRow1() {
        const editor = this.app.currentEditor
        const idx1 = editor.currentCellIdx - editor.currentCellIdx % 16
        const idx2 = editor.buffer.bufSize - editor.buffer.bufSize % 16
        return idx1 === idx2
    }
    onHomeKeyDown(event) {
        if (event.ctrlKey) {
            this.moveCursorFirstPage()
        } else {
            this.moveCursorLineStart()
        }
    }
    onEndKeyDown(event) {
        if (event.ctrlKey) {
            this.moveCursorLastPage()
        } else {
            this.moveCursorLineEnd()
        }
    }
    moveCursorFirstPage() {
        console.log('moveCursorFirstPage')
    }
    moveCursorLastPage() {
        console.log('moveCursorLastPage')
    }
    getMaxCellIdx() {
        let bufSize = this.app.currentEditor.buffer.bufSize - 1
        if (this.app.settings.get('showAddCellButton')) {
            bufSize++
        }
        return bufSize
    }
    moveCursorUp() {
        if (!this.canMoveCursor()) {
            return
        }
        const editor = this.app.currentEditor
        let currentCell = this.posMgr.getElem(editor.currentCellIdx)
        if (!currentCell) {
            let index = editor.currentCellIdx
            const offset = index - index % 16
            this.emit('bufferOffsetChange', {origin: this, offset})
            currentCell = this.posMgr.getElem(editor.currentCellIdx)
        }
        const posX = this.posMgr.getX(currentCell)
        const selectedCellIdx = editor.currentCellIdx - 16
        if (selectedCellIdx < 0) {
            this.printMessage('Cannot move cursor up')
            return
        }
        editor.currentCellIdx = selectedCellIdx
        if (this.isFirstRow(currentCell)) {
            const offset = editor.buffer.bufferOffset - 16
            this.emit('bufferOffsetChange', {origin: this, offset})
        } else {
            const row = currentCell.parentElement
            const selectedCell = row.previousElementSibling.children[posX]
            if (!selectedCell) {
                this.printMessage('Cannot move cursor up')
                return
            }
            if (this.posMgr.getY(currentCell) === 0) {
                this.printMessage('Cannot move cursor up')
                return
            }
            this.app.styleMgr.clearSelection(currentCell)
            this.app.styleMgr.selectCell(selectedCell)
        }
    }
    moveCursorDown() {
        if (!this.canMoveCursor()) {
            return
        }
        const editor = this.app.currentEditor
        let currentCell = this.posMgr.getElem(editor.currentCellIdx)
        if (!currentCell) {
            let index = editor.currentCellIdx
            const offset = index - index % 16 + 16
            this.emit('bufferOffsetChange', {origin: this, offset})
            currentCell = this.posMgr.getElem(editor.currentCellIdx)
        }
        const selectedCellIdx = editor.currentCellIdx + 16
        let upperBound = editor.buffer.bufSize
        if (this.app.settings.get('showAddCellButton')) {
            upperBound++
        }
        if (selectedCellIdx >= upperBound) {
            this.printMessage('Cannot move cursor down')
            return
        }
        if (this.isLastRow(currentCell)) {
            editor.currentCellIdx = null
            const offset = editor.buffer.bufferOffset + 16
            this.emit('bufferOffsetChange', {origin: this, offset})
        }
        if (editor.currentCellIdx < editor.buffer.bufSize) {
            this.app.styleMgr.clearSelection(currentCell)
        }
        editor.currentCellIdx = selectedCellIdx
        if (editor.currentCellIdx < editor.buffer.bufSize) {
            const selectedCell = this.posMgr.getElem(selectedCellIdx)
            this.app.styleMgr.selectCell(selectedCell)
        }
    }
    moveCursorLeft() {
        if (!this.canMoveCursor()) {
            return
        }
        const editor = this.app.currentEditor
        if (editor.currentCellIdx === 0) {
            this.printMessage('Cannot move cursor left')
            return
        }
        const currentCell = this.posMgr.getElem(editor.currentCellIdx)
        let selectedCell = currentCell.previousElementSibling
        if (!selectedCell) {
            const row = currentCell.parentElement
            selectedCell = row.previousElementSibling.lastElementChild
        }

        if (editor.currentCellIdx < editor.buffer.bufSize) {
            this.app.styleMgr.clearSelection(currentCell)
        }
        editor.currentCellIdx--
        if (editor.currentCellIdx < editor.buffer.bufSize) {
            this.app.styleMgr.selectCell(selectedCell)
        }
    }
    moveCursorLineStart() {
        if (!this.canMoveCursor()) {
            return
        }
        const editor = this.app.currentEditor
        let currentCell = this.posMgr.getElem(editor.currentCellIdx)
        const selectedCell = currentCell.parentElement.firstElementChild
        if (!selectedCell) {
            this.printMessage('Cannot move cursor to the start')
            return
        }
        this.app.styleMgr.clearSelection(currentCell)
        editor.currentCellIdx -= editor.currentCellIdx % 16
        this.app.styleMgr.selectCell(selectedCell)
    }
    moveCursorRight() {
        if (!this.canMoveCursor()) {
            return
        }
        const editor = this.app.currentEditor
        if (editor.currentCellIdx >= this.getMaxCellIdx()) {
            this.printMessage('Cannot move cursor right')
            return
        }
        const currentCell = this.posMgr.getElem(editor.currentCellIdx)
        let selectedCell = currentCell.nextElementSibling
        if (!selectedCell) {
            const row = currentCell.parentElement
            selectedCell = row.nextElementSibling.firstElementChild
        }
        if (this.isAddCellButton(selectedCell)) {
            this.printMessage('Cannot move cursor right')
            return
        }
        if (editor.currentCellIdx < editor.buffer.bufSize) {
            this.app.styleMgr.clearSelection(currentCell)
        }
        if (editor.currentCellIdx < editor.buffer.bufSize) {
            editor.currentCellIdx++
            this.app.styleMgr.selectCell(selectedCell)
        } else {
            this.printMessage('Cannot move cursor right')
        }
    }
    moveCursorLineEnd() {
        if (!this.canMoveCursor()) {
            return
        }
        const editor = this.app.currentEditor
        const currentCell = this.posMgr.getElem(editor.currentCellIdx)
        let selectedCell
        let selectedCellIdx
        const currentRowFirstCellIdx = editor.currentCellIdx - editor.currentCellIdx % 16
        const lastRowFirstCellIdx = editor.buffer.bufSize - editor.buffer.bufSize % 16
        if (currentRowFirstCellIdx === lastRowFirstCellIdx) {
            selectedCellIdx = editor.buffer.bufSize - 1
            selectedCell = this.posMgr.getElem(selectedCellIdx)
        } else {
            selectedCellIdx = currentRowFirstCellIdx + 15
            selectedCell = currentCell.parentElement.lastElementChild
        }
        if (this.isAddCellButton(selectedCell)) {
            if (selectedCellIdx - editor.currentCellIdx === 1) {
                this.printMessage('Cannot move cursor right')
                return
            } else {
                selectedCellIdx--
                selectedCell = selectedCell.previousElementSibling
            }
        }
        this.app.styleMgr.clearSelection(currentCell)
        editor.currentCellIdx = selectedCellIdx
        this.app.styleMgr.selectCell(selectedCell)
    }
}
