class Buffer {
    constructor(opts) {
        this.app = opts.app
        if (opts.buffer !== undefined) {
            const remainder = opts.buffer.byteLength % 16
            if (remainder !== 0) {
                const newBufSize = opts.buffer.byteLength - remainder + 16
                this.realloc(newBufSize, opts.buffer)
            } else {
                this.buffer = opts.buffer
                this.dataView = new DataView(this.buffer)
            }
            this.bufSize = opts.buffer.byteLength
        } else if (opts.bufSize !== undefined) {
            const bufSize = Math.ceil(opts.bufSize / 16) * 16
            this.buffer = new ArrayBuffer(bufSize)
            this.bufSize = opts.bufSize
            this.dataView = new DataView(this.buffer)
        } else {
            throw new Error('Either opts.buffer or opts.bufSize must be specified')
        }
        this.bufferOffset = 0
    }
    toString() {
        let line = ''
        for (let i = 0; i < this.bufSize; i++) {
            line += this.dataView[i].toString(16).padStart(2, '0')
            if ((i + 1) % 16 === 0) {
                line += '\n'
            } else {
                line += ' '
            }
        }
        return line
    }
    print() {
        console.log(this.toString())
    }
    getBuffer() {
        return new DataView(this.buffer, 0, this.bufSize)
    }

    setUint8(event) {
        this.dataView.setUint8(event.index, event.value, event.littleEndian)
        this.app.emit('bufferValueChanged', event)
    }
    setUint16(byteOffset, event, littleEndian) {
        this.dataView.setUint16(byteOffset, event.value, littleEndian)
        this.app.emit('bufferValueChanged', event)
    }
    setUint32(byteOffset, event, littleEndian) {
        this.dataView.setUint32(byteOffset, event.value, littleEndian)
        this.app.emit('bufferValueChanged', event)
    }
    setUint64(byteOffset, event, littleEndian) {
        this.dataView.setUint64(byteOffset, event.value, littleEndian)
        this.app.emit('bufferValueChanged', event)
    }
    setInt8(byteOffset, event, littleEndian) {
        this.dataView.setInt8(byteOffset, event.value, littleEndian)
        this.app.emit('bufferValueChanged', event)
    }
    setInt16(byteOffset, event, littleEndian) {
        this.dataView.setInt16(byteOffset, event.value, littleEndian)
        this.app.emit('bufferValueChanged', event)
    }
    setInt32(byteOffset, event, littleEndian) {
        this.dataView.setInt32(byteOffset, event.value, littleEndian)
        this.app.emit('bufferValueChanged', event)
    }
    setInt64(byteOffset, event, littleEndian) {
        this.dataView.setInt64(byteOffset, event.value, littleEndian)
        this.app.emit('bufferValueChanged', event)
    }
    setFloat16(byteOffset, event, littleEndian) {
        this.dataView.setFloat16(byteOffset, event.value, littleEndian)
        this.app.emit('bufferValueChanged', event)
    }
    setFloat32(byteOffset, event, littleEndian) {
        this.dataView.setFloat32(byteOffset, event.value, littleEndian)
        this.app.emit('bufferValueChanged', event)
    }
    setFloat64(byteOffset, event, littleEndian) {
        this.dataView.setFloat64(byteOffset, event.value, littleEndian)
        this.app.emit('bufferValueChanged', event)
    }

    getUint8(byteOffset, littleEndian) {
        return this.dataView.getUint8(byteOffset, littleEndian)
    }
    getUint16(byteOffset, littleEndian) {
        return this.dataView.getUint16(byteOffset, littleEndian)
    }
    getUint32(byteOffset, littleEndian) {
        return this.dataView.getUint32(byteOffset, littleEndian)
    }
    getUint64(byteOffset, littleEndian) {
        return this.dataView.getBigUint64(byteOffset, littleEndian)
    }
    getInt8(byteOffset, littleEndian) {
        return this.dataView.getInt8(byteOffset, littleEndian)
    }
    getInt16(byteOffset, littleEndian) {
        return this.dataView.getInt16(byteOffset, littleEndian)
    }
    getInt32(byteOffset, littleEndian) {
        return this.dataView.getInt32(byteOffset, littleEndian)
    }
    getInt64(byteOffset, littleEndian) {
        return this.dataView.getBigInt64(byteOffset, littleEndian)
    }
    getFloat16(byteOffset, littleEndian) {
        return this.dataView.getFloat16(byteOffset, littleEndian)
    }
    getFloat32(byteOffset, littleEndian) {
        return this.dataView.getFloat32(byteOffset, littleEndian)
    }
    getFloat64(byteOffset, littleEndian) {
        return this.dataView.getFloat64(byteOffset, littleEndian)
    }

    extendBuffer(increment = 16) {
        const newBufSize = this.buffer.byteLength + increment
        this.realloc(newBufSize, this.buffer)
    }
    realloc(newBufSize, oldBuffer) {
        const newBuffer = new ArrayBuffer(newBufSize)
        const uint8Arr = new Uint8Array(newBuffer)
        uint8Arr.set(new Uint8Array(oldBuffer))
        this.buffer = newBuffer
        this.dataView = new DataView(newBuffer)
    }
}