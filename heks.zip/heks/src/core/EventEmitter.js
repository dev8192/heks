class EventEmitter {
    constructor() {
        this.events = {}
    }
    addListener(event, listener) {
        if (!this.events[event]) {
            this.events[event] = []
        }
        this.events[event].push(listener)
    }
    removeListener(event, listener) {
        if (!this.events[event]) {
            return
        }
        const listeners = []
        for (const item of this.events[event]) {
            if (item !== listener) {
                listeners.push(item)
            }
        }
        this.events[event] = listeners
    }
    emit(event, ...args) {
        if (event === 'bufferValueChanged') {
            // debugger
        }
        console.log(event)
        if (!this.events[event]) {
            return
        }
        const listeners = this.events[event]
        // console.log(listeners)
        for (let i = 0; i < listeners.length; i++) {
            listeners[i](...args)
        }
    }
}