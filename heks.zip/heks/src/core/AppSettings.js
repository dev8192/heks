class BaseSettingsStore {
    constructor(opts) {
        this.parentWidget = opts.parentWidget
    }
    add(name, value) {
    }
    getValue(name) {
    }
    setValue(name, value) {
    }
    iterate(callback) {
    }
    write() {
    }
}

class ArraySettingsStore extends BaseSettingsStore {
    constructor(opts) {
        super(opts)
        this.settingsArr = []
    }
    add(name, value) {
        this.settingsArr.push(value)
    }
    getValue(name) {
        for (const obj of this.settingsArr) {
            if (obj.id === name) {
                return obj.value
            }
        }
    }
    setValue(name, value) {
        for (const obj of this.settingsArr) {
            if (obj.id === name) {
                obj.value = value
            }
        }
    }
    iterate(callback) {
        for (const obj of this.settingsArr) {
            const ret = callback(obj, obj.id)
            if (ret) {
                break
            }
        }
    }
}

class ArraySettingsStoreLS extends ArraySettingsStore {
    constructor(opts) {
        super(opts)        
    }
}

class ObjectSettingsStore extends BaseSettingsStore {
    constructor(opts) {
        super(opts)
        this.settingsObj = {}
    }
    add(name, value) {
        this.settingsObj[name] = value
    }
    getValue(name) {
        return this.settingsObj[name].value
    }
    setValue(name, value) {
        if (name === 'showCols') {
            debugger
        }
        console.log('setValue', name, value)
        this.settingsObj[name].value = value
    }
    iterate(callback) {
        for (const [id, obj] of Object.entries(this.settingsObj)) {
            const ret = callback(obj, id)
            if (ret) {
                break
            }
        }
    }
}

class ObjectSettingsStoreLS extends ObjectSettingsStore {
    constructor(opts) {
        super(opts)
        localStorage.removeItem('heks_settings')
        const str = localStorage.getItem('heks_settings')
        if (str) {
            this.settingsObj = JSON.parse(str)
            this.parentWidget.completed = true
        } else {
            this.settingsObj = {}
            this.parentWidget.completed = false
        }
    }
    write() {
        const str = JSON.stringify(this.settingsObj)
        localStorage.setItem('heks_settings', str)
    }
}

class AppSettings extends EventEmitter {
    constructor(opts) {
        super()
        this.app = opts.app

        // this.store = new ArraySettingsStore({
        //     parentWidget: this,
        // })
        // this.store = new ArraySettingsStoreLS({
        //     parentWidget: this,
        // })
        this.store = new ObjectSettingsStore({
            parentWidget: this,
        })
        // this.store = new ObjectSettingsStoreLS({
        //     parentWidget: this,
        // })

        this.app.addListener('optionsProcessed', this.init.bind(this))
    }
    init() {
        this.store.write()
    }
    contribute(arr) {
        if (this.completed) {
            return
        }
        for (const obj of arr) {
            obj.value = obj.defaultValue
            this.store.add(obj.id, obj)
        }
    }
    iterateSettings(callback) {
        this.store.iterate(callback)
    }
    processOptions(opts) {
        this.store.iterate((obj, id) => {
            if (obj.globalOpt && opts[id] !== undefined) {
                obj.value = opts[id]
            }
        })
    }
    get(name) {
        return this.store.getValue(name)
    }
    set(name, value) {
        this.store.setValue(name, value)
        this.emit(name + 'Changed', value)
    }
    writeSettings() {
        this.store.write()
    }
    static isFileNameValid(fileName) {
        if (fileName.length !== fileName.trim().length) {
            console.log('Leading / trailing whitespace is not allowed in file name')
            return false
        }
        if (fileName.length === 0) {
            console.log('Empty file name is not allowed')
            return false
        }
        if (fileName.length > 20) {
            console.log('File name is too long')
            return false
        }
        return true
    }
    static isValidColor(color) {
        const colorValue = Number(color)
        if (colorValue >= 0 && colorValue <= 0xFFFFFF) {
            return true
        }
        if (ColorPicker.cssColors.includes(color)) {
            return true
        }
        console.log('Not a valid CSS color')
        return false
    }
}
