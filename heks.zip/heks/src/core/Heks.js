class Heks extends EventEmitter {
    static settingContributions = [
        {
            id: 'defaultFileName',
            title: 'Default file name',
            type: 'text_input',
            defaultValue: 'example.txt',
            order: 400,
            validate: AppSettings.isFileNameValid,
        },
        {
            id: 'maxBufSize',
            title: 'Max buffer size',
            type: 'number_input',
            // defaultValue: 1073741824, // 2 ** 30
            defaultValue: 1024, // 2 ** 10
            order: 700,
        },
        {
            id: 'defaultBufSize',
            title: 'Default buffer size',
            type: 'number_input',
            defaultValue: 256,
            order: 700,
        },
        {
            id: 'startView',
            title: 'Start view',
            type: 'toggle',
            // defaultValue: 'select_mode',
            defaultValue: 'start_dialog',
            globalOpt: true,
            order: 700,
        },
        {
            id: 'singlePageApplication',
            title: 'Single page application',
            type: 'toggle',
            defaultValue: true,
            globalOpt: true,
            order: 700,
        },
        {
            id: 'useHistoryApi',
            title: 'Use History API',
            type: 'toggle',
            defaultValue: false,
            globalOpt: true,
            order: 700,
        },
    ]
    constructor(opts = {}) {
        super()
        
        this.printMessage = this.printMessage.bind(this)

        this.opts = opts

        this.views = {}

        this.widgets = {}
        this.prepateWidgets()

        this.fileInfo = null
        this.currentView = null
        this.previousView = null

        if (document.title) {
            this.title = document.title
        } else {
            this.title = 'Heks'
        }

        this.settings = new AppSettings({
            app: this,
        })
        this.settings.contribute(Heks.settingContributions)

        this.messageWidget = new MessageWidget()
        this.startDialog = new StartDialog({
            app: this,
            parentElem: document.body,
            selector: '.start_dialog',
        })
        this.newFileDialog = new NewFileDialog({
            app: this,
            parentElem: document.body,
            selector: '.new_file_dialog',
        })
        this.fileExplorer = new FileExplorer({
            app: this,
            parentElem: document.body,
            selector: '.file_explorer.view',
        })

        // // this.saveFileDialog = new SimpleDialog({
        // this.saveFileDialog = new DialogWithCountdown({
        //     app: this,
        //     container: (() => {
        //         const elem = document.createElement('div')
        //         elem.classList.add('view')
        //         elem.classList.add('simple_view')
        //         elem.classList.add('hidden')
        //         document.body.insertBefore(elem, this.mainView.container)
        //         return elem
        //     })()
        // })

        this.wasmProgram = new WasmProgram()

        this.wasmParser = new WasmParser({
            app: this,
        })

        this.wasmRunner = new WasmRunner({
            app: this,
            parentElem: document.body,
            selector: '.wasm_runner',
        })
        
        this.saveFileDialog = new SaveFileDialog({
            app: this,
            parentElem: document.body,
            selector: '.save_file_dialog',
        })

        this.workspaceMgr = new WorkspaceManager({
            app: this.app,
            printMessage: this.printMessage,
        })
        this.workspaceMgr.addListener('workspaceOpened', this.onWorkspaceOpened.bind(this))
        
        this.workspaceView = new WorkspaceView({
            app: this,
            parentElem: document.body,
            selector: '.workspace_view',
        })

        this.wasmView = new WasmView({
            app: this,
            parentElem: document.body,
            selector: '.wasm_view',
        })

        this.wasmView = new WasmBuilder({
            app: this,
            parentElem: document.body,
            selector: '.wasm_builder',
        })

        this.settingsView = new SettingsView({
            app: this,
            printMessage: this.printMessage,
            settings: this.settings,
            parentElem: document.body,
            selector: '.settings_view',
        })
        this.mainView = new MainView({
            app: this,
            parentElem: document.body,
            selector: '.main_view',
            settings: this.settings,
        })

        this.styleMgr = new ClassStyleManager({app: this})
        // this.styleMgr = new ElementStyleManager({app: this})

        this.openEditors = []
        this.currentEditor = null

        this.settings.processOptions(opts)
        this.emit('optionsProcessed')
        
        if (opts.startView) {
            this.views[opts.startView].show()
        }

        if (opts.editors) {
            this.prepareEditors(opts.editors)
        }

        if (opts.textModes) {
            this.textModes = new TextModes({
                app: this,
                textModes: opts.textModes,
                parentElem: this.mainView.container,
            })
        }
    }
    prepateWidgets() {
        const widgetMap = {
            'text_input': TextInput,
        }
        const widgetsContainer = document.body.querySelector(':scope > div.widgets')
        for (const widget of widgetsContainer.children) {
            const ctor = widgetMap[widget.className]
            this.widgets[widget.className] = new ctor({
                container: widget,
            })
            widget.remove()
        }
    }
    prepareEditors(editorSpecs) {
        for (const editorSpec of editorSpecs) {
            if (editorSpec.buffer) {
                this.createEditorFromBuffer({
                    bufSize: editorSpec.bufSize,
                    fileName: editorSpec.fileName,
                    startOffset: editorSpec.startOffset,
                    buffer: editorSpec.buffer,
                    switchToTab: false,
                })
            } else {
                // this.createEditorNoBuffer
            }
        }
        if (this.openEditors.length > 0) {
            const lastEditor = this.openEditors[this.openEditors.length - 1]
            this.mainView.tabsWidget.switchToTab(lastEditor.tab)
            this.mainView.show()
        }
    }
    async getEditor(handle) {
        for (const editor of this.openEditors) {
            if (editor.fileInfo.type !== 'on_disk') {
                continue
            }
            if (await editor.fileInfo.fileHandle.isSameEntry(handle)) {
                return editor
            }
        }
        return null
    }
    async openFile() {
        try {
            const [fileHandle] = await window.showOpenFilePicker()
            const editor = await this.getEditor(fileHandle)
            if (editor) {
                this.mainView.show(editor.tab)
            } else {
                this.fileInfo = await new OnDiskFile({
                    app: this,
                    fileHandle,
                }).init()
                this.newFileDialog.show()
            }
        } catch (err) {
            if (err.name === 'AbortError') {
                console.log('User canceled the dialog')
            } else {
                console.log('Unxepected Error', err)
            }
        }
    }
    createEditorFromBuffer(spec) {
        const fileInfo = new InMemoryFile({
            app: this,
            bufSize: spec.bufSize,
            fileName: spec.fileName,
            startOffset: spec.startOffset,
            buffer: spec.buffer,
        })
        const editor = new HexEditor({
            fileInfo,
            buffer: spec.buffer,
            bufSize: spec.bufSize,
            fileName: spec.fileName,
            startOffset: spec.startOffset,
            app: this,
            settings: this.settings,
        })
        this.openEditors.push(editor)
        editor.tab = this.mainView.tabsWidget.createTab(spec.fileName)
        // editor.isModified = true
        if (spec.switchToTab) {
            this.mainView.tabsWidget.switchToTab(editor.tab)
            this.mainView.show()
        }
        return editor
    }
    async createEditorFromFile(spec) {
        let buffer
        if (this.fileInfo.fileObj.size === spec.bufSize) {
            buffer = await this.fileInfo.fileObj.arrayBuffer()
        } else {
            const blob = this.fileInfo.fileObj.slice(
                spec.startOffset, spec.startOffset + spec.bufSize)
            buffer = await blob.arrayBuffer()
        }

        editor = new HexEditor({
            fileInfo: this.fileInfo,
            buffer,
            fileName: spec.fileName,
            startOffset: spec.startOffset,
            app: this,
            settings: this.settings,
        })
        this.openEditors.push(editor)
        editor.tab = this.mainView.tabsWidget.createTab(spec.fileName)
        if (spec.switchToTab) {
            this.mainView.tabsWidget.switchToTab(editor.tab)
            this.mainView.show()
        }
        return editor
    }
    selectCell(index) {
        const editor = this.mainView.editorView
        const cell = editor.posMgr.getElem(index)
        editor.selectionMgr.selectCell(cell)
        this.mainView.focusEditorView()
    }
    printMessage(msg) {
        if (this.messageWidget) {
            this.messageWidget.print(msg)
        }
    }
    onWorkspaceOpened() {
        this.fileExplorer.show()
    }
}
