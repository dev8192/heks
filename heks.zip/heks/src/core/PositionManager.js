class IterativeCellCounter {
    constructor(opts) {
        this.app = opts.app
    }
    count() {
        let counter = 0
        this.app.mainView.editorView.iterateCells((cell, index) => {
            // console.log(index, cell)
            counter++
        })
        return counter
    }
}

class BasePositionManager {
    constructor(opts) {
        this.app = opts.app
        this.cellCounter = new IterativeCellCounter({app: this.app})
    }
    getCellCount() {
        return this.cellCounter.count()
    }
    setIndex() {
    }
    getIndex() {
    }
    getX(elem) {
    }
    getY(elem) {
    }
    setIndices() {
    }
    getEmptyCell(gridElem, bufSize) {
    }
}

class LoopPositionManager extends BasePositionManager {
    constructor(opts) {
        super(opts)
    }
    getIndex(elem) {
        let found
        this.app.mainView.editorView.iterateCells((cell, index) => {
            if (cell === elem) {
                found = index
                return true
            }
        })
        if (typeof found === 'number') {
            found += this.app.currentEditor.buffer.bufferOffset
        }
        return found
    }
    getElem(index) {
        index -= this.app.currentEditor.buffer.bufferOffset
        if (index < 0) {
            return null
        }
        const posX = index % 16
        let posY = (index - posX + 16) / 16
        posY += this.app.settings.get('showCols') ? 0 : -1
        const row = this.app.mainView.editorView.gridElem.children[posY]
        if (!row) {
            return null
        }
        return row.children[posX]
    }
    getX(elem) {
        let counter = 0
        const rowElem = elem.parentElement
        for (const item of rowElem.children) {
            if (item === elem) {
                return counter
            }
            counter++
        }
        throw new Error('Element not found')
    }
    getY(elem) {
        const rowElem = elem.parentElement
        const gridElem = rowElem.parentElement
        for (let i = 0; i < gridElem.childElementCount; i++) {
            if (gridElem.children[i] === rowElem) {
                if (this.app.currentEditor.opts.showCols) {
                    i--
                }
                return i
            }
        }
        throw new Error('Element not found')
    }
}

class DataAttrPositionManager extends BasePositionManager {
    constructor(opts) {
        super(opts)
        this.setIndex = this.setIndex.bind(this)
    }
    setIndices() {
        this.app.mainView.editorView.iterateCells((elem, index) => {
            this.setIndex(elem, index)
            console.log(elem.dataset.x, elem.dataset.y)
        })
    }
    setIndex(elem, index) {
        if (index === undefined) {
            const row = elem.parentElement
            const gridElem = row.parentElement
            elem.dataset.x = row.childElementCount
            elem.dataset.y = gridElem.childElementCount - 1
        } else {
            elem.dataset.x = index % 16
            elem.dataset.y = Math.floor(index / 16)
        }
    }
    getIndex(elem) {
        const x = Number(elem.dataset.x)
        const y = Number(elem.dataset.y)
        return y * this.app.currentEditor.gridWidth + x
    }
    getX(elem) {
        return Number(elem.dataset.x)
    }
    getY(elem) {
        return Number(elem.dataset.y)
    }
}

class MapPositionManager extends BasePositionManager {
    constructor(opts) {
        super(opts)
        this.elemToIndexMap = new Map()
    }
    setIndices() {
        this.app.mainView.editorView.iterateCells((elem, index) => {
            this.setIndex(elem, index)
        })
    }
    setIndex(elem, index) {
        this.elemToIndexMap.set(elem, index)
    }
    getIndex(elem) {
        return this.elemToIndexMap.get(elem)
    }
    getX(elem) {
        const index = this.elemToIndexMap.get(elem)
        return index % this.app.currentEditor.gridWidth
    }
    getY(elem) {
        const index = this.elemToIndexMap.get(elem)
        return Math.floor(index / this.app.currentEditor.gridWidth)
    }
    getCellCount() {
        return this.elemToIndexMap.size
    }
}
