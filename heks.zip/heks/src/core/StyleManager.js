
class BaseStyleManager extends EventEmitter {
    constructor(opts) {
        super()
        this.app = opts.app
        
        this.app.settings.addListener('bgColorChanged', this.onBgColorChanged.bind(this))
        this.app.settings.addListener('selColorChanged', this.onSelColorChanged.bind(this))
    }
    #bgColor
    get bgColor() {
        if (this.#bgColor === undefined) {
            this.#bgColor = this.app.settings.get('bgColor')
        }
        return this.#bgColor
    }
    set bgColor(value) {
        this.#bgColor = value
    }
    onBgColorChanged(color) {
        this.bgColor = color
    }
    #selColor
    get selColor() {
        if (this.#selColor === undefined) {
            this.#selColor = this.app.settings.get('selColor')
        }
        return this.#selColor
    }
    set selColor(value) {
        this.#selColor = value
    }
    onSelColorChanged(color) {
        this.selColor = color
    }
    setBgColor(elem) {
    }
    clearBgColor(elem) {
    }
    addStyle() {
    }
    selectCell(elem) {
        this.emit('cellSelected', elem)
    }
    clearSelection(elem) {
        this.emit('selectionCleared', elem)
    }
}

class ClassStyleManager extends BaseStyleManager {
    constructor(opts) {
        super(opts)
        if (opts.styleElem) {
            this.styleElem = opts.styleElem
        } else {
            this.styleElem = document.createElement('style')
            document.head.appendChild(this.styleElem)
        }

        this.addStyle(`
            .editor_view .cell.occupied {
                background-color: ${this.bgColor};
            }
        `)
        this.addStyle(`
            .editor_view .cell.occupied.selected {
                background-color: ${this.selColor};
                border: black 5px solid;
            }
        `)
    }
    addStyle(ruleStr) {
        const sheet = this.styleElem.sheet
        sheet.insertRule(ruleStr, sheet.cssRules.length)
    }
    onBgColorChanged(color) {
        super.onBgColorChanged(color)
        this.styleElem.sheet.cssRules.item(0).styleMap.set('background-color', color)
    }
    onSelColorChanged(color) {
        super.onSelColorChanged(color)
        this.styleElem.sheet.cssRules.item(1).styleMap.set('background-color', color)
    }
    selectCell(elem, className = 'selected') {
        if (!elem) {
            return
        }
        elem.classList.add(className)
        super.selectCell(elem)
    }
    clearSelection(elem, className = 'selected') {
        if (!elem) {
            return
        }
        elem.classList.remove(className)
        super.clearSelection(elem)
    }
    setBgColor(elem) {
        elem.classList.add('occupied')
    }
    clearBgColor(elem) {
        elem.classList.remove('occupied')
    }
}

class ElementStyleManager extends BaseStyleManager {
    constructor(opts) {
        super(opts)
    }
    onBgColorChanged(color) {
        super.onBgColorChanged(color)
        // this.app.mainView.markAllEditorsAsDirty()
    }
    onSelColorChanged(color) {
        super.onSelColorChanged(color)
        // this.app.mainView.markAllEditorsAsDirty()
    }
    setBgColor(elem) {
        elem.style.backgroundColor = this.bgColor
    }
    clearBgColor(elem) {
        elem.style.backgroundColor = ''
    }
    selectCell(elem, color) {
        if (!elem) {
            return
        }
        if (color) {
            elem.style.backgroundColor = color
        } else {
            elem.style.backgroundColor = this.selColor
        }
        super.selectCell(elem)
    }
    clearSelection(elem) {
        if (!elem) {
            return
        }
        elem.style.backgroundColor = this.bgColor
        super.clearSelection(elem)
    }
}