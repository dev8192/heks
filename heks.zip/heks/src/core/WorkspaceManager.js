const exampleWorkspaceData = [
    {
        name: 'flat_example',
        backend: 'LocalStorage',
        system: true,
        data: {
            children: [
                { name: 'file1', data: '' },
                { name: 'file2', data: '' },
                { name: 'file3' , data: '' },
                { name: 'file4' , data: '' },
                { name: 'file5' , data: '' },
                { name: 'file6' , data: '' },
                { name: 'file7' , data: '' },
                { name: 'file8' , data: '' },
                { name: 'file9' , data: '' },
                { name: 'file10' , data: '' },
                { name: 'dir1', children: [] },
                { name: 'dir2', children: [] },
                { name: 'dir3', children: [] },
                { name: 'dir4', children: [] },
                { name: 'dir5', children: [] },
            ]
        }
    },
    {
        name: 'deep_example',
        backend: 'LocalStorage',
        system: true,
        data: {
            children: [
                { name: 'dir1', children: [
                    { name: 'dir2', children: [
                        { name: 'dir3', children: [
                            { name: 'dir4', children: [
                                { name: 'dir5', children: [
                                    { name: 'file1', data: '' },
                                    { name: 'file2', data: '' },
                                    { name: 'file3', data: '' },
                                ] },
                            ] },
                        ] },
                    ] },
                ] },
            ]
        }
    },
    {
        name: 'example1',
        backend: 'LocalStorage',
        system: true,
        data: {
            children: [
                {
                    name: 'dir1',
                    children: [
                        { name: 'file1', data: '' },
                        {
                            name: 'dir2',
                            children: [
                                { name: 'file5', data: '' },
                                { name: 'file6', data: '' },
                            ]
                        },
                        {
                            name: 'dir4',
                            children: [
                                { name: 'file7', data: '' },
                            ]
                        },
                        { name: 'file2', data: '' },
                    ],
                },
                { name: 'file3', data: '' },
                { name: 'file4', data: '' },
                { name: 'dir3', children: [] },
            ]
        },
    }
]

const data1 = [
    'dir1/file1',
    'dir1/file2',
    'dir1/dir2/file5',
    'file3',
    'file4',
    'dir3',
]

class WorkspaceManager extends EventEmitter {
    constructor(opts) {
        super(opts)
        this.printMessage = opts.printMessage

        this.DB_NAME = 'heks_workspaces'
        this.STORE_NAME = 'workspace_list'
        
        this.metadataDB = null

        this.currentWorkspace = null
    }
    startManager() {
        return new Promise((resolve, reject) => {
            if (this.metadataDB) {
                resolve()
                return
            }
            const req = indexedDB.open(this.DB_NAME, 1)
            req.onupgradeneeded = () => {
                req.result.createObjectStore(this.STORE_NAME, { keyPath: 'name' })
            }
            req.onsuccess = () => {
                this.metadataDB = req.result
                resolve()
            }
            req.onerror = () => reject(req.error)
        })
    }
    stopManager() {
        if (this.metadataDB) {
            this.metadataDB.close()
            this.metadataDB = null
        }
    }
    async resetWorkspaces() {
        try {
            await this.clearMetadata()
            await this.writeWorkspaceData(exampleWorkspaceData)
        } catch(err) {
            console.log(err)
        }
    }
    clearMetadata() {
        return new Promise((resolve, reject) => {
            const tx = this.metadataDB.transaction(this.STORE_NAME, 'readwrite')
            const store = tx.objectStore(this.STORE_NAME)
            store.clear()
            tx.oncomplete = () => {
                resolve()
            }
            tx.onabort = () => {
                reject(tx.error)
            }
            tx.onerror = () => {
                reject(tx.error)
            }
        })
    }
    writeWorkspaceData(data) {
        return new Promise(async (resolve, reject) => {
            const tx = this.metadataDB.transaction(this.STORE_NAME, 'readwrite')
            const store = tx.objectStore(this.STORE_NAME)
            for (const item of data) {
                let promise
                if (item.backend === 'LocalStorage') {
                    promise = LocalStorageBackend.createFromData(item.name, item.data)
                } else if (item.backend === 'FileSystem') {
                    promise = FileSystemAccessBackend.createFromData(item.name, item.data)
                } else if (item.backend === 'IndexedDB') {
                    promise = IndexedDBBackend.createFromData(item.name, item.data)
                } else {
                    throw new Error('Unknown backend')
                }
                promise.then(() => {
                    const req = store.add(item)
                    req.onerror = () => {
                        reject(req.error)
                    }
                })
            }
            tx.oncomplete = () => {
                resolve()
            }
            tx.onabort = () => {
                reject(tx.error)
            }
            tx.onerror = () => {
                reject(tx.error)
            }
        })
    }
    checkLocalStorageWorkspaces() {
        const workspaces = []
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i)
            if (key.startsWith('heks_workspace')) {
                const data = localStorage.getItem(key)
                workspaces.push(data)
            }
        }
        console.log(workspaces)
    }
    validateName(name) {
        if (name.trim().length !== name.length) {
            this.printMessage('Leading and trailing whitespace is not allowed')
            return false
        }
        if (!/[a-zA-Z0-9]{5,15}/.test(name)) {
            this.printMessage('This name is not allowed')
            return false
        }
        return true
    }
    async createLocalStorageWorkspace(name) {
        try {
            await this.saveWorkspace({
                name,
                backend: 'LocalStorage',
                system: false,
            })
        } catch (err) {
            console.log(err)
        }
    }
    async createIndexedDBWorkspace(name) {
        try {
            await this.saveWorkspace({
                name,
                backend: 'IndexedDB',
                system: false,
            })
        } catch (err) {
            console.log(err)
        }
    }
    async createFileSystemWorkspace(name) {
        try {
            const handle = await window.showDirectoryPicker()
            await this.saveWorkspace({
                name,
                backend: 'FileSystem',
                system: false,
                handle,
            })
        } catch (err) {
            console.log(err)
        }
    }
    async saveWorkspace(obj) {
        return new Promise((resolve, reject) => {
            const tx = this.metadataDB.transaction(this.STORE_NAME, 'readwrite')
            const store = tx.objectStore(this.STORE_NAME)
            store.put(obj)
            tx.oncomplete = () => {
                resolve()
            }
            tx.onerror = () => {
                reject(tx.error)
            }
        })
    }
    async getWorkspaceMetadata(key) {
        // console.log('getWorkspaceMetadata', key)
        return new Promise((resolve, reject) => {
            const tx = this.metadataDB.transaction(this.STORE_NAME, 'readonly')
            const store = tx.objectStore(this.STORE_NAME)
            const getReq = store.get(key)
            tx.oncomplete = () => {
                resolve(getReq.result)
            }
            tx.onerror = () => {
                reject(getReq.error)
            }
        })
    }
    async getAllWorkspaces() {
        return new Promise((resolve, reject) => {
            const tx = this.metadataDB.transaction(this.STORE_NAME, 'readonly')
            const store = tx.objectStore(this.STORE_NAME)
            const req = store.getAll()
            req.onsuccess = () => {
                resolve(req.result)
            }
            req.onerror = () => {
                reject(req.error)
            }
        })
    }
    async iterateWorkspaces(handler) {
        return new Promise((resolve, reject) => {
            const tx = this.metadataDB.transaction(this.STORE_NAME, 'readonly')
            const store = tx.objectStore(this.STORE_NAME)
            const req = store.openCursor()
            req.onsuccess = (evt) => {
                const cursor = evt.target.result
                if (cursor) {
                    handler(cursor.value)
                    cursor.continue()
                } else {
                    resolve()
                }
            }
            req.onerror = () => {
                reject(req.error)
            }
        })
    }
    async openWorkspace(workspaceObject) {
        if (workspaceObject.backend === 'LocalStorage') {
            this.currentWorkspace = new LocalStorageBackend({
                app: this,
                name: workspaceObject.name,
                type: workspaceObject.type,
            })
        } else if (workspaceObject.backend === 'FileSystem') {
            await this.openFileSystemWorkspace(workspaceObject)
        } else if (workspaceObject.backend === 'IndexedDB') {
            this.currentWorkspace = new IndexedDBBackend({
                app: this,
                name: workspaceObject.name,
                type: workspaceObject.type,
            })
        } else {

        }
        this.emit('workspaceOpened', workspaceObject)
    }
    async openFileSystemWorkspace(workspaceObject) {
        // console.log('openFileSystemWorkspace')
        try {
            const obj = await this.getWorkspaceMetadata(workspaceObject.name)
            // console.log('obj', obj)
            if (!obj) {
                return null
            }

            let perm
            try {
                perm = await obj.handle.queryPermission({ mode: 'readwrite' })
                // console.log('queryPermission', perm)
            } catch (err) {
                console.error(err)
            }
            if (perm !== 'granted') {
                try {
                    perm = await obj.handle.requestPermission({ mode: 'readwrite' })
                    // console.log('requestPermission', perm)
                } catch (err) {
                    console.error(err)
                }
            }
            if (perm === 'granted') {
                this.currentWorkspace = new FileSystemAccessBackend({
                    app: this,
                    handle: obj.handle,
                    name: workspaceObject.name,
                    type: workspaceObject.type,
                })
            }
        } catch (err) {
            console.log(err)
        }
    }
    async removeWorkspace(workspaceObject) {
        if (workspaceObject.type === 'system') {
            this.printMessage('Cannot remove sample workspace')
            return
        }
        return new Promise((resolve, reject) => {
            const tx = this.metadataDB.transaction(this.STORE_NAME, 'readwrite')
            const store = tx.objectStore(this.STORE_NAME)
            const req = store.delete(workspaceObject.name)
            req.onsuccess = () => {
                resolve(req.result)
            }
            req.onerror = () => {
                reject(req.error)
            }
        })
    }
    async renameWorkspace(oldName, newName) {
        const tx = this.metadataDB.transaction(this.STORE_NAME, 'readwrite')
        const store = tx.objectStore(this.STORE_NAME)
        
        const getReq = store.get(oldName)
        const obj = await new Promise((resolve, reject) => {
            getReq.onsuccess = () => resolve(getReq.result)
            getReq.onerror = () => reject(getReq.error)
        })
        
        if (!obj) throw new Error('Record not found')
        if (obj.type === 'system') {
            throw new Error('Cannot rename sample workspace')
        }

        obj.name = newName
        store.put(obj) 

        return new Promise((resolve, reject) => {
            tx.oncomplete = () => {
                resolve()
            }
            tx.onerror = () => {
                reject(tx.error)
            }
        })
    }
}
