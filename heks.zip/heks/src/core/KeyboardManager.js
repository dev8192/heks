class KeyboardManager {
    constructor(opts) {
        this.handlers = {}
        this.container = opts.container
        this.stopPropagation = opts.stopPropagation
        this.container.tabIndex = 0
        this.container.addEventListener('keydown', this.onKeyDown.bind(this))
    }
    addHandler(eventCode, handler) {
        this.handlers[eventCode] = handler
    }
    removeHandler(eventCode) {
        // this.handlers[eventCode] = null
        delete this.handlers[eventCode]
    }
    onKeyDown(event) {
        if (this.stopPropagation) {
            event.stopPropagation()
        }
        if (this.handlers[event.code]) {
            this.handlers[event.code](event)
        }
    }
}
