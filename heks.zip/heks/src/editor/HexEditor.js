/*
app.currentEditor.fileOffset        app.currentEditor.fileInfo.startOffset
app.currentEditor.bufferOffset      app.currentEditor.buffer.bufferOffset
*/
class BaseEditor extends Widget {
    static settingContributions = [
    ]
    constructor(opts = {}) {
        super(opts)
        this.dirty = false
        this.fileInfo = opts.fileInfo
        this.isModified = false
        this.settings = opts.settings
        this.settings.contribute(BaseEditor.settingContributions)
    }
    async dump() {
        if (this.fileInfo.fileObj) {
            const contents = await this.fileInfo.fileObj.text()
            console.log(contents)
        }
    }
    async saveFile() {
        try {
            if (!this.fileInfo.fileHandle) {
                this.fileInfo.fileHandle = await window.showSaveFilePicker({
                    suggestedName: this.fileInfo.getFileName(),
                })
            }
            const writable = await this.fileInfo.fileHandle.createWritable()
            const buffer = this.buffer.getBuffer()
            await writable.write(buffer)
            await writable.close()
            this.isModified = false
        } catch (err) {
            if (err.name === 'AbortError') {
                console.log('User canceled the dialog');
            } else {
                console.log('Unxepected Error', err);
            }
        }
    }
    build() {

    }
    populate() {

    }
}

class HexEditor extends BaseEditor {
    constructor(opts) {
        super(opts)

        this.gridWidth = 16

        this.bufferOffset = 0
        this.fileOffset = 0
        this.currentCellIdx = null

        this.buffer = new Buffer({
            app: this.app,
            buffer: this.opts.buffer,
            bufSize: this.opts.bufSize,
        })

        for (const item of MainView.settingContributions) {
            if (opts[item.id] !== undefined) {
                this.settings.set(item.id, opts[item.id])
            }
        }

        if (this.opts.startOffset === undefined) {
            this.opts.startOffset = 0
        }
    }
    getCurrentCellIdx() {
        // if (this.currentCellIdx === this.buffer.bufSize)
        return this.currentCellIdx
    }
    getIndex(elem) {
        return this.posMgr.getIndex(elem)
    }
    getMaxRows() {
        return this.settings.get('maxRows')
    }
    populate() {
        // console.log('HexEditor.populate')
        const upperBound = this.buffer.bufSize - this.buffer.bufferOffset
        this.app.mainView.editorView.iterateCells((cell, index) => {
            if (index < upperBound) {
                const byte = this.buffer.getUint8(this.buffer.bufferOffset + index)
                cell.textContent = byte.toString(16).padStart(2, '0')
                this.app.styleMgr.setBgColor(cell)
            } else {
                cell.textContent = ''
                this.app.styleMgr.clearBgColor(cell)
            }
        })
        if (this.app.currentEditor.currentCellIdx !== null) {
            const posMgr = this.app.mainView.editorView.posMgr
            const elem = posMgr.getElem(this.app.currentEditor.currentCellIdx)
            this.app.styleMgr.selectCell(elem)
        }

        if (this.settings.get('showAddCellButton')) {
            this.app.mainView.editorView.addCellButton.insert()
        }

        if (this.settings.get('showRows')) {
            const container = this.app.mainView.editorView.offsetsElem
            let offset = this.buffer.bufferOffset
            const offSize = this.settings.get('offsetSize')
            const showCols = this.settings.get('showCols')
            let i = showCols ? 1 : 0
            const remainder = this.buffer.bufSize % 16
            let upperBound = (this.buffer.bufSize - remainder) / 16 + 1
            upperBound += showCols ? 1 : 0
            for (; i < container.childElementCount; i++) {
                const elem = container.children[i]
                if (i < upperBound) {
                    const addr = '0x' + offset.toString(16).padStart(offSize, '0')
                    elem.textContent = addr
                    this.app.styleMgr.setBgColor(elem)
                    offset += 16
                } else {
                    elem.textContent = ''
                    this.app.styleMgr.clearBgColor(elem)
                }
            }
        }
    }
}

class BinEditor extends BaseEditor {
    constructor(opts = {}) {
        super(opts)
    }
}
