class SelectionManager extends EventEmitter {
    constructor(opts) {
        super()
        this.app = opts.app
        this.printMessage = opts.printMessage
        this.editorView = opts.editorView
        this.posMgr = this.editorView.posMgr
        this.editorView.iterateCells((cell, index) => {
            cell.addEventListener('click', this.onClick.bind(this))
        })
        this.app.addListener('editorCreated', this.onEditorCreated.bind(this))
    }
    onEditorCreated(editor) {
        editor.currentCell = null
    }
    unload() {
        this.editorView.iterateCells((cell, index) => {
            cell.removeEventListener('click', this.onClick.bind(this))
        })
    }
    onClick(event) {
        this.selectCell(event.target)
        event.stopPropagation()
    }
    selectCell(cell) {
        const cellEditor = this.app.mainView.cellEditor
        if (cellEditor && cellEditor.currentPos !== 0) {
            this.printMessage('Editing the cell value is not finished')
            return
        }
        const index = this.posMgr.getIndex(cell)
        if (this.app.currentEditor.currentCellIdx === null) {
            this.app.currentEditor.currentCellIdx = index
            this.app.styleMgr.selectCell(cell)
        } else {
            if (this.app.currentEditor.currentCellIdx === index) {
                this.app.styleMgr.clearSelection(cell)
                this.app.currentEditor.currentCellIdx = null
            } else {
                const oldCell = this.posMgr.getElem(this.app.currentEditor.currentCellIdx)
                this.app.styleMgr.clearSelection(oldCell)
                this.app.currentEditor.currentCellIdx = index
                this.app.styleMgr.selectCell(cell)
            }
        }
    }
    clearSelection() {
        if (this.app.currentEditor.currentCellIdx === null) {
            return
        }
        const cell = this.posMgr.getElem(this.app.currentEditor.currentCellIdx)
        this.app.styleMgr.clearSelection(cell)
        this.app.currentEditor.currentCellIdx = null
        this.emit('selectionCleared', cell)
    }
}

class EditorView extends Widget {
    constructor(opts) {
        super(opts)
        this.settings = opts.settings
        this.buildInternal()
        
        this.posMgr = new LoopPositionManager({app: this.app})
        // this.posMgr = new DataAttrPositionManager({app: this.app})
        // this.posMgr = new MapPositionManager({app: this.app})
        this.posMgr.setIndices()

        this.addCellButton = null

        if (this.settings.get('showAddCellButton')) {
            this.addCellButton = new AddCellButton({
                app: this.app,
                editorView: this,
            })
        }
        this.selectionMgr = new SelectionManager({
            app: this.app,
            editorView: this,
        })

        this.app.addListener('bufferValueChanged', this.onBufferValueChanged.bind(this))
    }
    onBufferValueChanged(event) {
        if (event.origin === this) {
            return
        }
        const elem = this.posMgr.getElem(event.index)
        elem.textContent = event.value.toString(16).padStart(2, '0')
    }
    createLayout1() {
        this.container.classList.add('editor_view')
        this.container.classList.add('hex_editor')

        if (this.settings.get('showRows')) {
            this.offsetsElem = document.createElement('div')
            this.offsetsElem.classList.add('offsets')
            this.container.append(this.offsetsElem)
        }

        this.gridElem = document.createElement('div')
        this.gridElem.classList.add('grid')
        this.container.append(this.gridElem)
    }
    createLayout2() {
        this.container.innerHTML = '<div class="editor_view hex_editor">\n' +
            '<div class="offsets"></div>\n' +
            '<div class="grid"></div>\n' +
        '</div>'
        this.gridElem = this.container.querySelector('.grid')
        this.offsetsElem = this.container.querySelector('.offsets')
    }
    buildInternal() {
        this.createLayout1()

        const showCols = this.settings.get('showCols')
        if (showCols) {
            const row = document.createElement('div')
            row.classList.add('row')
            row.classList.add('header')
            for (let i = 0; i < 16; i++) {
                const cell = document.createElement('div')
                cell.classList.add('cell')
                cell.textContent = i.toString(16).padStart(2, '0')
                row.append(cell)
            }
            this.gridElem.append(row)
        }

        let maxRows = this.settings.get('maxRows')
        for (let i = 0; i < maxRows; i++) {
            const row = document.createElement('div')
            row.classList.add('row')
            this.gridElem.append(row)
            for (let j = 0; j < 16; j++) {
                const cell = document.createElement('div')
                cell.classList.add('cell')
                row.append(cell)
            }
        }
        
        if (this.settings.get('showRows')) {
            let i = showCols ? -1 : 0
            for (; i < maxRows; i++) {
                const cell = document.createElement('div')
                cell.classList.add('cell')
                this.offsetsElem.append(cell)
            }
        }
    }
    isRowFull(row) {
        const count = row.childElementCount
        return count % 16 === 0 && count !== 0
    }
    iterateCells(callback) {
        let index = 0
        const rowCount = this.gridElem.childElementCount
        let row = this.settings.get('showCols') ? 1 : 0
        for (; row < rowCount; row++) {
            const rowElem = this.gridElem.children[row]
            for (let col = 0; col < rowElem.childElementCount; col++) {
                if (!rowElem.children[col].classList.contains('add_cell')) {
                    const done = callback(rowElem.children[col], index)
                    if (done) {
                        return
                    }
                    index++
                }
            }
        }
    }
    computeLastPage() {
        const viewHeight = this.settings.get('maxRows')
        const byteLen = this.app.currentEditor.buffer.buffer.byteLength
        let offset = byteLen - viewHeight * 16
        if (this.settings.get('showAddCellButton')) {
            if (this.app.currentEditor.buffer.bufSize % 16 === 0) {
                offset += 16
            }
        }
        if (offset < 0) {
            return 0
        }
        return offset
    }
}
