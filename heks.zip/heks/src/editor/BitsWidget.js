class BitsWidget extends Widget {
    constructor(opts) {
        super(opts)
        this.contentElem = this.container.querySelector('.content')

        this.onBitElemClick = this.onBitElemClick.bind(this)
        this.contentElem.querySelectorAll('.bit').forEach((bitElem) => {
            bitElem.addEventListener('click', this.onBitElemClick)
        })
        
        this.allOnesButton = this.container.querySelector('.all_ones')
        this.setAllOnes = this.setAllOnes.bind(this)
        this.allOnesButton.addEventListener('click', this.setAllOnes)
        
        this.allZerosButton = this.container.querySelector('.all_zeros')
        this.setAllZeros = this.setAllZeros.bind(this)
        this.allZerosButton.addEventListener('click', this.setAllZeros)
        
        this.resetButton = this.container.querySelector('.reset')
        this.reset = this.reset.bind(this)
        this.resetButton.addEventListener('click', this.reset)

        this.app.addListener('bufferValueChanged', this.onBufferValueChanged.bind(this))

        this.elemToIndexMap = new Map()
        this.initElemToIndexMap()

        this.initialValue = null

        this.valueArray = [
            '0', '0', '0', '0',
            '0', '0', '0', '0',
        ]
    }
    initElemToIndexMap() {
        let group = this.contentElem.querySelector('.left')
        let index = 0
        for (; index < 4; index++) {
            const elem = group.children[index]
            this.elemToIndexMap.set(elem, index)
        }
        group = this.contentElem.querySelector('.right')
        for (; index < 8; index++) {
            const elem = group.children[index - 4]
            this.elemToIndexMap.set(elem, index)
        }
    }
    show() {
        const index = this.app.currentEditor.currentCellIdx
        const value = this.app.currentEditor.buffer.getUint8(index)
        this.initialValue = value
        this.setValue(value)
        super.show()
    }
    getValue() {
        const binStr = this.valueArray.join('')
        return parseInt(binStr, 2)
    }
    setValue(value) {
        const str = value.toString(2).padStart(8, '0')
        this.valueArray = str.split('')
        for (let i = 0; i < 8; i++) {
            this.setBit(i, str[i])
        }
    }
    setBit(index, value) {
        let elem
        if (index < 4) {
            elem = this.contentElem.querySelector('.left').children[index]
        } else {
            elem = this.contentElem.querySelector('.right').children[index - 4]
        }
        elem.textContent = value
    }
    onBitElemClick(event) {
        const index = this.elemToIndexMap.get(event.target)
        this.valueArray[index] = this.valueArray[index] === '0' ? '1' : '0'
        event.target.textContent = this.valueArray[index]
        const value = this.getValue()
        this.emit('valueChanged', {
            origin: this,
            value,
        })
    }
    setAllOnes() {
        const value = 255
        this.setValue(value)
        this.emit('valueChanged', {
            origin: this,
            value,
        })
    }
    setAllZeros() {
        const value = 0
        this.setValue(value)
        this.emit('valueChanged', {
            origin: this,
            value,
        })
    }
    reset() {
        const value = this.initialValue
        this.setValue(value)
        this.emit('valueChanged', {
            origin: this,
            value,
        })
    }
    onBufferValueChanged(event) {
        if (event.origin === this) {
            return
        }
        this.show()
    }
}
