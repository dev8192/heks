class WasmBuilder extends View {
    constructor(opts) {
        opts.viewId = 'wasm_builder'
        super(opts)

        this.printMessage = this.app.printMessage

        this.onFunctionAdded = this.onFunctionAdded.bind(this)

        this.typeList = new TypeList({
            app: this.app,
            parentElem: this.container,
            selector: '.type_list',
        })
        this.typeList.addListener('show', this.onTypeListShow.bind(this))
        this.typeList.addListener('hide', this.onTypeListHide.bind(this))
        this.typeList.addListener('selectionChanged', this.onTypeListSelectionChanged.bind(this))

        this.typesMenu = this.container.querySelector('.types.title')
        this.toggleTypeVisibilityButton = this.typesMenu.querySelector('.toggle_visibility')
        this.toggleTypeVisibilityButton.onclick = this.onToggleTypeVisibilityButtonClick.bind(this)
        this.addTypeButton = this.typesMenu.querySelector('.add')
        this.addTypeButton.onclick = this.onAddTypeButtonClick.bind(this)
        this.deleteTypeButton = this.typesMenu.querySelector('.delete')
        this.deleteTypeButton.onclick = this.onDeleteTypeButtonClick.bind(this)
        this.typeEditor = new TypeEditor({
            app: this.app,
            parentElem: this.container,
            selector: '.type_editor',
        })
        this.typeEditor.addListener('ok', this.onTypeEditorOk.bind(this))
        this.typeEditor.addListener('cancel', this.onTypeEditorCancel.bind(this))

        this.importsButton = this.container.querySelector('.imports .add')
        this.importsButton.onclick = this.onImportsButtonClick.bind(this)
        this.importsContentElem = this.container.querySelector('.imports.content')

        this.toggleFuncVisibilityButton = this.container.querySelector('.functions .toggle_visibility')
        this.toggleFuncVisibilityButton.onclick = this.toggleFunctionListVisibility.bind(this)

        this.addFunctionButton = this.container.querySelector('.functions .add')
        this.editButton = this.container.querySelector('.functions .edit')
        this.editButton.addEventListener('click', this.onEditButtonClick.bind(this))
        
        this.toggleFuncListModeButton = new ButtonGroup({
            parentElem: this.container,
            selector: '.toggle_mode',
            onClick: this.setFuncListMode.bind(this),
        })
        this.setFuncListMode(this.toggleFuncListModeButton.getValue())
        this.functionList.addListener('show', this.onFunctionListShow.bind(this))
        this.functionList.addListener('hide', this.onFunctionListHide.bind(this))

        this.addFunctionButton.onclick = this.onFunctionsButtonClick.bind(this)
        this.functionEditor = new FunctionEditor({
            app: this.app,
            parentElem: this.container,
            selector: '.function_editor',
        })
        this.app.wasmProgram.types.addListener('typeSelected', this.onTypeSelected.bind(this))
        this.functionEditor.addListener('ok', this.onFunctionEditorOk.bind(this))
        this.functionEditor.addListener('cancel', this.onFunctionEditorCancel.bind(this))

        this.codeEditor = new CodeEditor({
            app: this.app,
            parentElem: this.container,
            selector: '.code_editor'
        })
        this.codeEditor.addListener('ok', this.onCodeEditorOk.bind(this))
        this.codeEditor.addListener('cancel', this.onCodeEditorCancel.bind(this))

        this.tablesButton = this.container.querySelector('.tables .add')
        this.tablesButton.onclick = this.onTablesButtonClick.bind(this)
        this.tablesContentElem = this.container.querySelector('.tables.content')

        this.memoriesButton = this.container.querySelector('.memories .add')
        this.memoriesButton.onclick = this.onMemoriesButtonClick.bind(this)
        this.memoriesContentElem = this.container.querySelector('.memories.content')

        this.globalsButton = this.container.querySelector('.globals .add')
        this.globalsButton.onclick = this.onGlobalsButtonClick.bind(this)
        this.globalsContentElem = this.container.querySelector('.globals.content')

        this.exportsButton = this.container.querySelector('.exports .add')
        this.exportsButton.onclick = this.onExportsButtonClick.bind(this)
        this.exportsContentElem = this.container.querySelector('.exports.content')

        this.startButton = this.container.querySelector('.start .add')
        this.startButton.onclick = this.onStartButtonClick.bind(this)
        this.startContentElem = this.container.querySelector('.start.content')

        this.dataButton = this.container.querySelector('.data .add')
        this.dataButton.onclick = this.onDataButtonClick.bind(this)
        this.dataContentElem = this.container.querySelector('.data.content')


        this.runButton = this.container.querySelector('.run')
        this.runButton.addEventListener('click', this.onRunButtonClick.bind(this))
        this.removeButton = this.container.querySelector('.remove')
        this.removeButton.addEventListener('click', this.onRemoveButtonClick.bind(this))
        this.closeButton = this.container.querySelector('.close')
        this.closeButton.addEventListener('click', this.onCloseButtonClick.bind(this))
        this.editorButton = this.container.querySelector('.editor')
        this.editorButton.addEventListener('click', this.onEditorButtonClick.bind(this))
    }
    show() {
        super.show()
        this.app.wasmProgram.addListener('functionAdded', this.onFunctionAdded)
    }
    hide() {
        super.hide()
        this.app.wasmProgram.removeListener('functionAdded', this.onFunctionAdded)
    }
    onTypeListSelectionChanged(selection) {
        if (selection) {
            this.deleteTypeButton.classList.remove('hidden')
        } else {
            this.deleteTypeButton.classList.add('hidden')
        }
    }

    onTypeListShow() {
        this.toggleTypeVisibilityButton.textContent = 'Hide'
    }
    onTypeListHide() {
        this.toggleTypeVisibilityButton.textContent = 'Show'
    }
    onToggleTypeVisibilityButtonClick() {
        if (this.typeList.isVisible()) {
            this.typeList.hide()
        } else {
            this.typeList.show()
        }
    }
    onAddTypeButtonClick() {
        this.addTypeButton.classList.add('hidden')
        this.typeEditor.show()
    }
    onDeleteTypeButtonClick() {
        this.app.wasmProgram.deleteType(this.app.wasmProgram.types.currentType)
    }
    onTypeEditorOk(typeSpec) {
        this.app.wasmProgram.types.addItem(typeSpec)
        this.addTypeButton.classList.remove('hidden')
    }
    onTypeEditorCancel() {
        this.addTypeButton.classList.remove('hidden')
    }

    onImportsButtonClick() {
        
    }

    onFunctionListShow() {
        this.toggleFuncVisibilityButton.textContent = 'Hide'
    }
    onFunctionListHide() {
        this.toggleFuncVisibilityButton.textContent = 'Show'
    }
    toggleFunctionListVisibility() {
        if (this.functionList.isVisible()) {
            this.functionList.hide()
        } else {
            this.functionList.show()
        }
    }
    onFunctionsButtonClick() {
        this.addFunctionButton.classList.add('hidden')
        this.functionEditor.show()
    }
    onTypeSelected(typeObj) {
        this.functionEditor.setType(typeObj.name)
    }
    onFunctionAdded() {
        this.app.wasmProgram.functions.buildSection()
        this.functionList.show()
    }
    onFunctionEditorOk(funcObj) {        
        this.app.wasmProgram.functions.addItem(funcObj)
        this.addFunctionButton.classList.remove('hidden')
    }
    onFunctionEditorCancel() {
        this.addFunctionButton.classList.remove('hidden')
    }
    setFuncListMode(mode) {
        if (this.functionList) {
            this.functionList.dispose()
        }
        if (mode === 'verbose') {
            this.functionList = new VerboseFunctionList({
                app: this.app,
                parentElem: this.container,
                selector: '.function_list',
            })
        } else if (mode === 'compact') {
            this.functionList = new CompactFunctionList({
                app: this.app,
                parentElem: this.container,
                selector: '.function_list',
            })
        } else {
            throw new Error('FuncListMode is not set')
        }
        if (this.app.wasmProgram.functions.data.length > 0) {
            this.functionList.show()
        }
    }

    onEditButtonClick() {
        if (!this.app.wasmProgram.functions.currentFunction) {
            this.printMessage('Select a function')
            return
        }
        this.codeEditor.show()
    }

    onTablesButtonClick() {
        
    }
    onMemoriesButtonClick() {
        
    }
    onGlobalsButtonClick() {
        
    }
    onExportsButtonClick() {
        
    }
    onStartButtonClick() {
        
    }
    
    onCodeEditorOk() {

    }
    
    onCodeEditorCancel() {

    }

    onDataButtonClick() {
        
    }

    onRunButtonClick() {
        this.wasmExec.show()
    }
    onRemoveButtonClick() {
        
    }
    onCloseButtonClick() {
        
    }
    onEditorButtonClick() {
        
    }
}
