class Section extends EventEmitter {
    constructor(opts) {
        super(opts)
        this.wasmProgram = opts.wasmProgram
        this.data = []
        this.code = null
    }
    getSectionId() {
        return this.constructor.sectionId
    }
    len() {
        return this.data.length
    }
    build() {
    }
    buildSection() {
    }
    addItem(spec) {
        this.data.push(spec)
    }
    getItem(idx) {
        return this.data[idx]
    }
    delete(item) {
        this.data = this.data.filter(arg => arg != item)
    }
}

class StringArray extends Array {
    compare(arr = []) {
        if (this.length !== arr.length) {
            return false
        }
        for (let i = 0; i < this.length; i++) {
            if (this[i] !== arr[i]) {
                return false
            }
        }
        return true
    }
}

class WasmType {
    constructor(opts) {
        this.name = opts.name
        this.param = new StringArray(...opts.param)
        this.result = new StringArray(...opts.result)
    }
}

class TypeSection extends Section {
    static sectionId = 1
    constructor(opts) {
        super(opts)
    }
    addItem(typeSpec) {
        const typeObj = new WasmType(typeSpec)
        this.data.push(typeObj)
        this.wasmProgram.emit('typeAdded', typeObj)
        return typeObj
    }
    getTypeIdx(obj) {
        for (let i = 0; i < this.data.length; i++) {
            if (this.data[i] === obj) {
                return i
            }
        }
        throw new Error('Not found')
    }
    findByStr(typeStr) {

    }
    findByObj(typeObj) {
        for (const item of this.data) {
            if (!item.param.compare(typeObj.param)) {
                continue
            }
            if (!item.result.compare(typeObj.result)) {
                continue
            }
            return item
        }
        return null
    }
    byteLength() {
        let len = 1
        for (const item of this.data) {
            len += 3
            len += item.param.length
            len += item.result.length
        }
        return len
    }
    buildSection() {
        if (this.data.length === 0) {
            return
        }
        const bytes = []
        for (const { param = [], result = [] } of this.data) {
            bytes.push(0x60)
            bytes.push(param.length)
            for (const p of param) {
                bytes.push(typeToByte[p])
            }
            bytes.push(result.length)
            for (const r of result) {
                bytes.push(typeToByte[r])
            }
        }
        const bufSize = this.byteLength() + 2
        const uint8Arr = new Uint8Array(bufSize)
        uint8Arr[0] = this.constructor.sectionId
        uint8Arr[1] = bytes.length + 1
        uint8Arr[2] = this.data.length
        uint8Arr.set(new Uint8Array(bytes), 3)
        this.code = uint8Arr
        return uint8Arr
    }
    buildPrettyString(bytes) {
        const lines = []
        lines.push(
            "0x" + bytes[0].toString(16).padStart(2, "0") + ", " +
            "0x" + bytes[1].toString(16).padStart(2, "0") + ", " +
            "0x" + bytes[2].toString(16).padStart(2, "0") + ", // type"
        )

        let i = 3
        while (i < bytes.length) {
            const start = i
            if (bytes[i] === 0x60) {
                const paramsCount = bytes[i + 1]
                const resultsCountIndex = i + 2 + paramsCount
                const resultsCount = bytes[resultsCountIndex]
                const end = resultsCountIndex + 1 + resultsCount
                const arr = []
                for (let i = start; i < end; i++) {
                    arr.push("0x" + bytes[i].toString(16).padStart(2, "0"))
                }
                lines.push("    " + arr.join(", ") + ",")
                i = end
            } else {
                i++
            }
        }
        return lines.join("\n")
    }
}

class ImportSection extends Section {
    static sectionId = 2
    constructor(opts) {
        super(opts)
    }
}

class WasmFunction {
    constructor(opts) {
        this.export = opts.export
        this.name = opts.name
        this.type = opts.type
        this.body = {
            children: [],
        }
        this.locals = opts.locals || 0
        this.defaultParams = {}
    }
    setName(name) {
        this.name = name
    }
    getName() {
        return this.name
    }
    setCode(bytes) {
        const body = {
            children: []
        }
        bytes.push(0x0b)
        WasmParser.parseInstruction(bytes, 0, bytes.length, body)
    }
    setType(type) {
        this.type = type
    }
    setDefaultParam({offset, value}) {
        this.defaultParams[offset] = value
    }
    clearDefaultParam({offset}) {
        delete this.defaultParams[offset]
    }
    getDefaultParam({offset}) {
        return this.defaultParams[offset]
    }
    setExport(name) {
        this.export = name
    }
    clearExport() {
        this.export = null
    }
}

class FunctionSection extends Section {
    static sectionId = 3
    constructor(opts) {
        super(opts)
        this.currentFunction = null
    }
    addItem(funcSpec) {
        const funcObj = new WasmFunction(funcSpec)
        this.data.push(funcObj)
        this.wasmProgram.emit('functionAdded', funcObj)
        return funcObj
    }
    select(name) {
        let funcObj
        for (let i = 0; i < this.data.length; i++) {
            if (this.data[i].name === name) {
                funcObj = this.data[i]
                break
            }
        }
        if (!funcObj) {
            return
        }
        if (this.currentFunction) {
            this.emit('selectionRemoved', this.currentFunction.name)
            if (this.currentFunction === funcObj) {
                this.currentFunction = null
            } else {
                this.emit('selectionAdded', funcObj.name)
                this.currentFunction = funcObj
            }
        } else {
            this.emit('selectionAdded', funcObj.name)
            this.currentFunction = funcObj
        }
    }
    byteLength() {
        return this.data.length + 1
    }
    buildSection() {
        if (this.data.length === 0) {
            return
        }
        const uint8Arr = new Uint8Array(this.data.length + 3)
        uint8Arr[0] = this.constructor.sectionId
        uint8Arr[1] = this.byteLength()
        uint8Arr[2] = this.data.length
        for (let i = 0; i < this.data.length; i++) {
            const type = this.data[i].type
            uint8Arr[i + 3] = this.wasmProgram.types.getTypeIdx(type)
        }
        this.code = uint8Arr
    }
}

class TableSection extends Section {
    static sectionId = 4
    constructor(opts) {
        super(opts)
    }
}

class ElementSection extends Section {
    static sectionId = 9
    constructor(opts) {
        super(opts)
    }
}

class DataCountSection extends Section {
    static sectionId = 12
    constructor(opts) {
        super(opts)
    }
}

class TagSection extends Section {
    static sectionId = 13
    constructor(opts) {
        super(opts)
    }
}

class MemorySection extends Section {
    static sectionId = 5
    constructor(opts) {
        super(opts)
    }
}

class GlobalSection extends Section {
    static sectionId = 6
    constructor(opts) {
        super(opts)
    }
}
/*
        0x07, 0x07, 0x01, // export
            0x03, 0x61, 0x64, 0x64, 0x00, 0x00,
*/
class ExportSection extends Section {
    static sectionId = 7
    static exportType = {
        func: 0,
        table: 1,
        memory: 2,
        global: 3,
        tag: 4,
    }
    constructor(opts) {
        super(opts)
    }
    byteLength() {
        let len = 1
        for (const item of this.data) {
            len += 3
            len += item.name.length
        }
        return len
    }
    buildSection() {
        const bytes = []
        for (const exportObj of this.data) {
            bytes.push(exportObj.name.length)
            for (let i = 0; i < exportObj.name.length; i++) {
                const byte = exportObj.name.charCodeAt(i)
                bytes.push(byte)
            }
            const type = this.constructor.exportType[exportObj.type]
            bytes.push(type)
            bytes.push(exportObj.position)
        }
        const uint8Arr = new Uint8Array(bytes.length + 3)
        uint8Arr[0] = this.constructor.sectionId
        uint8Arr[1] = bytes.length + 1
        uint8Arr[2] = this.data.length
        uint8Arr.set(new Uint8Array(bytes), 3)
        this.code = uint8Arr
        return uint8Arr
    }
}

class StartSection extends Section {
    static sectionId = 8
    constructor(opts) {
        super(opts)
    }
}
/*
        0x0a, 0x09, 0x01, // code
            0x07, 0x00, 
                0x20, 0x00, 
                0x20, 0x01, 
                0x6a,
            0x0b,
*/
class CodeSection extends Section {
    static sectionId = 10
    constructor(opts) {
        super(opts)
    }
    computeLength(instrObj) {
        let len = 0
        if (instrObj.children) {
            len += 2
            for (const item of instrObj.children) {
                len += this.computeLength(item)
            }
        } else {
            len += 1
            if (instrObj.imm) {
                len += instrObj.imm.length
            }
        }
        return len
    }
    byteLength() {
        let len = 1
        for (const item of this.data) {
            len++
            len += item.locals
            len += this.computeLength(item.body)
        }
        return len
    }
    buildExpression(bytes, instrObj) {
        if (instrObj.opcode !== undefined) {
            bytes.push(instrObj.opcode)
        }
        if (instrObj.children) {
            for (const item of instrObj.children) {
                this.buildExpression(bytes, item)
            }
            bytes.push(0x0b)
        } else if (instrObj.imm) {
            for (const item of instrObj.imm) {
                bytes.push(item)
            }
        }
    }
    buildSection() {
        const bytes = []
        for (const funcObj of this.data) {
            const len = this.computeLength(funcObj.body)
            bytes.push(len)
            bytes.push(funcObj.locals)
            this.buildExpression(bytes, funcObj.body)
        }
        const uint8Arr = new Uint8Array(bytes.length + 3)
        uint8Arr[0] = this.constructor.sectionId
        uint8Arr[1] = bytes.length + 1
        uint8Arr[2] = this.data.length
        uint8Arr.set(new Uint8Array(bytes), 3)
        this.code = uint8Arr
        return uint8Arr
    }
}

class DataSection extends Section {
    static sectionId = 11
    constructor(opts) {
        super(opts)
    }
}

class WasmProgram extends EventEmitter {
    static magic =  new Uint8Array([
        0x00, 0x61, 0x73, 0x6d, 
        0x01, 0x00, 0x00, 0x00
    ])
    constructor(opts) {
        super(opts)

        this.types = new TypeSection({wasmProgram: this})
        this.imports = new ImportSection({wasmProgram: this})
        this.functions = new FunctionSection({wasmProgram: this})
        this.tables = new TableSection({wasmProgram: this})
        this.memories = new MemorySection({wasmProgram: this})
        this.globals = new GlobalSection({wasmProgram: this})
        this.exports = new ExportSection({wasmProgram: this})
        this.start = new StartSection({wasmProgram: this})
        this.code = new CodeSection({wasmProgram: this})
        this.data = new DataSection({wasmProgram: this})

        this.sections = [
            this.types,
            this.imports,
            this.functions,
            this.tables,
            this.memories,
            this.globals,
            this.exports,
            this.start,
            this.code,
            this.data,
        ]

        this.program = null
    }
    static fromArray(arr) {
        const parser = new WasmParser()
        parser.parse(arr)
        return parser.program
    }
    static fromBase64() {

    }
    addType(spec) {
        return this.types.addItem(spec)
    }
    deleteType(typeObj) {
        this.types.delete(typeObj)
        this.emit('typeDeleted', typeObj)
    }
    getType(param) {
        return this.types.findByObj(param)
    }
    addFunction(obj) {
        let type, body
        if (obj.type) {
            type = this.types.findByObj(obj.type)
            if (!type) {
                throw new Error('Type is not found')
            }
        }
        return this.functions.addItem({
            type,
            name: obj.name,
            export: obj.export,
            body,
        })
    }
    addExport(obj) {
        this.exports.addItem(obj)
    }
    selectFunction(name) {
        this.functions.select(name)
    }
    merge(arr) {
        let len = 0
        for (const uint8arr of arr) {
            len += uint8arr.byteLength
        }
        const merged = new Uint8Array(len)
        let offset = 0
        for (const uint8arr of arr) {
            merged.set(uint8arr, offset)
            offset += uint8arr.byteLength
        }
        return merged
    }
    build() {
        for (const item of this.functions.data) {
            this.code.addItem({
                locals: item.locals,
                body: item.body,
            })
        }
        let position = 0
        for (const item of this.functions.data) {
            if (item.export) {
                this.addExport({
                    name: item.export,
                    type: 0,
                    idx: position++,
                    ref: item,
                })
            }
        }
        const sections = [
            this.constructor.magic,
        ]
        for (const section of this.sections) {
            section.buildSection()
            if (section.code) {
                sections.push(section.code)
            }
        }
        console.log(sections)
        this.program = this.merge(sections)
    }
    toHexString(start, len) {
        if (!this.program) {
            return ''
        }
        if (start === undefined) start = 0
        if (len === undefined) len = this.program.byteLength
        const bytes = this.program.subarray(start, start + len)
        const arr = []
        for (const byte of bytes) {
            arr.push('0x' + byte.toString(16).padStart(2, '0'))
        }
        return arr.join(', ')
    }
}
