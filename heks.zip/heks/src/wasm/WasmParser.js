
let byteToInstr1 = {
    0x02: {name: 'block', block: true},
    0x03: {name: 'loop', block: true},
    0x04: {name: 'if', block: true},
    0x05: {name: 'else', block: true},
    0x20: {name: 'local.get', imm: 1},
    0x6a: {name: 'i32.add'},
    0x6c: {name: 'i32.mul'},
}

const blockInstructions = new Set([
    0x02, // block
    0x03, // loop
    0x04, // if
    0x05, // else
])
function prepareOpcodes(arr) {
    const obj = {}
    for (const [opcode, name, group, imm] of arr) {
        obj[opcode] = {
            name,
            imm,
            block: blockInstructions.has(opcode)
        }
    }
    return obj
}
const opcodeSubset = [
    [0x02, 'block', 'GroupName', 0],
    [0x03, 'loop', 'GroupName', 0],
    [0x04, 'if', 'GroupName', 0],
    [0x05, 'else', 'GroupName', 0],
    [0x20, 'local.get', 'GroupName', 1],
    [0x6a, 'i32.add', 'GroupName', 0],
    [0x6c, 'i32.mul', 'GroupName', 0],
]
const byteToInstr = prepareOpcodes(opcodeSubset)

class WasmParser {
    static sectionIds = {
        1: 'type',
        2: 'import',
        3: 'function',
        4: 'table',
        5: 'memory',
        6: 'global',
        7: 'export',
        8: 'start',
        9: 'element',
        10: 'code',
        11: 'data',
        12: 'data_count',
        13: 'tag',
    }
    constructor() {
    }
    parse(arr) {
        this.program = new WasmProgram()
        for (let i = 0; i < arr.length; i++) {
            arr[i] = Number(arr[i])
        }
        this.program.program = new Uint8Array(arr)
        let curPos = 0
        for (; curPos < 8; curPos++) {
            if (arr[curPos] !== this.program.constructor.magic[curPos]) {
                throw new Error('Parser error')
            }
        }
        while ((curPos + 3) < arr.length) {
            let sectionId = arr[curPos]
            let sectionSize = arr[curPos + 1]
            const startOff = curPos + 2
            const endOff = startOff + sectionSize
            if (sectionId === 1) {
                this.parseTypes(arr, startOff, endOff)
            } else if (sectionId === 2) {
                this.parseImports(arr, startOff, endOff)
            } else if (sectionId === 3) {
                this.parseFunctions(arr, startOff, endOff)
            } else if (sectionId === 4) {
                this.parseTables(arr, startOff, endOff)
            } else if (sectionId === 5) {
                this.parseMemory(arr, startOff, endOff)
            } else if (sectionId === 6) {
                this.parseGlobals(arr, startOff, endOff)
            } else if (sectionId === 7) {
                this.parseExports(arr, startOff, endOff)
            } else if (sectionId === 8) {
                this.parseStart(arr, startOff, endOff)
            } else if (sectionId === 9) {
                this.parseElements(arr, startOff, endOff)
            } else if (sectionId === 10) {
                this.parseCode(arr, startOff, endOff)
            } else if (sectionId === 11) {
                this.parseData(arr, startOff, endOff)
            } else if (sectionId === 12) {
                this.parseDataCount(arr, startOff, endOff)
            } else if (sectionId === 13) {
                this.parseTags(arr, startOff, endOff)
            } else {

            }
            curPos = endOff
        }
        // console.log(this.program)
        // console.log(this.program.functions)
        return this.program
    }
    /*
        5.3.1 Number Types          p.184
    */
    parseTypeItems(arr, pos, output) {
        const itemCount = arr[pos]
        pos++
        for (let i = 0; i < itemCount; i++) {
            const byte = arr[pos]
            let type
            if (byte === 0x7C) {
                type = 'f64'
            } else if (byte === 0x7D) {
                type = 'f32'
            } else if (byte === 0x7E) {
                type = 'i64'
            } else if (byte === 0x7F) {
                type = 'i32'
            } else {
                throw new Error('Unknown type')
            }
            output.push(type)
            pos++
        }
        return pos
    }
    parseTypes(arr, startOff, endOff) {
        let pos = startOff
        const itemCount = arr[pos]
        pos++
        let typeIdx = 0
        while (pos < endOff) {
            const obj = {
                type: 'func',
                param: [],
                result: [],
                typeIdx,
            }
            pos++
            typeIdx++
            pos = this.parseTypeItems(arr, pos, obj.param)
            pos = this.parseTypeItems(arr, pos, obj.result)
            this.program.addType(obj)
        }
        if (this.program.types.len() !== itemCount) {
            throw new Error('Item count is wrong')
        }
    }
    parseImports(arr, startOff, endOff) {
        return arr.slice(startOff, endOff)
    }
    parseFunctions(arr, startOff, endOff) {
        let pos = startOff
        const itemCount = arr[pos]
        pos++
        if (this.program.types === undefined) {
            throw new Error('Types must be parsed before functions')
        }
        let functionIdx = 0
        while (pos < endOff) {
            const type = this.program.types.getItem(arr[pos])
            this.program.functions.addItem({
                type,
                functionIdx,
            })
            functionIdx++
            pos++
        }
        if (this.program.functions.len() !== itemCount) {
            throw new Error('Item count is wrong')
        }
    }
    parseTables(arr, startOff, endOff) {
        return arr.slice(startOff, endOff)
    }
    parseMemory(arr, startOff, endOff) {
        return arr.slice(startOff, endOff)
    }
    parseGlobals(arr, startOff, endOff) {
        return arr.slice(startOff, endOff)
    }
    parseString(arr, pos, len) {
        let str = ''
        const upperBound = pos + len
        for (let i = pos; i < upperBound; i++) {
            str += String.fromCharCode(arr[i])
        }
        return str
    }
    parseExports(arr, startOff, endOff) {
        let pos = startOff
        const itemCount = arr[pos]
        pos++
        if (this.program.functions === undefined) {
            throw new Error('Functions must be parsed before exports')
        }
        while (pos < endOff) {
            const strLen = arr[pos]
            pos++
            const name = this.parseString(arr, pos, strLen)
            pos += strLen
            const type = arr[pos]
            pos++
            const idx = arr[pos]
            pos++
            let ref
            if (type === 0) {
                ref = this.program.functions.getItem(idx)
            } else if (type === 1) {
                ref = this.program.tables.getItem(idx)
            } else if (type === 2) {
                ref = this.program.memory.getItem(idx)
            } else if (type === 3) {
                ref = this.program.globals.getItem(idx)
            } else if (type === 4) {
                ref = this.program.tags.getItem(idx)
            } else {
                throw new Error('Unknown export type')
            }
            if (ref === undefined) {
                throw new Error('Object not found')
            }
            const obj = {
                name,
                type,
                idx,
                ref,
            }
            ref.export = obj
            this.program.addExport(obj)
        }
        if (this.program.exports.len() !== itemCount) {
            throw new Error('Item count is wrong')
        }
    }
    parseStart(arr, startOff, endOff) {
        return arr.slice(startOff, endOff)
    }
    parseElements(arr, startOff, endOff) {
        return arr.slice(startOff, endOff)
    }
    /*
        2.5.7 Functions         p.29
        5.4.9 Expressions       p.201
    */
    static parseInstruction(arr, startOff, endOff, instrObj) {
        let pos = startOff
        let endInstrFound
        while (pos < endOff) {
            const byte = arr[pos]
            if (byte === 0x0B) {
                endInstrFound = true
                pos++
                break
            }
            let childInstr
            const instrInfo = byteToInstr[byte]
            if (instrInfo.block) {
                childInstr = {
                    name: instrInfo.name,
                    opcode: byte,
                    children: [],
                }
                pos = this.parseInstruction(arr, pos + 1, endOff, childInstr)
                instrObj.children.push(childInstr)
            } else if (instrInfo) {
                childInstr = {
                    name: instrInfo.name,
                    opcode: byte,
                }
                pos++
                if (instrInfo.imm) {
                    childInstr.imm = []
                    for (let i = 0; i < instrInfo.imm; i++) {
                        childInstr.imm.push(arr[pos])
                        pos++
                    }
                }
                instrObj.children.push(childInstr)
            } else {
                throw new Error('Cannot find instruction')
            }
        }
        if (pos < endOff) {
            throw new Error('Superflous bytes')
        }
        if (!endInstrFound) {
            throw new Error('End instruction not found')
        }
        return pos
    }
    parseCode(arr, startOff, endOff) {
        let pos = startOff
        const itemCount = arr[pos]
        pos++
        if (this.program.functions === undefined) {
            throw new Error('Functions must be parsed before code')
        }
        let idx = 0
        let counter = 0
        while (pos < endOff) {
            const funcObj = this.program.functions.getItem(idx)
            if (funcObj === undefined) {
                throw new Error('Function not found')
            }
            const size = arr[pos] - 1
            pos++
            funcObj.locals = arr[pos]
            pos++
            funcObj.body = {
                children: [],
            }
            const newPos = this.constructor.parseInstruction(arr, pos, pos + size, funcObj.body)
            // console.log(newPos, pos + size)
            pos += size
            idx++
            counter++
            this.program.code.addItem(funcObj)
        }
        if (counter !== itemCount) {
            throw new Error('Item count is wrong')
        }
        if (this.program.functions.len() !== itemCount) {
            throw new Error('Item count is wrong')
        }
    }
    parseData(arr, startOff, endOff) {
        return arr.slice(startOff, endOff)
    }
    parseDataCount(arr, startOff, endOff) {
        return arr.slice(startOff, endOff)
    }
    parseTags(arr, startOff, endOff) {
        return arr.slice(startOff, endOff)
    }
}



