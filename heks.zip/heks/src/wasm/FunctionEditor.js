class FunctionEditor extends Dialog {
    constructor(opts) {
        super(opts)
        
        this.printMessage = this.app.printMessage

        this.typeInput = this.container.querySelector('.type')
        this.identifierInput = this.container.querySelector('.identifier')
        this.exportInput = this.container.querySelector('.export_name')
    }
    show() {
        const type = app.wasmProgram.types.currentType
        if (type) {
            this.typeInput.value = type.name
        } else {
            this.typeInput.value = ''
        }
        this.identifierInput.value = ''
        this.exportInput.value = ''
        super.show()
    }
    setType(name) {
        this.typeInput.value = name
    }
    setName(name) {
        this.identifierInput.value = name
    }
    setExport(name) {
        this.exportInput.value = name
    }
    onOkClick() {
        const type = this.app.wasmProgram.types.currentType
        if (!type) {
            this.printMessage('Select type')
            return
        }
        this.hide()
        this.emit('ok', {
            type, 
            name: this.identifierInput.value, 
            export: this.exportInput.value,
        })
    }
}
