class TypeList extends Widget {
    constructor(opts) {
        super(opts)
        this.app.wasmProgram.addListener('typeAdded', this.onTypeAdded.bind(this))
        this.app.wasmProgram.addListener('typeDeleted', this.onTypeDeleted.bind(this))
        this.onRowClick = this.onRowClick.bind(this)
        this.typeElemToTypeObjMap = new Map()
        this.typeObjToTypeElemMap = new Map()
        this.currentType = null
    }
    select(type) {

    }
    clearSelection() {

    }
    onRowClick(event) {
        const elem = event.currentTarget
        const obj = this.typeElemToTypeObjMap.get(elem)
        if (this.currentType) {
            const oldElem = this.typeObjToTypeElemMap.get(this.currentType)
            oldElem.classList.remove('selected')
            if (obj === this.currentType) {
                this.currentType = null
            } else {
                this.currentType = obj
                elem.classList.add('selected')
                this.emit('typeSelected', this.currentType)
            }
        } else {
            this.currentType = obj
            elem.classList.add('selected')
            this.emit('typeSelected', this.currentType)
        }
    }
    onTypeAdded(obj) {
        const rowElem = this.buildRow(obj)
        rowElem.addEventListener('click', this.onRowClick)
        this.container.append(rowElem)
    }
    onTypeDeleted(typeObj) {
        const typeElem = this.app.wasmProgram.types.typeObjToTypeElemMap.get(typeObj)
        typeElem.remove()
    }
    show() {
        super.show()
        this.emit('show')
    }
    hide() {
        super.hide()
        this.emit('hide')
    }
    handleParts(keyword, dest, src) {
        dest.push('<div class="space"> </div>')
        dest.push('<div class="paren">(</div>')
        dest.push(`<div class="keyword">${keyword}</div>`)
        dest.push('<div class="space"> </div>')
        const parts = []
        for (const item of src) {
            parts.push(`<div class="keyword">${item}</div>`)
        }
        dest.push(parts.join('<div class="space"> </div>'))
        dest.push('<div class="paren">)</div>')
    }
    buildRow(obj) {
        const rowElem = document.createElement('div')
        rowElem.classList.add('wat')
        const typeDef = []
        typeDef.push('<div class="paren">(</div>')
        typeDef.push('<div class="keyword">type</div>')
        typeDef.push('<div class="space"> </div>')
        if (obj.name) {
            typeDef.push(`<div class="identifier">$${obj.name}</div>`)
            typeDef.push('<div class="space"> </div>')
        }
        typeDef.push('<div class="paren">(</div>')
        typeDef.push('<div class="keyword">func</div>')
        if (obj.param.length) {
            this.handleParts('param', typeDef, obj.param)
        }
        if (obj.result.length) {
            this.handleParts('result', typeDef, obj.result)
        }
        typeDef.push('<div class="paren">)</div>')
        typeDef.push('<div class="paren">)</div>')
        rowElem.innerHTML = typeDef.join('')
        this.typeElemToTypeObjMap.set(rowElem, obj)
        this.typeObjToTypeElemMap.set(obj, rowElem)
        return rowElem
    }
}
