const typeToByte = {
    f64: 0x7c,
    f32: 0x7d,
    i64: 0x7e,
    i32: 0x7f,
}

const byteToType = {
    0x7c: 'f64',
    0x7d: 'f32',
    0x7e: 'i64',
    0x7f: 'i32',
}

/*
    2.4 Instructions                p.18
    7.10 Index of Instructions      p.294
*/
const wasmOpcodes = [
    [0x00, 'unreachable', 'Parametric'],
    [0x01, 'nop', 'Parametric'],
    [0x02, 'block', 'Control'],
    [0x03, 'loop', 'Control'],
    [0x04, 'if', 'Control'],
    [0x05, 'else', 'Control'],
    [0x06, undefined],
    [0x07, undefined],
    [0x08, 'throw', 'Control'],
    [0x09, undefined],
    [0x0a, 'throw_ref', 'Control'],
    [0x0b, 'end', 'Control'],
    [0x0c, 'br', 'Control'],
    [0x0d, 'br_if', 'Control'],
    [0x0e, 'br_table', 'Control'],
    [0x0f, 'return', 'Control'],
    [0x10, 'call', 'Control'],
    [0x11, 'call_indirect', 'Control'],
    [0x12, 'return_call', 'Control'],
    [0x13, 'return_call_indirect', 'Control'],
    [0x14, 'call_ref', 'Control'],
    [0x15, 'return_call_ref', 'Control'],
    [0x16, undefined],
    [0x17, undefined],
    [0x18, undefined],
    [0x19, undefined],
    [0x1a, 'drop', 'Parametric'],
    [0x1b, 'select', 'Parametric'],
    [0x1c, 'select', 'Parametric'],
    [0x1d, undefined],
    [0x1e, undefined],
    [0x1f, 'try_table', 'Control'],
    [0x20, 'local.get', 'Variable'],
    [0x21, 'local.set', 'Variable'],
    [0x22, 'local.tee', 'Variable'],
    [0x23, 'global.get', 'Variable'],
    [0x24, 'global.set', 'Variable'],
    [0x25, 'table.set', 'Table'],
    [0x26, 'table.get', 'Table'],
    [0x27, undefined],
    [0x28, 'i32.load', 'Memory'],
    [0x29, 'i64.load', 'Memory'],
    [0x2a, 'f32.load', 'Memory'],
    [0x2b, 'f64.load', 'Memory'],
    [0x2c, 'i32.load8_s', 'Memory'],
    [0x2d, 'i32.load8_u', 'Memory'],
    [0x2e, 'i32.load16_s', 'Memory'],
    [0x2f, 'i32.load16_u', 'Memory'],
    [0x30, 'i64.load8_s', 'Memory'],
    [0x31, 'i64.load8_u', 'Memory'],
    [0x32, 'i64.load16_s', 'Memory'],
    [0x33, 'i64.load16_u', 'Memory'],
    [0x34, 'i64.load32_s', 'Memory'],
    [0x35, 'i64.load32_u', 'Memory'],
    [0x36, 'i32.store', 'Memory'],
    [0x37, 'i64.store', 'Memory'],
    [0x38, 'f32.store', 'Memory'],
    [0x39, 'f64.store', 'Memory'],
    [0x3a, 'i32.store8', 'Memory'],
    [0x3b, 'i32.store16', 'Memory'],
    [0x3c, 'i64.store8', 'Memory'],
    [0x3d, 'i64.store16', 'Memory'],
    [0x3e, 'i64.store32', 'Memory'],
    [0x3f, 'memory.size', 'Memory'],
    [0x40, 'memory.grow', 'Memory'],
    [0x41, 'i32.const', 'Numeric.Constant'],
    [0x42, 'i64.const', 'Numeric.Constant'],
    [0x43, 'f32.const', 'Numeric.Constant'],
    [0x44, 'f64.const', 'Numeric.Constant'],
    [0x45, 'i32.eqz', 'Numeric.Test'],
    [0x46, 'i32.eq', 'Numeric.Comparison'],
    [0x47, 'i32.ne', 'Numeric.Comparison'],
    [0x48, 'i32.lt_s', 'Numeric.Comparison'],
    [0x49, 'i32.lt_u', 'Numeric.Comparison'],
    [0x4a, 'i32.gt_s', 'Numeric.Comparison'],
    [0x4b, 'i32.gt_u', 'Numeric.Comparison'],
    [0x4c, 'i32.le_s', 'Numeric.Comparison'],
    [0x4d, 'i32.le_u', 'Numeric.Comparison'],
    [0x4e, 'i32.ge_s', 'Numeric.Comparison'],
    [0x4f, 'i32.ge_u', 'Numeric.Comparison'],
    [0x50, 'i64.eqz', 'Numeric.Test'],
    [0x51, 'i64.eq', 'Numeric.Comparison'],
    [0x52, 'i64.ne', 'Numeric.Comparison'],
    [0x53, 'i64.lt_s', 'Numeric.Comparison'],
    [0x54, 'i64.lt_u', 'Numeric.Comparison'],
    [0x55, 'i64.gt_s', 'Numeric.Comparison'],
    [0x56, 'i64.gt_u', 'Numeric.Comparison'],
    [0x57, 'i64.le_s', 'Numeric.Comparison'],
    [0x58, 'i64.le_u', 'Numeric.Comparison'],
    [0x59, 'i64.ge_s', 'Numeric.Comparison'],
    [0x5a, 'i64.ge_u', 'Numeric.Comparison'],
    [0x5b, 'f32.eq', 'Numeric.Comparison'],
    [0x5c, 'f32.ne', 'Numeric.Comparison'],
    [0x5d, 'f32.lt', 'Numeric.Comparison'],
    [0x5e, 'f32.gt', 'Numeric.Comparison'],
    [0x5f, 'f32.le', 'Numeric.Comparison'],
    [0x60, 'f32.ge', 'Numeric.Comparison'],
    [0x61, 'f64.eq', 'Numeric.Comparison'],
    [0x62, 'f64.ne', 'Numeric.Comparison'],
    [0x63, 'f64.lt', 'Numeric.Comparison'],
    [0x64, 'f64.gt', 'Numeric.Comparison'],
    [0x65, 'f64.le', 'Numeric.Comparison'],
    [0x66, 'f64.ge', 'Numeric.Comparison'],
    [0x67, 'i32.clz', 'Numeric.Unary'],
    [0x68, 'i32.ctz', 'Numeric.Unary'],
    [0x69, 'i32.popcnt', 'Numeric.Unary'],
    [0x6a, 'i32.add', 'Numeric.Binary'],
    [0x6b, 'i32.sub', 'Numeric.Binary'],
    [0x6c, 'i32.mul', 'Numeric.Binary'],
    [0x6d, 'i32.div_s', 'Numeric.Binary'],
    [0x6e, 'i32.div_u', 'Numeric.Binary'],
    [0x6f, 'i32.rem_s', 'Numeric.Binary'],
    [0x70, 'i32.rem_u', 'Numeric.Binary'],
    [0x71, 'i32.and', 'Numeric.Binary'],
    [0x72, 'i32.or', 'Numeric.Binary'],
    [0x73, 'i32.xor', 'Numeric.Binary'],
    [0x74, 'i32.shl', 'Numeric.Binary'],
    [0x75, 'i32.shr_s', 'Numeric.Binary'],
    [0x76, 'i32.shr_u', 'Numeric.Binary'],
    [0x77, 'i32.rotl', 'Numeric.Binary'],
    [0x78, 'i32.rotr', 'Numeric.Binary'],
    [0x79, 'i64.clz', 'Numeric.Unary'],
    [0x7a, 'i64.ctz', 'Numeric.Unary'],
    [0x7b, 'i64.popcnt', 'Numeric.Unary'],
    [0x7c, 'i64.add', 'Numeric.Binary'],
    [0x7d, 'i64.sub', 'Numeric.Binary'],
    [0x7e, 'i64.mul', 'Numeric.Binary'],
    [0x7f, 'i64.div_s', 'Numeric.Binary'],
    [0x80, 'i64.div_u', 'Numeric.Binary'],
    [0x81, 'i64.rem_s', 'Numeric.Binary'],
    [0x82, 'i64.rem_u', 'Numeric.Binary'],
    [0x83, 'i64.and', 'Numeric.Binary'],
    [0x84, 'i64.or', 'Numeric.Binary'],
    [0x85, 'i64.xor', 'Numeric.Binary'],
    [0x86, 'i64.shl', 'Numeric.Binary'],
    [0x87, 'i64.shr_s', 'Numeric.Binary'],
    [0x88, 'i64.shr_u', 'Numeric.Binary'],
    [0x89, 'i64.rotl', 'Numeric.Binary'],
    [0x8a, 'i64.rotr', 'Numeric.Binary'],
    [0x8b, 'f32.abs', 'Numeric.Unary'], // unop 1
    [0x8c, 'f32.neg', 'Numeric.Unary'], // unop 2
    [0x8d, 'f32.ceil', 'Numeric.Unary'], // unop 4
    [0x8e, 'f32.floor', 'Numeric.Unary'], // unop 5
    [0x8f, 'f32.trunc', 'Numeric.Unary'], // unop 6
    [0x90, 'f32.nearest', 'Numeric.Unary'], // unop 7
    [0x91, 'f32.sqrt', 'Numeric.Unary'], // unop 3
    [0x92, 'f32.add', 'Numeric.Binary'],
    [0x93, 'f32.sub', 'Numeric.Binary'],
    [0x94, 'f32.mul', 'Numeric.Binary'],
    [0x95, 'f32.div', 'Numeric.Binary'],
    [0x96, 'f32.min', 'Numeric.Binary'],
    [0x97, 'f32.max', 'Numeric.Binary'],
    [0x98, 'f32.copysign', 'Numeric.Binary'],
    [0x99, 'f64.abs', 'Numeric.Unary'],
    [0x9a, 'f64.neg', 'Numeric.Unary'],
    [0x9b, 'f64.ceil', 'Numeric.Unary'],
    [0x9c, 'f64.floor', 'Numeric.Unary'],
    [0x9d, 'f64.trunc', 'Numeric.Unary'],
    [0x9e, 'f64.nearest', 'Numeric.Unary'],
    [0x9f, 'f64.sqrt', 'Numeric.Unary'],
    [0xa0, 'f64.add', 'Numeric.Binary'],
    [0xa1, 'f64.sub', 'Numeric.Binary'],
    [0xa2, 'f64.mul', 'Numeric.Binary'],
    [0xa3, 'f64.div', 'Numeric.Binary'],
    [0xa4, 'f64.min', 'Numeric.Binary'],
    [0xa5, 'f64.max', 'Numeric.Binary'],
    [0xa6, 'f64.copysign', 'Numeric.Binary'],
    [0xa7, 'i32.wrap_i64', 'Numeric.Conversion'],
    [0xa8, 'i32.trunc_f32_s', 'Numeric.Conversion'],
    [0xa9, 'i32.trunc_f32_u', 'Numeric.Conversion'],
    [0xaa, 'i32.trunc_f64_s', 'Numeric.Conversion'],
    [0xab, 'i32.trunc_f64_u', 'Numeric.Conversion'],
    [0xac, 'i64.extend_i32_s', 'Numeric.Conversion'],
    [0xad, 'i64.extend_i32_u', 'Numeric.Conversion'],
    [0xae, 'i64.trunc_f32_s', 'Numeric.Conversion'],
    [0xaf, 'i64.trunc_f32_u', 'Numeric.Conversion'],
    [0xb0, 'i64.trunc_f64_s', 'Numeric.Conversion'],
    [0xb1, 'i64.trunc_f64_u', 'Numeric.Conversion'],
    [0xb2, 'f32.convert_i32_s', 'Numeric.Conversion'],
    [0xb3, 'f32.convert_i32_u', 'Numeric.Conversion'],
    [0xb4, 'f32.convert_i64_s', 'Numeric.Conversion'],
    [0xb5, 'f32.convert_i64_u', 'Numeric.Conversion'],
    [0xb6, 'f32.demote_f64', 'Numeric.Conversion'],
    [0xb7, 'f64.convert_i32_s', 'Numeric.Conversion'],
    [0xb8, 'f64.convert_i32_u', 'Numeric.Conversion'],
    [0xb9, 'f64.convert_i64_s', 'Numeric.Conversion'],
    [0xba, 'f64.convert_i64_u', 'Numeric.Conversion'],
    [0xbb, 'f64.promote_f32', 'Numeric.Conversion'],
    [0xbc, 'i32.reinterpret_f32', 'Numeric.Conversion'],
    [0xbd, 'i64.reinterpret_f64', 'Numeric.Conversion'],
    [0xbe, 'f32.reinterpret_i32', 'Numeric.Conversion'],
    [0xbf, 'f64.reinterpret_i64', 'Numeric.Conversion'],
    [0xc0, 'i32.extend8_s', 'Numeric.Conversion'],
    [0xc1, 'i32.extend16_s', 'Numeric.Conversion'],
    [0xc2, 'i64.extend8_s', 'Numeric.Conversion'],
    [0xc3, 'i64.extend16_s', 'Numeric.Conversion'],
    [0xc4, 'i64.extend32_s', 'Numeric.Conversion'],
    [0xc5, undefined],
    [0xc6, undefined],
    [0xc7, undefined],
    [0xc8, undefined],
    [0xc9, undefined],
    [0xca, undefined],
    [0xcb, undefined],
    [0xcc, undefined],
    [0xcd, undefined],
    [0xce, undefined],
    [0xcf, undefined],
    [0xd0, 'ref.null', 'Reference'], // 2 (7)
    [0xd1, 'ref.is_null', 'Reference'], // 3 (7)
    [0xd2, 'ref.func', 'Reference'], // 1 (7)
    [0xd3, 'ref.eq', 'Reference'], // 5 (7)
    [0xd4, 'ref.as_non_null', 'Reference'], // 4 (7)
    [0xd5, 'br_on_null', 'Control'],
    [0xd6, 'br_on_non_null', 'Control'],
    [0xd7, undefined],
    [0xd8, undefined],
    [0xd9, undefined],
    [0xda, undefined],
    [0xdb, undefined],
    [0xdc, undefined],
    [0xdd, undefined],
    [0xde, undefined],
    [0xdf, undefined],
    [0xe0, undefined],
    [0xe1, undefined],
    [0xe2, undefined],
    [0xe3, undefined],
    [0xe4, undefined],
    [0xe5, undefined],
    [0xe6, undefined],
    [0xe7, undefined],
    [0xe8, undefined],
    [0xe9, undefined],
    [0xea, undefined],
    [0xeb, undefined],
    [0xec, undefined],
    [0xed, undefined],
    [0xee, undefined],
    [0xef, undefined],
    [0xf0, undefined],
    [0xf1, undefined],
    [0xf2, undefined],
    [0xf3, undefined],
    [0xf4, undefined],
    [0xf5, undefined],
    [0xf6, undefined],
    [0xf7, undefined],
    [0xf8, undefined],
    [0xf9, undefined],
    [0xfa, undefined],
    [0xfb, 'prefix', 'Prefix'],
    [0xfc, 'prefix', 'Prefix'],
    [0xfd, 'prefix', 'Prefix'],
    [0xfe, undefined],
    [0xff, undefined],
]

const instrCategories = {
    'Parametric': {sec: '2.4.1', color: '#94df79'},
    'Control': {sec: '2.4.2', color: '#d4a2d9'},
    'Variable': {sec: '2.4.3', color: '#86e6b5'},
    'Table': {sec: '2.4.4', color: '#75d46c'},
    'Memory': {sec: '2.4.5', color: '#e7ca83'},
    'Reference': {sec: '2.4.6', color: '#89dda6'},
    'Aggregate': {sec: '2.4.7', color: '#efc28d'},
    'Numeric.Constant': {sec: '2.4.8', color: '#7cd87e'},
    'Numeric.Unary': {sec: '2.4.8', color: '#764bad'},
    'Numeric.Binary': {sec: '2.4.8', color: '#89cc57'},
    'Numeric.Test': {sec: '2.4.8', color: '#bfab45'},
    'Numeric.Comparison': {sec: '2.4.8', color: '#c962a5'},
    'Numeric.Conversion': {sec: '2.4.8', color: '#ec5f66'},
    'Vector': {sec: '2.4.9', color: '#d86acd'},
    'Prefix': {sec: null, color: '#f16161'},
    'reserved': {sec: null, color: '#a5a5a5'},
}

const extensions = [
    
    ['00', 'table.init', 'Table'],
    ['00', 'elem.drop', 'Table'],
    ['00', 'table.copy', 'Table'],
    ['00', 'table.grow', 'Table'],
    ['00', 'table.size', 'Table'],
    ['00', 'table.fill', 'Table'],
]

const extensions_fb = [
    [0x00, '', ''],
    [0x01, '', ''],
    [0x02, '', ''],
    [0x03, '', ''],
    [0x04, '', ''],
    [0x05, '', ''],
    [0x06, '', ''],
    [0x07, '', ''],
    [0x08, '', ''],
    [0x09, '', ''],
    [0x0a, '', ''],
    [0x0b, '', ''],
    [0x0c, '', ''],
    [0x0d, '', ''],
    [0x0e, '', ''],
    [0x0f, '', ''],
    [0x10, '', ''],
    [0x11, '', ''],
    [0x12, '', ''],
    [0x13, '', ''],
    [0x14, 'ref.test', 'Reference'], // 6 (7)
    [0x15, 'ref.test', 'Reference'], // 6 (7)
    [0x16, 'ref.cast', 'Reference'], // 7 (7)
    [0x17, 'ref.cast', 'Reference'], // 7 (7)
    [0x18, '', ''],
    [0x19, '', ''],
    [0x1a, '', ''],
    [0x1b, '', ''],
    [0x1c, '', ''],
    [0x1d, '', ''],
    [0x1e, '', ''],
]

const extensions_fc = [
    [0x00, 'i32.trunc_sat_f32_s', ''],
    [0x01, 'i32.trunc_sat_f32_u', ''],
    [0x02, 'i32.trunc_sat_f64_s', ''],
    [0x03, 'i32.trunc_sat_f64_u', ''],
    [0x04, 'i64.trunc_sat_f32_s', ''],
    [0x05, 'i64.trunc_sat_f32_u', ''],
    [0x06, 'i64.trunc_sat_f64_s', ''],
    [0x07, 'i64.trunc_sat_f64_u', ''],
    [0x08, 'memory.init', 'Memory'],
    [0x09, 'data.drop', 'Memory'],
    [0x0a, 'memory.copy', 'Memory'],
    [0x0b, 'memory.fill', 'Memory'],
    [0x0c, 'table.init', 'Table'],
    [0x0d, 'elem.drop', 'Table'],
    [0x0e, 'table.copy', 'Table'],
    [0x0f, 'table.grow', 'Table'],
    [0x10, 'table.size', 'Table'],
    [0x11, 'table.fill', 'Table'],
]

/*
    there are 275 items in this group
    p.300
*/
const extensions_fd = [
    [0, '00', 'v128.load'],
    [1, '01', 'v128.load8x8_s'],
    [2, '02', 'v128.load8x8_u'],
    [3, '03', 'v128.load16x4_s'],
    [4, '04', 'v128.load16x4_u'],
    [5, '05', 'v128.load32x2_s'],
    [6, '06', 'v128.load32x2_u'],
    [7, '07', 'v128.load8_splat'],
    [8, '08', 'v128.load16_splat'],
    [9, '09', 'v128.load32_splat'],
    [10, '0a', 'v128.load64_splat'],
    [11, '0b', 'v128.store'],
    [12, '0c', 'v128.const'],
    [13, '0d', ''],
    [14, '0e', ''],
    [15, '0f', ''],
    [16, '10', ''],
    [17, '11', ''],
    [18, '12', ''],
    [19, '13', ''],
    [20, '14', ''],
    [21, '15', ''],
    [22, '16', ''],
    [23, '17', ''],
    [24, '18', ''],
    [25, '19', ''],
    [26, '1a', ''],
    [27, '1b', ''],
    [28, '1c', ''],
    [29, '1d', ''],
    [30, '1e', ''],
    [31, '1f', ''],
    [32, '20', ''],
    [33, '21', ''],
    [34, '22', ''],
    [35, '23', 'i8x16.eq'],
    [36, '24', 'i8x16.ne'],
    [37, '25', 'i8x16.lt_s'],
    [38, '26', 'i8x16.lt_u'],
    [39, '27', 'i8x16.gt_s'],
    [40, '28', 'i8x16.gt_u'],
    [41, '29', 'i8x16.le_s'],
    [42, '2a', 'i8x16.le_u'],
    [43, '2b', 'i8x16.ge_s'],
    [44, '2c', 'i8x16.ge_u'],
    [45, '2d', 'i16x8.eq'],
    [46, '2e', 'i16x8.ne'],
    [47, '2f', 'i16x8.lt_s'],
    [48, '30', 'i16x8.lt_u'],
    [49, '31', 'i16x8.gt_s'],
    [50, '32', 'i16x8.gt_u'],
    [51, '33', 'i16x8.le_s'],
    [52, '34', 'i16x8.le_u'],
    [53, '35', 'i16x8.ge_s'],
    [54, '36', 'i16x8.ge_u'],
    [55, '37', 'i32x4.eq'],
    [56, '38', 'i32x4.ne'],
    [57, '39', 'i32x4.lt_s'],
    [58, '3a', 'i32x4.lt_u'],
    [59, '3b', 'i32x4.gt_s'],
    [60, '3c', 'i32x4.gt_u'],
    [61, '3d', 'i32x4.le_s'],
    [62, '3e', 'i32x4.le_u'],
    [63, '3f', 'i32x4.ge_s'],
    [64, '40', 'i32x4.ge_u'],
    [65, '41', 'f32x4.eq'],
    [66, '42', 'f32x4.ne'],
    [67, '43', 'f32x4.lt'],
    [68, '44', 'f32x4.gt'],
    [69, '45', 'f32x4.le'],
    [70, '46', 'f32x4.ge'],
    [71, '47', 'f64x2.eq'],
    [72, '48', 'f64x2.ne'],
    [73, '49', 'f64x2.lt'],
    [74, '4a', 'f64x2.gt'],
    [75, '4b', 'f64x2.le'],
    [76, '4c', 'f64x2.ge'],
    [77, '4d', 'v128.not'],
    [78, '4e', ''],
    [79, '4f', ''],
    [80, '50', ''],
    [81, '51', ''],
    [82, '52', ''],
    [83, '53', ''],
    [84, '54', ''],
    [85, '55', ''],
    [86, '56', ''],
    [87, '57', ''],
    [88, '58', ''],
    [89, '59', ''],
    [90, '5a', ''],
    [91, '5b', ''],
    [92, '5c', ''],
    [93, '5d', ''],
    [94, '5e', ''],
    [95, '5f', ''],
    [96, '60', ''],
    [97, '61', ''],
    [98, '62', ''],
    [99, '63', ''],
    [100, '64', ''],
    [101, '65', ''],
    [102, '66', ''],
    [103, '67', ''],
    [104, '68', ''],
    [105, '69', ''],
    [106, '6a', ''],
    [107, '6b', ''],
    [108, '6c', ''],
    [109, '6d', ''],
    [110, '6e', ''],
    [111, '6f', ''],
    [112, '70', ''],
    [113, '71', ''],
    [114, '72', ''],
    [115, '73', ''],
    [116, '74', ''],
    [117, '75', ''],
    [118, '76', ''],
    [119, '77', ''],
    [120, '78', ''],
    [121, '79', ''],
    [122, '7a', ''],
    [123, '7b', ''],
    [124, '7c', ''],
    [125, '7d', ''],
    [126, '7e', ''],
    [127, '7f', ''],
    [128, '80 01', ''],
    [129, '81 01', ''],
    [130, '82 01', ''],
    [131, '83 01', ''],
    [132, '84 01', ''],
    [133, '85 01', ''],
    [134, '86 01', ''],
    [135, '87 01', ''],
    [136, '88 01', ''],
    [137, '89 01', ''],
    [138, '8a 01', ''],
    [139, '8b 01', ''],
    [140, '8c 01', ''],
    [141, '8d 01', ''],
    [142, '8e 01', ''],
    [143, '8f 01', ''],
    [144, '90 01', ''],
    [145, '91 01', ''],
    [146, '92 01', ''],
    [147, '93 01', ''],
    [148, '94 01', ''],
    [149, '95 01', ''],
    [150, '96 01', ''],
    [151, '97 01', ''],
    [152, '98 01', ''],
    [153, '99 01', ''],
    [154, '9a 01', undefined],
    [155, '9b 01', ''],
    [156, '9c 01', ''],
    [157, '9d 01', ''],
    [158, '9e 01', ''],
    [159, '9f 01', ''],
    [160, 'a0 01', ''],
    [161, 'a1 01', ''],
    [162, 'a2 01', undefined],
    [163, 'a3 01', ''],
    [164, 'a4 01', ''],
    [165, 'a5 01', undefined],
    [166, 'a6 01', undefined],
    [167, 'a7 01', ''],
    [168, 'a8 01', ''],
    [169, 'a9 01', ''],
    [170, 'aa 01', ''],
    [171, 'ab 01', ''],
    [172, 'ac 01', ''],
    [173, 'ad 01', ''],
    [174, 'ae 01', ''],
    [175, 'af 01', undefined],
    [176, 'b0 01', undefined],
    [177, 'b1 01', ''],
    [178, 'b2 01', undefined],
    [179, 'b3 01', undefined],
    [180, 'b4 01', undefined],
    [181, 'b5 01', ''],
    [182, 'b6 01', ''],
    [183, 'b7 01', ''],
    [184, 'b8 01', ''],
    [185, 'b9 01', ''],
    [186, 'ba 01', ''],
    [187, 'bb 01', ''],
    [188, 'bc 01', ''],
    [189, 'bd 01', ''],
    [190, 'be 01', ''],
    [191, 'bf 01', ''],
    [192, 'c0 01', ''],
    [193, 'c1 01', ''],
    [194, 'c2 01', undefined],
    [195, 'c3 01', ''],
    [196, 'c4 01', ''],
    [197, 'c5 01', undefined],
    [198, 'c6 01', undefined],
    [199, 'c7 01', ''],
    [200, 'c8 01', ''],
    [201, 'c9 01', ''],
    [202, 'ca 01', ''],
    [203, 'cb 01', ''],
    [204, 'cc 01', ''],
    [205, 'cd 01', ''],
    [206, 'ce 01', ''],
    [207, 'cf 01', undefined],
    [208, 'd0 01', undefined],
    [209, 'd1 01', ''],
    [210, 'd2 01', undefined],
    [211, 'd3 01', undefined],
    [212, 'd4 01', undefined],
    [213, 'd5 01', ''],
    [214, 'd6 01', ''],
    [215, 'd7 01', ''],
    [216, 'd8 01', ''],
    [217, 'd9 01', ''],
    [218, 'da 01', ''],
    [219, 'db 01', ''],
    [220, 'dc 01', ''],
    [221, 'dd 01', ''],
    [222, 'de 01', ''],
    [223, 'df 01', ''],
    [224, 'e0 01', ''],
    [225, 'e1 01', ''],
    [226, 'e2 01', undefined],
    [227, 'e3 01', ''],
    [228, 'e4 01', ''],
    [229, 'e5 01', ''],
    [230, 'e6 01', ''],
    [231, 'e7 01', ''],
    [232, 'e8 01', ''],
    [233, 'e9 01', ''],
    [234, 'ea 01', ''],
    [235, 'eb 01', ''],
    [236, 'ec 01', ''],
    [237, 'ed 01', ''],
    [238, 'ee 01', undefined],
    [239, 'ef 01', ''],
    [240, 'f0 01', ''],
    [241, 'f1 01', ''],
    [242, 'f2 01', ''],
    [243, 'f3 01', ''],
    [244, 'f4 01', ''],
    [245, 'f5 01', ''],
    [246, 'f6 01', ''],
    [247, 'f7 01', ''],
    [248, 'f8 01', ''],
    [249, 'f9 01', ''],
    [250, 'fa 01', ''],
    [251, 'fb 01', ''],
    [252, 'fc 01', ''],
    [253, 'fd 01', ''],
    [254, 'fe 01', ''],
    [255, 'ff 01', ''],
    [256, '80 02', ''],
    [257, '81 02', ''],
    [258, '82 02', ''],
    [259, '83 02', ''],
    [260, '84 02', ''],
    [261, '85 02', ''],
    [262, '86 02', ''],
    [263, '87 02', ''],
    [264, '88 02', ''],
    [265, '89 02', ''],
    [266, '8a 02', ''],
    [267, '8b 02', ''],
    [268, '8c 02', ''],
    [269, '8d 02', ''],
    [270, '8e 02', ''],
    [271, '8f 02', ''],
    [272, '90 02', ''],
    [273, '91 02', ''],
    [274, '92 02', ''],
    [275, '93 02', ''],
]

/*

5.4.8 Vector Instructions       p.194
6.5.9 Vector Instructions       p.227


v128.const i8x16
v128.const i16x8
v128.const i32x4
v128.const i64x2
v128.const f32x4
v128.const f64x2


i8x16.xxx           i16x8.xxx           i32x4.xxx       i64x2.xxx       f32x4.xxx       f64x2.xxx

i8x16.shl           i16x8.shl           i32x4.shl       i64x2.shl       --              --
i8x16.shr_s         i16x8.shr_s         i32x4.shr_s     i64x2.shr_s     --              --
i8x16.shr_u         i16x8.shr_u         i32x4.shr_u     i64x2.shr_u     --              --
i8x16.add           i16x8.add           i32x4.add       i64x2.add       f32x4.add       f64x2.add
i8x16.add_sat_s     i16x8.add_sat_s     --              --              --              --
i8x16.add_sat_u     i16x8.add_sat_u     --              --              --              --
i8x16.sub           i16x8.sub           i32x4.sub       i64x2.sub       f32x4.sub       --
i8x16.sub_sat_s     i16x8.sub_sat_s     --              --              --              --
i8x16.sub_sat_u     i16x8.sub_sat_u     --              --              --              --

i8x16.eq            i16x8.eq            i32x4.eq        i64x2.eq        f32x4.eq        f64x2.eq
i8x16.ne            i16x8.ne            i32x4.ne        i64x2.ne        f32x4.ne        f64x2.ne
i8x16.lt_s          i16x8.lt_s          i32x4.lt_s      i64x2.lt_s      f32x4.lt        f64x2.lt
i8x16.lt_u          i16x8.lt_u          i32x4.lt_u      --              --              --
i8x16.gt_s          i16x8.gt_s          i32x4.gt_s      i64x2.gt_s      f32x4.gt        f64x2.gt
i8x16.gt_u          i16x8.gt_u          i32x4.gt_u      --              --              --
i8x16.le_s          i16x8.le_s          i32x4.le_s      i64x2.le_s      f32x4.le        f64x2.le
i8x16.le_u          i16x8.le_u          i32x4.le_u      --              --              --
i8x16.ge_s          i16x8.ge_s          i32x4.ge_s      i64x2.ge_s      f32x4.ge        f64x2.ge
i8x16.ge_u          i16x8.ge_u          i32x4.ge_u      --              --              --

--                  i16x8.mul           i32x4.mul       i64x2.mul       f32x4.mul       f64x2.mul
--                  --                  --              --              f32x4.div       f64x2.div

i8x16.min_s         i16x8.min_s         --              --              f32x4.min       f64x2.min
i8x16.min_u         i16x8.min_u         --              --              --              --
i8x16.max_s         i16x8.max_s         --              --              f32x4.max       f64x2.max
i8x16.max_u         i16x8.max_u         --              --              --              --
--                  --                  --              --              f32x4.pmin      f64x2.pmin
--                  --                  --              --              f32x4.pmax      f64x2.pmax
i8x16.avgr_u        i16x8.avgr_u        --              --              --              --

--                  i16x8.abs           i32x4.abs       i64x2.abs       f32x4.abs       f64x2.abs
--                  i16x8.neg           i32x4.neg       i64x2.neg       f32x4.neg       f64x2.neg
--                  i16x8.q15mulr_sat_s --

i8x16.popcnt
i8x16.all_true      i16x8.all_true              --      --              --              --
i8x16.bitmask       i16x8.bitmask               --      --              --              --
i8x16.narrow_i16x8_s
i8x16.narrow_i16x8_u
--                  i16x8.narrow_i32x4_s        --      --              --              --
--                  i16x8.narrow_i32x4_u        --      --              --              --
--                  i16x8.extend_low_i8x16_s    --      --              --              --
--                  i16x8.extend_high_i8x16_s   --      --              --              --
--                  i16x8.extend_low_i8x16_u    --      --              --              --
--                  i16x8.extend_high_i8x16_u   --      --              --              --

i8x16.xxx           i16x8.xxx           i32x4.xxx       i64x2.xxx       f32x4.xxx       f64x2.xxx

************************* extend *************************

--                  i16x8.extadd_pairwise_i8x16_s
--                  i16x8.extadd_pairwise_i8x16_u
--                  --                              i32x4.extadd_pairwise_i16x8_s
--                  --                              i32x4.extadd_pairwise_i16x8_u

i16x8.extmul_low_i8x16_s
i16x8.extmul_high_i8x16_s
i16x8.extmul_low_i8x16_u
i16x8.extmul_high_i8x16_u

i32x4.extmul_low_i16x8_s
i32x4.extmul_high_i16x8_s
i32x4.extmul_low_i16x8_u
i32x4.extmul_high_i16x8_u

i64x2.extmul_low_i32x4_s
i64x2.extmul_high_i32x4_s
i64x2.extmul_low_i32x4_u
i64x2.extmul_high_i32x4_u


************************* floating point only *************************

--                  --                  --              --              f32x4.sqrt      f64x2.sqrt
--                  --                  --              --              f32x4.ceil      f64x2.ceil
--                  --                  --              --              f32x4.floor     f64x2.floor
--                  --                  --              --              f32x4.trunc     f64x2.trunc
--                  --                  --              --              f32x4.nearest   f64x2.nearest
f32x4.demote_f64x2_zero
f64x2.promote_low_f32x4


*/




/*
    5.5.17 Modules          p.206
*/
const moduleInfo = [
    {order: 1, id: 1, name: 'type', category: 'definition'},
    {order: 2, id: 2, name: 'import', category: 'declaration'},
    {order: 3, id: 3, name: 'function', category: 'definition'},
    {order: 4, id: 4, name: 'table', category: 'definition'},
    {order: 5, id: 5, name: 'memory', category: 'definition'},
    {order: 6, id: 13, name: 'tag', category: 'definition'},
    {order: 7, id: 6, name: 'global', category: 'definition'},
    {order: 8, id: 7, name: 'export', category: 'declaration'},
    {order: 9, id: 8, name: 'start', category: 'initialization'},
    {order: 10, id: 9, name: 'element', category: 'initialization'},
    {order: 11, id: 12, name: 'data count', category: 'initialization'},
    {order: 12, id: 10, name: 'code', category: 'definition'},
    {order: 13, id: 11, name: 'data', category: 'initialization'},
]


