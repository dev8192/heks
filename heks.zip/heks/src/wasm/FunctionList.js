
class FunctionList extends Widget {
    constructor(opts) {
        super(opts)
        this.elemToFuncNameMap = new Map()
        this.funcSec = this.app.wasmProgram.functions
        this.onClick = this.onClick.bind(this)
        this.container.addEventListener('click', this.onClick)
        this.app.wasmProgram.functions.addListener('selectionAdded', this.addSelection.bind(this))
        this.app.wasmProgram.functions.addListener('selectionRemoved', this.removeSelection.bind(this))
    }
    show() {
        super.show()
        this.emit('show')
    }
    hide() {
        super.hide()
        this.emit('hide')
    }
    onClick(event) {
        if (event.target === this.container) {
            return
        }
        const funcName = this.elemToFuncNameMap.get(event.target)
        if (funcName) {
            this.app.wasmProgram.functions.select(funcName)
        }
    }
    dispose() {
        this.container.removeEventListener('click', this.onClick)
    }
}

class CompactFunctionList extends FunctionList {
    constructor(opts) {
        super(opts)

        this.funcNameToByteElemMap = new Map()
    }
    show() {
        this.container.innerHTML = ''
        this.elemToFuncNameMap.clear()

        this.container.classList.add('compact_wasm')
        for (let i = 0; i < this.funcSec.code.length; i++) {
            const elem = document.createElement('div')
            elem.classList.add('cell')
            elem.textContent = this.funcSec.code[i].toString(16).padStart(2, '0')
            this.container.append(elem)
        }
        for (let i = 3; i < this.container.childElementCount; i++) {
            const elem = this.container.children[i]
            const funcName = this.funcSec.data[i - 3].name
            this.elemToFuncNameMap.set(elem, funcName)
            this.funcNameToByteElemMap.set(funcName, elem)
        }
        if (this.funcSec.currentFunction) {
            this.addSelection(this.funcSec.currentFunction.name)
        }
        super.show()
    }
    addSelection(funcName) {
        const byteElem = this.funcNameToByteElemMap.get(funcName)
        byteElem.classList.add('selected')
    }
    removeSelection(funcName) {
        const byteElem = this.funcNameToByteElemMap.get(funcName)
        byteElem.classList.remove('selected')
    }
    dispose() {
        this.container.classList.remove('compact_wasm')
        super.dispose()
    }
}

class VerboseFunctionList extends FunctionList {
    constructor(opts) {
        super(opts)

        this.funcNameToRowIdxMap = new Map()
        this.rows = []
        this.selectedRowIdx = -1
    }
    show() {
        this.container.innerHTML = ''
        this.elemToFuncNameMap.clear()
        this.funcNameToRowIdxMap.clear()
        this.rows.length = 0
        
        this.container.classList.remove('compact_wasm')
        this.container.classList.add('verbose_wasm')
        for (let i = 0; i < this.funcSec.code.length; i++) {            
            const byteElem = document.createElement('div')
            byteElem.classList.add('byte')
            byteElem.textContent = this.funcSec.code[i].toString(16).padStart(2, '0')
            this.container.append(byteElem)
            
            const decElem = document.createElement('div')
            decElem.classList.add('dec')
            decElem.textContent = this.funcSec.code[i]
            this.container.append(decElem)
            
            const descElem = document.createElement('div')
            descElem.classList.add('desc')
            this.container.append(descElem)

            this.rows.push([
                byteElem,
                decElem,
                descElem,
            ])
        }
        for (const elem of this.container.children) {
            elem.classList.add('cell')
        }
        this.rows[0][this.rows[0].length - 1].textContent = 'Section ID'
        this.rows[1][this.rows[1].length - 1].textContent = 'Section size'
        this.rows[2][this.rows[2].length - 1].textContent = 'Section count'
        for (let i = 3; i < this.rows.length; i++) {
            const funcName = this.funcSec.data[i - 3].name
            this.rows[i][this.rows[i].length - 1].textContent = funcName
            this.funcNameToRowIdxMap.set(funcName, i)
            for (const elem of this.rows[i]) {
                this.elemToFuncNameMap.set(elem, funcName)
            }
        }
        if (this.funcSec.currentFunction) {
            this.addSelection(this.funcSec.currentFunction.name)
        }
        super.show()
    }
    addSelection(funcName) {
        const rowIdx = this.funcNameToRowIdxMap.get(funcName)
        for (const item of this.rows[rowIdx]) {
            item.classList.add('selected')
        }
    }
    removeSelection(funcName) {
        const rowIdx = this.funcNameToRowIdxMap.get(funcName)
        for (const item of this.rows[rowIdx]) {
            item.classList.remove('selected')
        }
    }
    dispose() {
        this.container.classList.remove('verbose_wasm')
        super.dispose()
    }
}
