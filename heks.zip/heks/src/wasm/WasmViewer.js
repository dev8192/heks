/*
0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 
0x01, 0x07, 0x01, 
    0x60, 0x02, 0x7f, 0x7f, 0x01, 0x7f, 
0x03, 0x02, 0x01, 0x00, 
0x07, 0x09, 0x01, 
    0x05, 0x66, 0x75, 0x6e, 0x63, 0x31, 0x00, 0x00, 
0x0a, 0x09, 0x01, 
    0x06, 0x00, 
        0x20, 0x00, 
        0x20, 0x01, 
        0x6a, 
    0x0b
*/

class WasmViewer extends Widget {
    constructor(opts) {
        super(opts)
        this.decMode = false
        this.drawMagic = true
        this.drawComments = true
        this.container.addEventListener('click', this.onClick.bind(this))
        this.funcElemToTypeIdxMap = new Map()
        this.typeIdxToRowElemMap = new Map()
    }
    addSelection(arr) {
        for (const item of arr) {
            item.classList.add('selected')
        }
        setTimeout(() => {
            this.removeSelection(arr)
        }, 1000)
    }
    removeSelection(arr) {
        for (const item of arr) {
            item.classList.remove('selected')
        }
    }
    onClick(event) {
        if (event.target.classList.contains('type_idx')) {
            console.log(event.target.textContent)
            const typeIdx = this.funcElemToTypeIdxMap.get(event.target)
            const rowElem = this.typeIdxToRowElemMap.get(typeIdx)
            this.addSelection(rowElem.children)
        }
    }
    formatNumber(number) {
        if (this.decMode) {
            return number.toString(10)
        } else {
            return number.toString(16).padStart(2, '0')
        }
    }
    drawRow(arr) {
        const rowElem = document.createElement('div')
        rowElem.classList.add('row')
        this.container.append(rowElem)

        for (const item of arr) {
            const typeElem = document.createElement('div')
            typeElem.classList.add('magic')
            typeElem.classList.add('cell')
            typeElem.textContent = this.formatNumber(item)
            rowElem.append(typeElem)
        }
    }
    createSectionHeader(sectionObj) {
        const rowElem = document.createElement('div')
        rowElem.classList.add('row')
        this.container.append(rowElem)

        const secIdElem = document.createElement('div')
        secIdElem.classList.add('section_id')
        secIdElem.classList.add('cell')
        secIdElem.textContent = this.formatNumber(sectionObj.getSectionId())
        rowElem.append(secIdElem)

        const secLenElem = document.createElement('div')
        secLenElem.classList.add('section_len')
        secLenElem.classList.add('cell')
        secLenElem.textContent = this.formatNumber(sectionObj.byteLength())
        rowElem.append(secLenElem)

        const itemCountElem = document.createElement('div')
        itemCountElem.classList.add('item_count')
        itemCountElem.classList.add('cell')
        itemCountElem.textContent = this.formatNumber(sectionObj.len())
        rowElem.append(itemCountElem)

        return rowElem
    }
    addComment(rowElem, text) {
        if (!this.drawComments) {
            return
        }
        const commentElem = document.createElement('div')
        commentElem.classList.add('comment')
        commentElem.textContent = text
        rowElem.append(commentElem)
    }
    addPlaceholders(rowElem, count) {
        for (let i = 0; i < count; i++) {
            const placeholderElem = document.createElement('div')
            placeholderElem.classList.add('placeholder')
            rowElem.append(placeholderElem)
        }
    }
    drawTypeItems(rowElem, arr) {
        const typeElem = document.createElement('div')
        typeElem.classList.add('type')
        typeElem.classList.add('cell')
        typeElem.textContent = this.formatNumber(arr.length)
        rowElem.append(typeElem)
        for (const item of arr) {
            const typeElem = document.createElement('div')
            typeElem.classList.add('type')
            typeElem.classList.add('cell')
            typeElem.textContent = this.formatNumber(typeToByte[item])
            rowElem.append(typeElem)
        }
    }
    drawTypes(program) {
        const rowElem = this.createSectionHeader(program.types)
        this.addComment(rowElem, 'types')

        for (let i = 0; i < program.types.data.length; i++) {
            const rowElem = document.createElement('div')
            rowElem.classList.add('row')
            this.container.append(rowElem)
            this.typeIdxToRowElemMap.set(i, rowElem)

            this.addPlaceholders(rowElem, 1)

            const typeElem = document.createElement('div')
            typeElem.classList.add('type')
            typeElem.classList.add('cell')
            typeElem.textContent = this.formatNumber(0x60)
            rowElem.append(typeElem)

            this.drawTypeItems(rowElem, program.types.data[i].param)
            this.drawTypeItems(rowElem, program.types.data[i].result)
        }
    }
    drawFunctions(program) {
        const rowElem = this.createSectionHeader(program.functions)
        for (const item of program.functions.data) {
            const elem = document.createElement('div')
            elem.classList.add('cell')
            elem.classList.add('type_idx')
            const typeIdx = program.types.getTypeIdx(item.type)
            elem.textContent = this.formatNumber(typeIdx)
            this.funcElemToTypeIdxMap.set(elem, typeIdx)
            rowElem.append(elem)
        }
        this.addComment(rowElem, 'functions')
    }
    drawExportName(rowElem, str) {
        for (let i = 0; i < str.length; i++) {
            const charElem = document.createElement('div')
            charElem.classList.add('cell')
            charElem.classList.add('char')
            const byte = str.charCodeAt(i)
            charElem.textContent = this.formatNumber(byte)
            rowElem.append(charElem)
        }
    }
    drawExports(program) {
        const rowElem = this.createSectionHeader(program.exports)
        this.addComment(rowElem, 'exports')

        for (let i = 0; i < program.exports.data.length; i++) {
            const item = program.exports.data[i]
            const rowElem = document.createElement('div')
            rowElem.classList.add('row')
            this.container.append(rowElem)

            this.addPlaceholders(rowElem, 1)

            const lenElem = document.createElement('div')
            lenElem.classList.add('len')
            lenElem.classList.add('cell')
            lenElem.textContent = this.formatNumber(item.name.length)
            rowElem.append(lenElem)

            this.drawExportName(rowElem, item.name)

            const typeElem = document.createElement('div')
            typeElem.classList.add('type')
            typeElem.classList.add('cell')
            typeElem.textContent = this.formatNumber(item.type)
            rowElem.append(typeElem)

            const indexElem = document.createElement('div')
            indexElem.classList.add('index')
            indexElem.classList.add('cell')
            indexElem.textContent = this.formatNumber(i)
            rowElem.append(indexElem)
        }
    }
    drawFunctionStart(program, item) {
        const rowElem = document.createElement('div')
        rowElem.classList.add('row')
        this.container.append(rowElem)

        this.addPlaceholders(rowElem, 1)

        const lenElem = document.createElement('div')
        lenElem.classList.add('len')
        lenElem.classList.add('cell')
        const len = program.code.computeLength(item.body)
        lenElem.textContent = this.formatNumber(len)
        rowElem.append(lenElem)

        const localsElem = document.createElement('div')
        localsElem.classList.add('len')
        localsElem.classList.add('cell')
        localsElem.textContent = this.formatNumber(item.locals)
        rowElem.append(localsElem)
    }
    drawImmediates(rowElem, arr) {
        for (const item of arr) {
            const immElem = document.createElement('div')
            immElem.classList.add('cell')
            immElem.classList.add('imm')
            immElem.textContent = this.formatNumber(item)
            rowElem.append(immElem)
        }
    }
    drawFunctionMiddle(instrObj, level) {
        for (const item of instrObj.children) {
            const rowElem = document.createElement('div')
            rowElem.classList.add('row')
            this.container.append(rowElem)
            
            this.addPlaceholders(rowElem, level)

            const opcodeElem = document.createElement('div')
            opcodeElem.classList.add('cell')
            opcodeElem.textContent = this.formatNumber(item.opcode)
            rowElem.append(opcodeElem)

            if (item.imm) {
                this.drawImmediates(rowElem, item.imm)
            }

            const comment = this.formatNumber(item.name)
            this.addComment(rowElem, comment)
        }
    }
    drawFunctionEnd() {
        const rowElem = document.createElement('div')
        rowElem.classList.add('row')
        this.container.append(rowElem)

        this.addPlaceholders(rowElem, 1)

        const endElem = document.createElement('div')
        endElem.classList.add('cell')
        endElem.textContent = this.formatNumber(11)
        rowElem.append(endElem)
    }
    drawCode(program) {
        const rowElem = this.createSectionHeader(program.code)
        this.addComment(rowElem, 'code')

        for (const item of program.functions.data) {
            this.drawFunctionStart(program, item)
            this.drawFunctionMiddle(item.body, 2)
            this.drawFunctionEnd()
        }
    }
    show() {
        console.log('WasmViewer.show')
        const program = this.app.wasmProgram
        this.container.innerHTML = ''
        if (this.drawMagic) {
            this.drawRow(program.constructor.magic)
        }
        if (program.types) {
            this.drawTypes(program)
        }
        if (program.functions) {
            this.drawFunctions(program)
        }
        if (program.exports) {
            this.drawExports(program)
        }
        if (program.functions) {
            this.drawCode(program)
        }
        super.show()
    }
}
