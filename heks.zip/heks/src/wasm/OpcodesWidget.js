class OpcodeCategories extends Widget {
    constructor(opts) {
        super(opts)
        this.rowToColorMap = new Map()
        this.onMouseEnter = this.onMouseEnter.bind(this)
        this.onMouseLeave = this.onMouseLeave.bind(this)
        this.buildInternal()
    }
    buildInternal() {
        for (const [catName, catObj] of Object.entries(instrCategories)) {
            const rowElem = document.createElement('div')
            rowElem.classList.add('row')
            rowElem.addEventListener('mouseenter', this.onMouseEnter)
            rowElem.addEventListener('mouseleave', this.onMouseLeave)
            this.container.append(rowElem)
            this.rowToColorMap.set(rowElem, catObj.color)
            
            const colorElem = document.createElement('div')
            colorElem.style.backgroundColor = catObj.color
            colorElem.classList.add('color')
            rowElem.append(colorElem)

            const nameElem = document.createElement('div')
            nameElem.textContent = catName
            rowElem.append(nameElem)

            const secElem = document.createElement('div')
            if (catObj.sec) {
                secElem.textContent = `(${catObj.sec})`
            }
            rowElem.append(secElem)
        }
    }
    onMouseEnter(event) {
        const color = this.rowToColorMap.get(event.target)
        this.emit('update_highlight', color)
    }
    onMouseLeave() {
        this.emit('update_highlight')
    }
}

class OpcodesWidget extends Widget {
    constructor(opts) {
        super(opts)
        this.cellToColorMap = new Map()
        this.cellToIndexMap = new Map()
        this.onMouseEnter = this.onMouseEnter.bind(this)
        this.onMouseLeave = this.onMouseLeave.bind(this)
        this.buildInternal()
    }
    buildInternal() {
        this.gridElem = document.createElement('div')
        this.gridElem.classList.add('grid')
        this.container.append(this.gridElem)
        for (let i = 0; i < 256; i++) {
            const cellElem = document.createElement('div')
            cellElem.addEventListener('mouseenter', this.onMouseEnter)
            cellElem.addEventListener('mouseleave', this.onMouseLeave)
            const category = wasmOpcodes[i][2]
            let color
            if (category) {
                color = instrCategories[category].color
            } else {
                color = '#a5a5a5'
            }
            cellElem.style.backgroundColor = color
            cellElem.textContent = i.toString(16).padStart(2, '0')
            cellElem.classList.add('cell')
            this.gridElem.append(cellElem)
            this.cellToColorMap.set(cellElem, color)
            this.cellToIndexMap.set(cellElem, i)
        }
    }
    show() {
        // for (let i = 0; i < 16; i++) {
        //     for (let j = 0; j < 16; j++) {
                
        //     }            
        // }
        super.show()
    }
    updateHighlight(catColor) {
        for (let i = 0; i < this.gridElem.childElementCount; i++) {
            const cellElem = this.gridElem.children[i]
            const cellColor = this.cellToColorMap.get(cellElem)
            if (cellColor === catColor) {
                cellElem.classList.add('selected')
            } else {
                cellElem.classList.remove('selected')
            }
        }
    }
    onMouseEnter(event) {
        event.target.classList.add('selected')
        const index = this.cellToIndexMap.get(event.target)
        this.emit('cellSelected', index)
    }
    onMouseLeave(event) {
        event.target.classList.remove('selected')
        this.emit('cellSelected')
    }
}

class OpcodeInfo extends Widget {
    constructor(opts) {
        super(opts)
        this.hexValueElem = this.container.querySelector('.hex_value')
        this.decValueElem = this.container.querySelector('.dec_value')
        this.nameElem = this.container.querySelector('.name')
        this.descElem = this.container.querySelector('.description')
    }
    show(index) {
        super.show()
        const opcodeObj = wasmOpcodes[index]
        this.hexValueElem.textContent = index.toString(16)
        this.decValueElem.textContent = index.toString(10)
        if (opcodeObj[1]) {
            this.nameElem.textContent = opcodeObj[1]
        } else {
            this.nameElem.textContent = 'reserved'
        }
        this.descElem.textContent = 'none'
    }
}
