class TypeEditor extends Dialog {
    constructor(opts) {
        super(opts)

        this.identifierInput = this.container.querySelector('.identifier')

        this.params = []
        this.results = []

        this.printMessage = this.app.printMessage

        this.paramContainer = this.container.querySelector('.param_types')
        this.addParamButton = this.paramContainer.querySelector('.add')
        this.addParamButton.addEventListener('click', this.onAddParamClick.bind(this))
        this.parameterContentElem = this.paramContainer.querySelector('.content')

        this.resultContainer = this.container.querySelector('.result_types')
        this.addResultButton = this.resultContainer.querySelector('.add')
        this.addResultButton.addEventListener('click', this.onAddResultClick.bind(this))
        this.resultContentElem = this.resultContainer.querySelector('.content')
        
        this.selectType = new ButtonGroup({
            parentElem: this.container,
            selector: '.select_type',
            onClick: this.onTypeSelected.bind(this),
        })
        this.selectType.container.remove()

        this.editingMode = null
    }
    show() {
        this.identifierInput.value = ''
        this.parameterContentElem.textContent = ''
        this.resultContentElem.textContent = ''
        this.params = []
        this.results = []
        super.show()
    }
    onAddParamClick() {
        this.editingMode = 'add_parameter'
        this.addParamButton.replaceWith(this.selectType.container)
    }
    onAddResultClick() {
        this.editingMode = 'add_return_value'
        this.addResultButton.replaceWith(this.selectType.container)
    }
    setName(name) {
        this.identifierInput.value = name
    }
    addParamType(type) {
        const typeElem = document.createElement('div')
        typeElem.classList.add('type_elem')
        typeElem.textContent = type
        this.params.push(type)
        this.parameterContentElem.append(typeElem)
    }
    addResultType(type) {
        const typeElem = document.createElement('div')
        typeElem.classList.add('type_elem')
        typeElem.textContent = type
        this.results.push(type)
        this.resultContentElem.append(typeElem)
    }
    onTypeSelected(type) {
        if (this.editingMode === 'add_parameter') {
            this.addParamType(type)
            this.selectType.container.replaceWith(this.addParamButton)
        } else if (this.editingMode === 'add_return_value') {
            this.addResultType(type)
            this.selectType.container.replaceWith(this.addResultButton)
        } else {
            throw new Error('Invalid editing mode')
        }
        this.editingMode = null
        this.selectType.setValue(null)
    }
    onOkClick() {
        this.hide()
        this.emit('ok', { 
            name: this.identifierInput.value, 
            param: this.params, 
            result: this.results,
        })
    }
}
