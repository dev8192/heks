class WasmRunner extends View {
    constructor(opts) {
        opts.viewId = 'wasm_runner'
        super(opts)

        this.wasmProgram = opts.wasmProgram

        this.inputMode = new ButtonGroup({
            parentElem: this.container,
            selector: '.input_mode',
            onClick: this.onChangeInputMode.bind(this),
        })

        this.parserInputElem = this.container.querySelector('.parser_input')
        this.inputElem = this.parserInputElem.querySelector('input')
        this.parseButton = this.parserInputElem.querySelector('.parse')
        this.parseButton.addEventListener('click', this.onParseButtonClick.bind(this))

        this.wasmViewer = new WasmViewer({
            app: this.app,
            parentElem: this.container,
            selector: '.wasm_viewer',
        })

        this.contentElem = this.container.querySelector('.content')
        this.templateElem = this.container.querySelector('template')
        this.closeButton = this.container.querySelector('.close')
        this.closeButton.addEventListener('click', this.onCloseButtonClick.bind(this))

        this.onFunctionButtonClick = this.onFunctionButtonClick.bind(this)
    }
    show() {
        const program = this.app.wasmProgram
        this.wasmViewer.show()
        super.show()
        const items = []
        if (program.exports.data.length === 0) {
            return
        }
        for (let i = 0; i < program.exports.data.length; i++) {
            const item = program.exports.data[i]
            if (item instanceof WasmFunction) {
                items.push({
                    title: item.name,
                    id: item,
                })
            }
        }
        items[0].selected = true
        this.prepareFunction(program.exports.data[0])
        this.functions = new ButtonGroup({
            parentElem: this.container,
            selector: '.function_selector',
            items,
            onClick: this.onFunctionButtonClick,
        })
    }
    onFunctionButtonClick(item) {
        this.contentElem.innerHTML = ''
        this.prepareFunction(item)
    }
    onParseButtonClick() {
        const str = this.inputElem.value
        this.inputElem.value = ''
        const arr = str.split(',')
        this.app.wasmProgram = WasmProgram.fromArray(arr)
        this.show()
    }
    onChangeInputMode(mode) {
        if (mode === 'internal') {
            this.parserInputElem.classList.add('hidden')
        } else {
            this.parserInputElem.classList.remove('hidden')
        }
    }
    handleParts(container, parts) {
        const arr = []
        for (let i = 0; i < parts.length; i++) {
            const rowElem = document.createElement('div')
            container.append(rowElem)

            const labelElem = document.createElement('label')
            rowElem.append(labelElem)
            labelElem.textContent = parts[i]
            
            const inputElem = document.createElement('input')
            rowElem.append(inputElem)
            arr.push(inputElem)
        }
        return arr
    }
    prepareFunction(item) {
        const funcElem = this.templateElem.content.cloneNode(true)
        
        const inputContainer = funcElem.querySelector('.input')
        const inputs = this.handleParts(inputContainer, item.ref.type.param)

        const outputContainer = funcElem.querySelector('.output')
        const outputs = this.handleParts(outputContainer, item.ref.type.result)

        const runButton = funcElem.querySelector('.run')
        runButton.addEventListener('click', () => {
            this.run({
                name: item.name,
                inputs,
                outputs,
            })
        })

        inputs[0].value = item.ref.getDefaultParam({offset: 0})
        inputs[1].value = item.ref.getDefaultParam({offset: 1})

        this.contentElem.append(funcElem)
    }
    run(spec) {
        console.log(spec)
        try {
            const program = this.app.wasmProgram.program
            WebAssembly.instantiate(program).then((wasm) => {
                const args = []
                for (const input of spec.inputs) {
                    args.push(Number(input.value))
                }
                const result = wasm.instance.exports[spec.name](...args)
                if (spec.outputs.length === 1) {
                    spec.outputs[0].value = result
                } else if (spec.outputs.length > 1) {
                    for (let i = 0; i < result.length; i++) {
                        spec.outputs[i].value = result[i]
                    }
                }
            })
        } catch (err) {
            this.outputElem.textContent = err
        }
    }
    onCloseButtonClick() {
        this.hide()
    }
}
