class WasmView extends View {
    constructor(opts) {
        opts.viewId = 'wasm_view'
        super(opts)

        this.opcodesWidget = new OpcodesWidget({
            app: this.app,
            parentElem: this.container,
            selector: '.opcodes_widget',
        })
        this.onCellSelected = this.onCellSelected.bind(this)
        this.opcodesWidget.addListener('cellSelected', this.onCellSelected)

        this.opcodeCategories = new OpcodeCategories({
            app: this.app,
            parentElem: this.container,
            selector: '.opcode_categories',
        })
        this.updateHighlight = this.updateHighlight.bind(this)
        this.opcodeCategories.addListener('update_highlight', this.updateHighlight)

        this.opcodeInfo = new OpcodeInfo({
            app: this.app,
            parentElem: this.container,
            selector: '.opcode_info',
        })
    }
    updateHighlight(color) {
        this.opcodesWidget.updateHighlight(color)
    }
    onCellSelected(index) {
        if (index === undefined) {
            this.opcodeInfo.hide()
        } else {
            this.opcodeInfo.show(index)
        }
    }
}
