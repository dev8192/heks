const opcodePresets = [
    {
        name: 'Simple',
        data: [
            [0x20, 'local.get', 'Variable'],
            [0x21, 'local.set', 'Variable'],
            [0x41, 'i32.const', 'Numeric.Constant'],
            [0x42, 'i64.const', 'Numeric.Constant'],
            [0x43, 'f32.const', 'Numeric.Constant'],
            [0x44, 'f64.const', 'Numeric.Constant'],
            [0x6a, 'i32.add', 'Numeric.Binary'],
            [0x6b, 'i32.sub', 'Numeric.Binary'],
        ]
    },
    {
        name: 'Control flow',
        data: [
            [0x02, 'block', 'Control'],
            [0x03, 'loop', 'Control'],
            [0x04, 'if', 'Control'],
            [0x05, 'else', 'Control'],
            [0x0b, 'end', 'Control'],
            [0x0c, 'br', 'Control'],
            [0x0d, 'br_if', 'Control'],
        ]
    },
    {
        name: 'Error handling',
        data: [],
    },
    {
        name: 'IEEE 754',
        data: [],
    },
    {
        name: 'Simple SIMD',
        data: [],
    },
    {
        name: 'Conditionals',
        data: [],
    }
]

class OpcodePresetManager {
    constructor() {

    }
    get(name) {
        for (const item of opcodePresets) {
            if (item.name === name) {
                return item
            }
        }
    }
}

class OpcodeSelector extends Widget {
    constructor(opts) {
        super(opts)
        
        this.opcodePresetMgr = new OpcodePresetManager()
        this.currentPreset = this.opcodePresetMgr.get('Simple')

        this.elemToOpcodeObjMap = new Map()

        this.container.addEventListener('click', this.onClick.bind(this))
    }
    onClick(event) {
        if (!event.target.classList.contains('opcode')) {
            return
        }
        const opcode = this.elemToOpcodeObjMap.get(event.target)
        this.emit('opcodeAdded', opcode)
    }
    show() {
        this.elemToOpcodeObjMap.clear()
        this.container.innerHTML = ''
        const groups = {}
        for (const item of this.currentPreset.data) {
            const group = item[2]
            const obj = {
                opcode: item[0],
                name: item[1],
            }
            if (groups[group]) {
                groups[group].push(obj)
            } else {
                groups[group] = [obj]
            }
        }
        for (const [group, items] of Object.entries(groups)) {
            const groupHeaderElem = document.createElement('div')
            groupHeaderElem.classList.add('group_header')
            groupHeaderElem.textContent = group
            this.container.append(groupHeaderElem)
            const groupBodyElem = document.createElement('div')
            groupBodyElem.classList.add('group_body')
            this.container.append(groupBodyElem)
            for (const item of items) {
                const opcodeElem = document.createElement('div')
                opcodeElem.classList.add('opcode')
                opcodeElem.textContent = item.name
                groupBodyElem.append(opcodeElem)
                this.elemToOpcodeObjMap.set(opcodeElem, item)
            }
        }
        super.show()
    }
}

class FunctionBody extends Widget {
    constructor(opts) {
        super(opts)
        this.onRowClick = this.onRowClick.bind(this)
        this.selectedOpcode = null
        this.rowToOpcodeMap = new Map()
        this.opcodeToRowMap = new Map()
    }
    onRowClick(event) {
        const instrObj = this.rowToOpcodeMap.get(event.currentTarget)
        if (this.selectedOpcode) {
            const rowElem = this.opcodeToRowMap.get(this.selectedOpcode)
            rowElem.classList.remove('selected')
            if (this.selectedOpcode === instrObj) {
                this.selectedOpcode = null
            } else {
                this.selectedOpcode = instrObj
                event.currentTarget.classList.add('selected')
            }
        } else {
            this.selectedOpcode = instrObj
            event.currentTarget.classList.add('selected')
        }
        this.emit('selectionChanged', this.selectedOpcode)
    }
    createRow(instrObj) {
        const rowElem = document.createElement('div')
        rowElem.classList.add('row')
        rowElem.addEventListener('click', this.onRowClick)
        this.rowToOpcodeMap.set(rowElem, instrObj)
        this.opcodeToRowMap.set(instrObj, rowElem)

        const opcodeElem = document.createElement('div')
        opcodeElem.classList.add('byte')
        opcodeElem.textContent = instrObj.opcode.toString(16).padStart(2, '0')
        rowElem.append(opcodeElem)

        const instrElem = document.createElement('div')
        instrElem.classList.add('comment')
        instrElem.textContent = instrObj.name
        rowElem.append(instrElem)

        return rowElem
    }
    show() {
        this.container.innerHTML = ''
        this.selectedOpcode = null
        this.rowToOpcodeMap.clear()

        for (const instrObj of this.body) {
            const rowElem = this.createRow(instrObj)
            this.container.append(rowElem)
        }
    }
    getData() {
        return this.body
    }
    setData(arr) {
        this.body = arr
    }
    insertBefore(opcode, anchor) {
        const rowElem = this.createRow(opcode)
        const anchorElem = this.opcodeToRowMap.get(anchor)
        if (this.body.length === 0) {
            this.body.unshift(opcode)
            this.container.insertBefore(rowElem, anchorElem)
        } else {
            const arr = []
            for (const item of this.body) {
                if (item === anchor) {
                    arr.push(opcode)
                }
                arr.push(item)
            }
            this.body = arr
            this.container.insertBefore(rowElem, anchorElem)
        }
    }
    insertAfter(opcode, anchor) {
        const rowElem = this.createRow(opcode)
        if (this.body.length === 0) {
            this.body.push(opcode)
            this.container.append(rowElem)
        } else {
            const arr = []
            for (const item of this.body) {
                arr.push(item)
                if (item === anchor) {
                    arr.push(opcode)
                }
            }
            this.body = arr
            const anchorElem = this.opcodeToRowMap.get(anchor)
            this.container.insertBefore(rowElem, anchorElem.nextElementSibling)
        }
    }
    prepend(opcode) {
        this.body.unshift(opcode)
        const rowElem = this.createRow(opcode)
        this.container.insertBefore(rowElem, this.container.firstElementChild)
    }
    append(opcode) {
        this.body.push(opcode)
        const rowElem = this.createRow(opcode)
        this.container.append(rowElem)
    }
}

class CodeEditor extends Dialog {
    constructor(opts) {
        super(opts)
        this.funcBody = []
        this.printMessage = this.app.printMessage

        this.insertMode = new ButtonGroup({
            parentElem: this.container,
            selector: '.insert_mode',
            onClick: this.onInsertModeSelected.bind(this),
        })
        this.insertBeforeFlag = this.insertMode.getValue() === 'insert_before'

        this.opcodeSelector = new OpcodeSelector({
            app: this.app,
            parentElem: this.container,
            selector: '.opcode_selector',
        })
        this.opcodeSelector.addListener('opcodeAdded', this.onOpcodeAdded.bind(this))

        this.funcBody = new FunctionBody({
            app: this.app,
            editor: this,
            parentElem: this.container,
            selector: '.func_body',
        })
        this.funcBody.addListener('selectionChanged', this.onSelectionChanged.bind(this))

        this.currentInstr = null
    }
    onSelectionChanged(opcode) {
        this.currentInstr = opcode
    }
    onInsertModeSelected(mode) {
        this.insertBeforeFlag = mode === 'insert_before'
    }
    onOpcodeAdded(opcode) {
        if (this.currentInstr) {
            if (this.insertBeforeFlag) {
                this.funcBody.insertBefore(opcode, this.currentInstr)
            } else {
                this.funcBody.insertAfter(opcode, this.currentInstr)
            }
        } else {
            if (this.insertBeforeFlag) {
                this.funcBody.prepend(opcode)
            } else {
                this.funcBody.append(opcode)
            }
        }
    }
    show() {
        this.opcodeSelector.show()
        this.funcBody.setData(this.app.wasmProgram.functions.currentFunction.body)
        this.funcBody.show()
        super.show()
    }
    onOkClick() {
        this.app.wasmProgram.functions.currentFunction.body = this.funcBody.getData()
        this.hide()
        this.emit('ok', this.funcBody)
    }
}
