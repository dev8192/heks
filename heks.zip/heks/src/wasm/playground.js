const types = [
  { name: 't1', param: [], result: ['i32', 'i64'] },
  { name: '', param: [], result: [] },
  { name: '', param: ['i32', 'i32'], result: [] },
  { name: 't2', param: ['i32'], result: ['i32'] },
  { name: '', param: ['i32', 'i32'], result: ['i32'] },
]

const valType = {
    f64: 0x7c,
    f32: 0x7d,
    i64: 0x7e,
    i32: 0x7f,
}

function buildTypeSection(types) {
    const bytes = []
    for (const { param = [], result = [] } of types) {
        bytes.push(0x60)
        bytes.push(param.length)
        for (const p of param) {
            bytes.push(valType[p])
        }
        bytes.push(result.length)
        for (const r of result) {
            bytes.push(valType[r])
        }
    }
    const count = types.length
    const size = 1 + bytes.length
    return [0x01, size, count, ...bytes]
}

function buildWatStrings(types) {
    const arr = []
    for (const { name = '', param = [], result = [] } of types) {
        const typeDef = [
            '(type '
        ]
        if (name) {
            typeDef.push(`$${name} `)
        }
        typeDef.push('(func')
        const parts = []
        if (param.length) {
            parts.push(`(param ${param.join(' ')})`)
        }
        if (result.length) {
            parts.push(`(result ${result.join(' ')})`)
        }
        if (parts.length) {
            typeDef.push(' ' + parts.join(' '))
        }
        typeDef.push('))')
        arr.push(typeDef.join(''))
    }
    return arr
}

function buildPrettyString(bytes) {
    const lines = []
    lines.push(
        "0x" + bytes[0].toString(16).padStart(2, "0") + ", " +
        "0x" + bytes[1].toString(16).padStart(2, "0") + ", " +
        "0x" + bytes[2].toString(16).padStart(2, "0") + ", // type"
    )

    let i = 3
    while (i < bytes.length) {
        const start = i
        if (bytes[i] === 0x60) {
            const paramsCount = bytes[i + 1]
            const resultsCountIndex = i + 2 + paramsCount
            const resultsCount = bytes[resultsCountIndex]
            const end = resultsCountIndex + 1 + resultsCount
            const arr = []
            for (let i = start; i < end; i++) {
                arr.push("0x" + bytes[i].toString(16).padStart(2, "0"))
            }
            lines.push("    " + arr.join(", ") + ",")
            i = end
        } else {
            i++
        }
    }
    return lines.join("\n")
}

const typeSection = buildTypeSection(types)
const watStrings = buildWatStrings(types)
const pretty = buildPrettyString(typeSection)

console.log(typeSection)
console.log(watStrings)
console.log(pretty)
