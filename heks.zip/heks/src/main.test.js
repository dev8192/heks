;(function() {
    function test(opts) {
        const tabsContainer = document.querySelector('.tabs_container')
        if (tabsContainer.childElementCount !== opts.editors.length) {
            console.log('Wrong number of tabs', tabsContainer.childElementCount)
            return false
        }
        for (let i = 0; i < opts.editors.length; i++) {
            const tab = tabsContainer.children[i]
            const fileNameElem = tab.querySelector('.file_name')
            if (fileNameElem.textContent !== opts.editors[i].fileName) {
                console.log('Wrong file name')
                return false
            }
        }
        return true
    }

    // test(app.opts)
})();