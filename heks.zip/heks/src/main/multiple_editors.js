/*
    Multiple editors
*/
const hexString1 = 
    '00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f ' +
    'ff ff ff ff ff ff ff ff ff ff ff ff ff ff'
const hexString2 = 
    '00 ff 00 00 00 00 00 00 08 00 00 00 00 00 00 00 ' +
    '00 01 00 00 00 00 00 00 08 00 00 00 00 00 00 00 ' +
    '00 02 00 00 00 00 00 00 08 00 00 00 00 00 00 00 ' +
    '00 03 00 00 00 00 00 00 08 00 00 00 00 00 00 00 ' +
    '00 04 00 00 00 00 00 00 08 00 00 00 00 00 00 00 ' +
    // '00 05 00 00 00 00 00 00 08 00 00 00 00 00 00 00 ' +
    // '00 06 00 00 00 00 00 00 08 00 00 00 00 00 00 00 ' +
    // '00 07 00 00 00 00 00 00 08 00 00 00 00 00 00 00 ' +
    // '00 08 00 00 00 00 00 00 08 00 00 00 00 00 00 00 ' +
    // '00 09 00 00 00 00 00 00 08 00 00 00 00 00 00 00 ' +
    // '00 0a 00 00 00 00 00 00 08 00 00 00 00 00 00 00 ' +
    // 'ff ff ff ff ff ff ff ff'
    'ff ff ff ff ff ff ff ff ff ff ff ff ff ff ff ff'
const hexString3 = 
    '00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f ' +
    '00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f ' +
    '00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f ' +
    '00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f ' +
    'ff ff ff ff ff ff ff ff ff ff ff ff ff ff ff'
const app = new Heks({
    editors: [
        {
            fileName: 'hexString2',
            buffer: strToArrayBuffer(hexString2),
        },
        // {
        //     fileName: 'hexString3',
        //     buffer: strToArrayBuffer(hexString3),
        // },
    ],
    // showCols: false,
    // showRows: false,
    maxRows: 5,
    showAddCellButton: true,
    // navPreset: 'arrows',
    // navPreset: 'wasd',
})
app.selectCell(24)
// app.settingsView.show()
