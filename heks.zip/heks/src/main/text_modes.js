
/*
    Text modes: declarative style
*/
const textModes = [
    {
        id: 'decNum',
        charset: 'ASCII',
        name: 'Decimal numbers',
        values: [
            [0x30, 0x39]
        ],
        color: 'cornflowerblue',
    },
    {
        id: 'latinAlphabet',
        charset: 'ASCII',
        name: 'Latin alphabet',
        values: [
            [65, 90],
            [97, 122],
        ],
        color: 'plum',
    },
    // {
    //     charset: 'ASCII',
    //     name: 'Hexadecimal numbers',
    //     values: [
    //         [0x30, 0x39],
    //         [0x41, 0x46],
    //         [0x61, 0x66],
    //     ],
    //     color: 'lightblue',
    // },
    {
        id: 'russianAlphabetWin1251',
        charset: 'Windows-1251',
        name: 'Russian alphabet',
        values: [
            0xA8, 0xB8,
            [0xC0, 0xFF],
        ],
        color: 'tomato',
    }
]
const app = new Heks({
    editors: [
        {
            fileName: 'example_1.txt',
            buffer: createAsciiTable(),
        },
    ],
    showCols: true,
    showRows: true,
    textModes: textModes,
})

