const app = new Heks({
    startView: 'file_explorer',
})

// app.fileExplorer.show()
// app.fileExplorer.addListener('ready', () => {
//     app.fileExplorer.treeView.selectItem('<root>')
//     // app.fileExplorer.treeView.startItemCreating('dir_item')
// })
