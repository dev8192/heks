/*
    A lot of tabs
*/
let editors = []
for (let i = 0; i < 32; i++) {
    editors.push({
        fileName: `file-${i + 1}`,
        buffer: new Uint8Array([i + 1]).buffer,
    })
}
const app = new Heks({
    editors,
})
