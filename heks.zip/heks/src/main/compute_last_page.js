/*
    EditorView.computeLastPage
*/
const hexString1 = 
    '00 ff 00 00 00 00 00 00 08 00 00 00 00 00 00 00 ' +
    '00 01 00 00 00 00 00 00 08 00 00 00 00 00 00 00 ' +
    '00 02 00 00 00 00 00 00 08 00 00 00 00 00 00 00 ' +
    '00 03 00 00 00 00 00 00 08 00 00 00 00 00 00 00 ' +
    'ff ff ff ff ff ff ff ff ff ff ff ff ff ff ff'
const hexString2 = hexString1 + ' ff'
const hexString3 = hexString2 + ' ff'
const app = new Heks({
    editors: [
        {
            fileName: 'hexString1',
            buffer: strToArrayBuffer(hexString1),
        },
        {
            fileName: 'hexString2',
            buffer: strToArrayBuffer(hexString2),
        },
        {
            fileName: 'hexString3',
            buffer: strToArrayBuffer(hexString3),
        },
    ],
    showCols: true,
    showRows: true,
    maxRows: 5,
    showAddCellButton: true,
})
