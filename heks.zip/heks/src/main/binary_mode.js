/*
    Binary mode
*/
const app = new Heks({
    buffer: createUnicodeTable(),
    showCols: true,
    showRows: true,
    // mode: 'hex',
    mode: 'bin',
})
