const app = new Heks({
    startView: 'workspace_view',
})

// app.workspaceMgr.addListener('ready', () => {
//     app.workspaceMgr.openWorkspace({
//         backend: "FileSystem",
//         name: "12345",
//         type: "user",
//     })
// })
