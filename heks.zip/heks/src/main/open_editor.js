/*
    Test openEditor()
*/
async function main() {
    app = new Heks()
    await runAfterDelay(() => {
        app.createEditorFromBuffer({
            bufSize: 0,
            fileName: 'file1.txt',
        })
    }, 1000)
    await runAfterDelay(() => {
        app.createEditorFromBuffer({
            bufSize: 20,
            fileName: 'file2.txt',
        })
    }, 1000)
    await runAfterDelay(() => {
        app.createEditorFromBuffer({
            fileName: 'file3.txt',
            startOffset: 0,
            buffer: new Uint8Array([0xAA, 0xBB, 0xCC]).buffer,
        })
    }, 1000)
}
let app
main()
