const app = new Heks()
app.settingsView.show()
