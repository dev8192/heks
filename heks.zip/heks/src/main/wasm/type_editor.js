const app = new Heks({
    // startView: 'wasm_view',
    startView: 'wasm_builder',
})

app.wasmProgram.addType({
    name: 'type1',
    param: ['i32'],
    result: ['i64'],
})
app.wasmProgram.addType({
    name: 'type2',
    param: ['i32', 'i32'],
    result: ['i64'],
})
app.wasmProgram.addType({
    name: 'type3',
    param: ['f64', 'f64', 'f64'],
    result: [],
})

// app.wasmView.addTypeDialog.show()
// app.wasmView.addTypeDialog.setName('type2')
// app.wasmView.addTypeDialog.addParamType('i32')
// app.wasmView.addTypeDialog.addParamType('i32')
// app.wasmView.addTypeDialog.addResultType('i64')
// app.wasmView.addTypeDialog.addResultType('i64')

app.wasmProgram.addFunction({
    type: {param: ['f64', 'f64', 'f64']},
    name: 'func1',
    export: 'func1',
})

app.wasmProgram.addFunction({
    type: {param: ['i32', 'i32'], result: ['i64']},
    name: 'func2',
    export: 'func2',
})

app.wasmProgram.selectFunction('func2')

app.wasmView.functionList.hide()
app.wasmView.codeEditor.show()

// setTimeout(() => {
//     app.wasmProgram.selectFunction('func1')
// }, 2000)

// app.wasmView.addFunctionDialog.show()
// app.wasmView.addFunctionDialog.setName('func1')
// app.wasmView.addFunctionDialog.setExport('func1')
