const app = new Heks()

const typeHandle1 = app.wasmProgram.addType({
    name: 'type1',
    param: ['i32', 'i32'],
    result: ['i32'],
})

// const typeHandle2 = new WasmType('type2')
// typeHandle2.setParams(['i32', 'i32'])
// typeHandle2.setResult(['i32'])

const funcHandle1 = app.wasmProgram.addFunction({
    // type: {param: ['i32', 'i32'], result: ['i32']},
    name: 'func1',
    // export: 'func1',
    bodyBytes: [
        0x20, 0x00, 
        0x20, 0x01, 
        0x6a,
    ]
})

funcHandle1.setName('func1')
funcHandle1.setCode([
    0x20, 0x00, 
    0x20, 0x01, 
    0x6a,
])

const typeHandle11 = app.wasmProgram.getType({param: ['i32', 'i32'], result: ['i32']})
// funcHandle1.setType(typeHandle11)

funcHandle1.setType(typeHandle1)

funcHandle1.setDefaultParam({offset: 0, value: 5})
funcHandle1.setDefaultParam({offset: 1, value: 10})
// funcHandle1.clearDefaultParam({offset: 1})

app.wasmProgram.addExport(funcHandle1)
// app.wasmProgram.removeExport(funcHandle1)

app.wasmProgram.build()
app.wasmRunner.show()
const str = app.wasmProgram.toHexString()
// console.log(str)
