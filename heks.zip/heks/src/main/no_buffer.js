/*
    No buffer
*/
const app = new Heks({
    editors: [
        {
            fileName: 'no_buffer',
        },
    ],
})
