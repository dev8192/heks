/*
    Default options
*/
const app = new Heks()
// app.newFileDialog.show()
app.settingsView.show()
