/*
    Test long file names
*/
const app = new Heks({
    editors: [
        {
            fileName: 'aaaaabbbbbccc',
            buffer: new ArrayBuffer(0),
        },
        {
            fileName: 'aaaaabbbbbccccc',
            buffer: new ArrayBuffer(0),
        },
        {
            fileName: 'aaaaabbbbbcccccddd',
            buffer: new ArrayBuffer(0),
        },
    ],
})
