const app = new Heks({
    startView: 'workspace_view',
})

console.log('nodejs_backend_main.js')

// app.workspaceMgr.addListener('ready', () => {
//     app.workspaceMgr.openWorkspace({
//         backend: "FileSystem",
//         name: "12345",
//         type: "user",
//     })
// })
