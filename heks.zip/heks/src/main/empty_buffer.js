/*
    Empty buffer
*/
const app = new Heks({
    editors: [
        {
            fileName: 'empty_buffer',
            buffer: new ArrayBuffer(0),
        },
    ],
})
