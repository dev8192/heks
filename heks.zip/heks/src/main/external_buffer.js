/*
    External buffer
*/
const app = new Heks({
    editors: [
        {
            // buffer: new Uint8Array(16).map((_, i) => i).buffer,
            // buffer: createLatinAlphabet(),
        }
    ],
    showCols: true,
    showRows: true,
})
