class TreeViewNested extends TreeViewBase {
    constructor(opts) {
        super(opts)
        this.populate(opts.data, this.container)
    }
    toggleDirVisibility(item) {
        const childContainer = item.nextElementSibling
        if (!childContainer) {
            return
        }
        if (childContainer.classList.contains('hidden')) {
            childContainer.classList.remove('hidden')
        } else {
            childContainer.classList.add('hidden')
        }
    }
    onClick(event) {
        if (event.target.classList.contains('file_item')) {
            this.selectItem(event.target)
        } else if (event.target.classList.contains('dir_item')) {
            this.toggleDirVisibility(event.target)
        }
    }
    populate(obj, container, level = 0) {
        const itemContainer = document.createElement('div')
        itemContainer.classList.add('vbox')
        // itemContainer.style.marginLeft = (level * 30) + 'px'
        container.append(itemContainer)

        let objName
        if (level === 0) {
            objName = '<root>'
        } else {
            objName = obj.name
        }
        const titleElem = document.createElement('button')
        titleElem.textContent = objName
        if (obj.children) {
            titleElem.classList.add('dir_item')
        } else {
            titleElem.classList.add('file_item')
        }
        itemContainer.append(titleElem)

        let childCount = 0
        if (obj.children && obj.children.length > 0) {
            const childContainer = document.createElement('div')
            childContainer.classList.add('child_container')
            itemContainer.append(childContainer)

            const leftContainer = document.createElement('div')
            leftContainer.classList.add('vbox') 
            leftContainer.classList.add('placeholder_container')
            childContainer.append(leftContainer)

            const contentElem = document.createElement('div')
            contentElem.classList.add('vbox')
            childContainer.append(contentElem)
            
            for (const item of obj.children) {
                childCount += this.populate(item, contentElem, level + 1)
            }
            // for (let i = 0; i < childCount; i++) {
            //     const placeholderElem = document.createElement('div')
            //     placeholderElem.classList.add('placeholder') 
            //     leftContainer.append(placeholderElem)
            // }
            if (obj.children.length > 0) {
                childCount++
            }
        } else {
            childCount++
        }
        console.log(objName, childCount)
        return childCount
    }
}
