class TreeViewFlat extends TreeViewBase {
    constructor(opts) {
        super(opts)
        this.printMessage = this.app.printMessage
        this.showChildCount = true
        this.showPlaceholders = true
        
        this.rowElemToObjectMap = new Map()
        this.pathToObjectMap = new Map()

        this.rootObject = {
            name: '<root>',
            parent: null,
            level: 0,
        }

        this.removeRowInternal = this.removeRowInternal.bind(this)

        this.selectedObject = null
        this.fileRenamingInProgress = false
        
        this.onClick = this.onClick.bind(this)
        this.resumeEvents()

        this.kbdMgr = new KeyboardManager({
            container: this.container,
        })

        this.onArrowUp = this.onArrowUp.bind(this)
        this.onArrowDown = this.onArrowDown.bind(this)
        this.onArrowLeft = this.onArrowLeft.bind(this)
        this.clearSelection = this.clearSelection.bind(this)
        this.startItemRenaming = this.startItemRenaming.bind(this)
        this.onSpacebarClick = this.onSpacebarClick.bind(this)
        this.removeItem = this.removeItem.bind(this)

        this.kbdMgr.addHandler('ArrowUp', this.onArrowUp)
        this.kbdMgr.addHandler('ArrowDown', this.onArrowDown)
        this.kbdMgr.addHandler('ArrowLeft', this.onArrowLeft)
        this.kbdMgr.addHandler('Escape', this.clearSelection)
        this.kbdMgr.addHandler('F2', this.startItemRenaming)
        this.kbdMgr.addHandler('Space', this.onSpacebarClick)
        this.kbdMgr.addHandler('Delete', this.removeItem)
        
        // this.nameInput = new TextInput()
        this.nameInput = this.app.widgets['text_input']

        this.onNameInputOk = this.onNameInputOk.bind(this)
        this.nameInput.addListener('ok', this.onNameInputOk)
        this.onNameInputCancel = this.onNameInputCancel.bind(this)
        this.nameInput.addListener('cancel', this.onNameInputCancel)
        this.onNameInput = this.onNameInput.bind(this)
        this.nameInput.addListener('input', this.onNameInput)
    }
    resumeEvents() {
        this.container.addEventListener('click', this.onClick)
    }
    pauseEvents() {
        this.container.removeEventListener('click', this.onClick)
    }
    populateRows(data) {
        this.container.innerHTML = ''
        this.populateInternal(data, this.rootObject)

        if (this.showPlaceholders) {
            TreeViewBase.traverse(this.rootObject, this.createPlaceholders.bind(this))
            TreeViewBase.traverse(this.rootObject, this.populatePlaceholders.bind(this))
        } else {
            this.marginSz = 50
            TreeViewBase.traverse(this.rootObject, this.setMargin.bind(this))
        }

        if (this.showChildCount) {
            this.populateChildCount = this.populateChildCount.bind(this)
            TreeViewBase.traverse(this.rootObject, this.populateChildCount)
        }
    }
    populateInternal(inputObj, outputObj) {
        if (inputObj.children) {
            outputObj.children = []
        }
        const rowElem = this.createRow(outputObj)
        outputObj.path = this.getPathString(outputObj)
        this.pathToObjectMap.set(outputObj.path, outputObj)
        this.container.append(rowElem)

        if (inputObj.children) {
            for (const childObj of inputObj.children) {
                const newObj = {
                    name: childObj.name,
                    parent: outputObj,
                    level: outputObj.level + 1,
                }
                outputObj.children.push(newObj)
                this.populateInternal(childObj, newObj)
            }
        }
    }
    createRow(obj) {
        obj.temp = false

        const rowElem = document.createElement('div')
        rowElem.classList.add('row')
        obj.rowElem = rowElem

        this.rowElemToObjectMap.set(rowElem, obj)

        const toggleElem = document.createElement('div')
        toggleElem.classList.add('toggle_elem')
        if (obj.children) {
            toggleElem.textContent = '▼'
            toggleElem.classList.add('triangle')
            obj.isCollapsed = false
        }
        rowElem.append(toggleElem)
        obj.toggleElem = toggleElem

        const titleElem = document.createElement('div')
        titleElem.classList.add('title')
        titleElem.textContent = obj.name
        if (obj.children) {
            titleElem.classList.add('dir_item')
        } else {
            titleElem.classList.add('file_item')
        }
        rowElem.append(titleElem)
        obj.titleElem = titleElem

        return rowElem
    }
    getPathString(obj) {
        const segments = []
        while (obj) {
            segments.push(obj.name)
            obj = obj.parent
        }
        segments.reverse()
        return segments.join('/')
    }
    selectNextObject(obj) {
        const index = obj.parent.children.indexOf(obj)
        let nextObject = obj.parent.children[index + 1]
        if (!nextObject) {
            nextObject = obj.parent.children[index - 1]
            if (!nextObject) {
                nextObject = obj.parent
            }
        }
        return nextObject
    }
    setMargin(obj) {
        obj.rowElem.style.marginLeft = this.marginSz * obj.level + 'px'
    }
    createPlaceholders(obj) {
        obj.placeholders = []
        for (let i = 0; i < obj.level; i++) {
            const placeholderElem = document.createElement('div')
            placeholderElem.classList.add('placeholder')
            obj.rowElem.insertBefore(placeholderElem, obj.rowElem.firstElementChild)
            obj.placeholders.push(placeholderElem)
        }
        obj.placeholders.reverse()
    }
    populatePlaceholders(obj) {
        const parents = []
        let tempObj = obj
        // if (obj.name === 'sss') debugger
        while (tempObj.parent && tempObj.parent.name !== '<root>') {
            parents.push(tempObj.parent)
            tempObj = tempObj.parent
        }
        // parents.pop()
        parents.reverse()
        for (let i = 0; i < obj.level; i++) {
            if ((i + 1) === obj.level) {
                if (obj.temp) {
                    const childCount = obj.parent.children.length
                    if (childCount === 0) {
                        obj.placeholders[i].textContent = '└'
                    } else {
                        obj.placeholders[i].textContent = '├'
                    }
                } else {
                    const parentArr = obj.parent.children
                    if (parentArr[parentArr.length - 1] === obj) {
                        obj.placeholders[i].textContent = '└'
                    } else {
                        obj.placeholders[i].textContent = '├'
                    }
                }
            } else {
                const parentObj = parents[i].parent
                if (parentObj) {
                    const lastChild = parentObj.children[parentObj.children.length - 1]
                    if (parents[i] !== lastChild) {
                        obj.placeholders[i].textContent = '│'
                    }
                }
            }
        }
        if (!obj.children) {
            obj.toggleElem.textContent = '─'
        }
    }
    updatePlaceholders(obj) {
        if (!obj.parent) {
            return
        }
        if (obj.parent.children[obj.parent.children.length - 1] !== obj) {
            return
        }
        const index = obj.placeholders.length - 1
        obj.placeholders[index].textContent = '└'
        if (obj.children) {
            TreeViewBase.traverse(obj, (obj) => {
                obj.placeholders[index].textContent = ''
            })
        }
        obj.placeholders[obj.placeholders.length - 1].textContent = '└'
    }
    populateChildCount(obj) {
        if (!obj.children) {
            return
        }
        const childCountElem = document.createElement('div')
        childCountElem.classList.add('child_count')
        obj.rowElem.append(childCountElem)
        obj.childCountElem = childCountElem
        this.setChildCount(obj)
    }
    setChildCount(obj) {
        obj.childCountElem.textContent = `(${obj.children.length})`
    }
    fileNameIsValid(fileName) {
        fileName = fileName.trim()
        if (fileName.length === 0) {
            this.printMessage('File name is too short')
            return false
        }
        if (fileName.includes('/')) {
            this.printMessage('File name cannot contain /')
            return false
        }
        return true
    }
    /******************** Event handlers ********************/
    onClick(event) {
        const elem = event.target
        if (elem === this.container) {
            this.clearSelection()
            return
        }
        if (elem.classList.contains('file_item') || elem.classList.contains('dir_item')) {
            const obj = this.rowElemToObjectMap.get(elem.parentElement)
            this.selectItemInternal(obj)
        }
        if (elem.classList.contains('triangle')) {
            const obj = this.rowElemToObjectMap.get(elem.parentElement)
            this.toggleDirVisibility(obj)
        }
    }
    /******************** Collapse & Expand ********************/
    recursiveShow(toggleElem, level) {
        let row = toggleElem.parentElement
        const obj = this.rowElemToObjectMap.get(row)
        row = row.nextElementSibling
        if (obj.isCollapsed) {
            while(row && this.rowElemToObjectMap.get(row).level > level) {
                row = row.nextElementSibling
            }
            return row
        }
        while(row && this.rowElemToObjectMap.get(row).level > level) {
            row.classList.remove('hidden')
            const toggleElem = row.querySelector('.triangle')
            if (toggleElem) {
                row = this.recursiveShow(toggleElem, level + 1)
            } else {
                row = row.nextElementSibling
            }
        }
        return row
    }
    recursiveHide(toggleElem, level) {
        let row = toggleElem.parentElement
        row = row.nextElementSibling
        while(row && this.rowElemToObjectMap.get(row).level > level) {
            row.classList.add('hidden')
            row = row.nextElementSibling
        }
    }
    toggleDirVisibility(obj) {
        if (obj.children.length === 0) {
            return
        }
        const isCollapsed = obj.isCollapsed
        obj.isCollapsed = !obj.isCollapsed
        if (isCollapsed) {
            obj.toggleElem.textContent = '▼'
            this.recursiveShow(obj.toggleElem, obj.level)
        } else {
            obj.toggleElem.textContent = '▶'
            this.recursiveHide(obj.toggleElem, obj.level)
        }
    }
    /******************** Selection ********************/
    selectItem(path) {
        const obj = this.pathToObjectMap.get(path)
        this.selectItemInternal(obj)
    }
    selectItemInternal(obj) {
        if (this.selectedObject) {
            this.selectedObject.titleElem.classList.remove('selected')
            this.emit('selectionCleared')
            if (this.selectedObject.titleElem === obj.titleElem) {
                this.selectedObject = null
            } else {
                obj.titleElem.classList.add('selected')
                this.selectedObject = obj
                this.emit('itemSelected', {
                    path: obj.path,
                    isDir: !!obj.children,
                    temp: obj.temp,
                })
            }
        } else {
            obj.titleElem.classList.add('selected')
            this.selectedObject = obj
            this.emit('itemSelected', {
                path: obj.path,
                isDir: !!obj.children,
                temp: obj.temp,
            })
        }
    }
    clearSelection() {
        if (!this.selectedObject) return
        this.selectedObject.titleElem.classList.remove('selected')
        this.emit('selectionCleared')
        this.selectedObject = null
    }
    /******************** Keyboard events ********************/
    onSpacebarClick() {
        if (!this.selectedObject) return
        const elem = this.selectedObject.toggleElem
        if (!elem) return
        this.toggleDirVisibility(this.selectedObject)
    }
    onArrowUp() {
        if (!this.selectedObject) {
            this.selectItemInternal(this.rootObject)
            return
        }
        const row = this.selectedObject.rowElem
        const prevRow = this.getPrevVisible(row)
        if (!prevRow) return
        const prevObj = this.rowElemToObjectMap.get(prevRow)
        this.selectItemInternal(prevObj)
    }
    getPrevVisible(row) {
        return row.previousElementSibling
        // row = row.previousElementSibling
        // while(row && !this.toggleElemToStateMap.get(row.querySelector('.title'))) {
        //     row = row.previousElementSibling
        // }
        // return row
    }
    onArrowDown() {
        if (!this.selectedObject) {
            this.selectItemInternal(this.rootObject)
            return
        }
        const row = this.selectedObject.rowElem
        const obj = this.rowElemToObjectMap.get(row)
        const nextRow = this.getNextVisible(row, obj.level)
        if (!nextRow) return
        const nextObj = this.rowElemToObjectMap.get(nextRow)
        this.selectItemInternal(nextObj)
    }
    getNextVisible(row, level) {
        return row.nextElementSibling

        row = row.nextElementSibling
        if (!row) {
            return
        }
        if (row.querySelector('.file_item')) {
            return row
        }
        const toggleElem = row.querySelector('.triangle')
        if (this.toggleElemToStateMap.get(toggleElem)) {
            this.skipCollapsedDir()
        }
        // while(row && this.rowElemToLevelMap.get(row) >= level) {
        //     if (!this.toggleElemToStateMap.get(row.querySelector('.triangle'))) {
        //         break
        //     } else {

        //     }
        //     row = row.nextElementSibling
        // }
        return row
    }
    skipCollapsedDir() {
        let row = toggleElem.parentElement
        const obj = this.rowElemToObjectMap.get(row)
        row = row.nextElementSibling
        if (obj.isCollapsed) {
            while(row && this.rowElemToLevelMap.get(row) > level) {
                row = row.nextElementSibling
            }
            return row
        }
        while(row && this.rowElemToLevelMap.get(row) > level) {
            row.classList.remove('hidden')
            const toggleElem = row.querySelector('.triangle')
            if (toggleElem) {
                row = this.recursiveShow(toggleElem, level + 1)
            } else {
                row = row.nextElementSibling
            }
        }
        return row
    }
    onArrowLeft() {
        if (!this.selectedObject) return
        const parentObj = this.selectedObject.parent
        if (parentObj) {
            this.selectItemInternal(parentObj)
        } else {
            this.printMessage('This is the <root> folder')
        }
    }
    /******************** Name input ********************/
    onNameInputOk() {
        if (this.fileRenamingInProgress) {
            this.finishItemRenaming()
        } else {
            this.finishFileCreating()
        }
    }
    onNameInputCancel() {
        if (this.fileRenamingInProgress) {
            this.cancelItemRenaming()
        } else {
            this.cancelItemCreating()
        }
    }
    onNameInput(value) {
        this.emit('nameInput', value)
    }
    /******************** Create item ********************/
    startItemCreating(itemType) {
        let newObj
        if (itemType === 'file_item') {
            newObj = {
                name: this.defaultFileName,
            }
        } else {
            newObj = {
                name: this.defaultDirName,
                children: [],
            }
        }
        newObj.parent = this.selectedObject
        newObj.level = this.selectedObject.level + 1
        const selectedRow = this.selectedObject.rowElem
        const rowElem = this.createRow(newObj)
        newObj.path = newObj.parent.path + '/' + newObj.name
        newObj.temp = true
        if (this.showPlaceholders) {
            this.createPlaceholders(newObj)
            this.populatePlaceholders(newObj)
        } else {
            this.setMargin(newObj)
        }
        if (this.showChildCount) {
            this.populateChildCount(newObj)
        }
        const nextRow = selectedRow.nextElementSibling
        this.container.insertBefore(rowElem, nextRow)
        this.selectItemInternal(newObj)

        this.selectedObject.titleElem.replaceWith(this.nameInput.container)
        this.nameInput.focus()
        this.nameInput.setValue(this.selectedObject.name)
    }
    finishFileCreating() {
        const fileName = this.nameInput.getValue()
        if (this.fileNameIsValid(fileName)) {
            const obj = this.selectedObject
            obj.temp = false
            const newPath = obj.parent.path + '/' + fileName
            obj.path = newPath
            obj.name = fileName
            obj.titleElem.textContent = fileName
            this.pathToObjectMap.set(newPath, obj)
            obj.parent.children = [
                obj,
                ...obj.parent.children,
            ]
            if (this.showChildCount) {
                this.setChildCount(obj.parent)
            }
            this.emit('itemCreated', {
                path: newPath,
                isDir: !!obj.children,
            })
            this.nameInput.container.replaceWith(obj.titleElem)
            this.selectItemInternal(obj.parent)
            this.container.focus()
        }
    }
    cancelItemCreating() {
        this.selectedObject.rowElem.remove()
        this.rowElemToObjectMap.delete(this.selectedObject.rowElem)
        this.pathToObjectMap.delete(this.selectedObject.path)
        this.selectItemInternal(this.selectedObject.parent)
        this.container.focus()
        this.emit('actionCanceled', {
            value: this.selectedObject.name,
        })
    }
    /******************** Rename item ********************/
    startItemRenaming() {
        this.fileRenamingInProgress = true
        this.selectedObject.titleElem.replaceWith(this.nameInput.container)
        this.nameInput.focus()
        this.nameInput.setValue(this.selectedObject.name)
        this.emit('renameStarted')
    }
    finishItemRenaming() {
        this.fileRenamingInProgress = false
        const newName = this.nameInput.getValue()
        if (this.fileNameIsValid(newName)) {
            const oldPath = this.selectedObject.path
            const newPath = this.selectedObject.parent.path + '/' + newName
            this.selectedObject.path = newPath
            this.selectedObject.name = newName
            this.selectedObject.titleElem.textContent = newName
            TreeViewBase.traverse(this.selectedObject, (obj) => {
                this.pathToObjectMap.delete(obj.path)
                obj.path = this.getPathString(obj)
                this.pathToObjectMap.set(obj.path, obj)
            })
            this.emit('renameFinished', {
                from: oldPath,
                to: newPath,
            })
            this.nameInput.container.replaceWith(this.selectedObject.titleElem)
            this.container.focus()
        }
    }
    cancelItemRenaming() {
        this.fileRenamingInProgress = false
        this.nameInput.container.replaceWith(this.selectedObject.titleElem)
        this.container.focus()
        this.emit('actionCanceled', {
            value: this.selectedObject.name,
        })
    }
    /******************** Remove item ********************/
    removeItem() {
        if (!this.selectedObject.parent) {
            this.printMessage('Cannot remove <root>')
            return
        }
        let newObj = this.selectNextObject(this.selectedObject)
        
        this.selectedObject.titleElem.classList.remove('selected')
        this.emit('selectionCleared')

        const parentObj = this.selectedObject.parent
        parentObj.children = parentObj.children.filter((item) => {
            return item !== this.selectedObject
        })

        if (this.showChildCount) {
            this.setChildCount(parentObj)
        }

        TreeViewBase.traverse(this.selectedObject, this.removeRowInternal)
        this.emit('itemDeleted', {
            path: this.selectedObject.path,
            isDir: !!this.selectedObject.children,
        })

        newObj.titleElem.classList.add('selected')
        this.selectedObject = newObj
        this.emit('itemSelected', {
            path: newObj.path,
            isDir: !!newObj.children,
            temp: newObj.temp,
        })

        if (this.showPlaceholders) {
            this.updatePlaceholders(newObj)
        }
    }
    removeRowInternal(obj) {
        obj.rowElem.remove()
        this.rowElemToObjectMap.delete(obj.rowElem)
        this.pathToObjectMap.delete(obj.path)
    }
    /******************** Collapse & Expand (2) ********************/
    expandRecursivelyInternal(obj) {
        obj.isCollapsed = false
        obj.toggleElem.textContent = '▼'
        obj.rowElem.classList.remove('hidden')
        this.recursiveShow(obj.toggleElem, obj.level)
        for (const childObj of obj.children) {
            if (childObj.children) {
                this.expandRecursivelyInternal(childObj)
            }
        }
    }
    expandRecursively() {
        if (!this.selectedObject) return
        if (!this.selectedObject.children) return
        this.expandRecursivelyInternal(this.selectedObject)
    }
    collapseChildrenInternal(obj) {
        if (obj.children) {
            obj.isCollapsed = true
            obj.toggleElem.textContent = '▶'
            for (const childObj of obj.children) {
                this.collapseChildrenInternal(childObj)
            }
        } else {
            obj.rowElem.classList.add('hidden')
        }
    }
    collapseChildren() {
        if (!this.selectedObject) return
        if (!this.selectedObject.children) return
        for (const childObj of this.selectedObject.children) {
            if (childObj.children) {
                this.collapseChildrenInternal(childObj)
            }
        }
    }
}
