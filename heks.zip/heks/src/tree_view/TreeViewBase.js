class TreeViewBase extends Widget {
    constructor(opts) {
        super(opts)
        this.defaultFileName = 'New file'
        this.defaultDirName = 'New folder'
    }
    static traverse(obj, callback, data) {
        callback(obj, data)
        if (obj.children) {
            for (const childObj of obj.children) {
                TreeViewBase.traverse(childObj, callback, data)
            }
        }
    }
}
