/*
Access to fetch at 'http://localhost:4444/' from origin 'null'
has been blocked by CORS policy:
No 'Access-Control-Allow-Origin' header is present on the requested resource.
*/
const http = require('http')

const server = http.createServer((req, res) => {
    console.log(req.url)
    res.writeHead(200, {
        'Content-Type': 'text/html',
        'Access-Control-Allow-Origin': '*',
    })
    res.end('<h1>Hello</h1>')
})

server.listen(4444)
