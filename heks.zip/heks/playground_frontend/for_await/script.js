function test1() {
    async function* asyncNumbers() {
        for (let i = 1; i <= 3; i++) {
            await new Promise(resolve => setTimeout(resolve, 500));
            yield i;
        }
    }

    async function run() {
        for await (const num of asyncNumbers()) {
            console.log(num);
        }
    }

    run();
}

function test1() {
    function createAsyncIterable() {
        let i = 1;
        return {
            [Symbol.asyncIterator]() {
                return {
                    async next() {
                        if (i <= 3) {
                            await new Promise(resolve => setTimeout(resolve, 500));
                            return { value: i++, done: false };
                        } else {
                            return { done: true };
                        }
                    }
                };
            }
        };
    }

    async function run() {
        for await (const num of createAsyncIterable()) {
            console.log(num);
        }
    }

    run();
}

function test1() {
    async function run() {
        const promises = [
            Promise.resolve('A'),
            Promise.resolve('B'),
            Promise.resolve('C')
        ];

        for await (const value of promises) {
            console.log(value);
        }
    }

    run();
}

function test() {
    async function run() {
        const promises = [
            new Promise(resolve => setTimeout(function() {
                resolve(500)
            }, 500)),
            new Promise(resolve => setTimeout(function() {
                resolve(1500)
            }, 1500)),
            new Promise(resolve => setTimeout(function() {
                resolve(1000)
            }, 1000)),
        ];

        for await (const value of promises) {
            console.log(value);
        }
    }

    run();
}

test()
