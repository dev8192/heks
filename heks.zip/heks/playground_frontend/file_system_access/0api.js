/*
    Blob
        File

    FileSystemHandle
        FileSystemFileHandle
        FileSystemDirectoryHandle
    
    FileSystemWritableFileStream

    FileList
    
    Ways to obtain an instance of FileSystemFileHandle:
    (1) showOpenFilePicker
    (2) showSaveFilePicker
    (3) showDirectoryPicker
    (4) Drag-and-Drop
*/

/*
    (3) showDirectoryPicker
*/
function test() {
    const button = createButton()
    button.addEventListener('click', async () => {
        try {
            const dirHandle = await window.showDirectoryPicker()
            console.log(dirHandle)
            const fileHandle = await dirHandle.getFileHandle('example.txt')
            console.log(fileHandle)
            const file = await fileHandle.getFile()
            console.log(file)
            const text = await file.text()
            console.log(text)
        } catch (err) {
            console.log(err)
            console.log(err.message)
        }
        console.log('done')
    })
}

test()
