/*
    FileSystemDirectoryHandle
*/

function test1() {
    const button = createButton()
    button.addEventListener('click', async () => {
        try {
            const dirHandle = await window.showDirectoryPicker()
            const dirHandle2 = await dirHandle.getDirectoryHandle('dir')
            const fileHandle = await dirHandle2.getFileHandle('file3.txt')
            const file = await fileHandle.getFile()
            const text = await file.text()
            console.log(text)
        } catch (err) {
            console.error('Error:', err)
            console.log(err.message)
        }
    })
}

function test() {
    const button = createButton()
    button.addEventListener('click', async () => {
        try {
            const dirHandle = await window.showSaveFilePicker()
            // const dirHandle = await window.showDirectoryPicker()
            console.log(dirHandle)
            return
            const iterator = dirHandle.entries()
            console.log(iterator)
            let item
            item = await iterator.next()
            console.log(item)
            item = await iterator.next()
            console.log(item)
            item = await iterator.next()
            console.log(item)
            item = await iterator.next()
            console.log(item)
        } catch (err) {
            console.error('Error:', err)
            console.log(err.message)
        }
    })
}

test()
