/*
    Simple text editor
*/
function test() {
    let fileHandle;

    const openButton = createButton('Open File')
    openButton.addEventListener('click', async () => {
        [fileHandle] = await window.showOpenFilePicker();

        const file = await fileHandle.getFile();
        const contents = await file.text();
        textarea.value = contents;
    });

    const saveButton = createButton('Save Changes')
    saveButton.addEventListener('click', async () => {
        if (!fileHandle) return;

        const writable = await fileHandle.createWritable();
        await writable.write(textarea.value);
        await writable.close();
    });

    const textarea = createTextarea()
}

test()
