
/*
    asynchronous iteration
*/
function test1() {
    async function listFilesRecursive(dirHandle, path = '') {
        for await (const [name, handle] of dirHandle.entries()) {
            const fullPath = `${path}${name}`
            if (handle.kind === 'file') {
                console.log(fullPath)
            } else if (handle.kind === 'directory') {
                await listFilesRecursive(handle, `${fullPath}/`)
            }
        }
    }

    const button = createButton()
    button.addEventListener('click', async () => {
        try {
            const dirHandle = await window.showDirectoryPicker()
            await listFilesRecursive(dirHandle)
        } catch (err) {
            if (err.name === 'AbortError') {
                console.log('User canceled directory picker.')
            } else {
                console.error('Error:', err)
            }
        }
    })
}

/*
    No for await
*/
function test1() {
    async function listFilesRecursive(dirHandle, path = '') {
        const iterator = dirHandle.entries()

        async function processNext() {
            const { value, done } = await iterator.next()
            if (done) return

            const [name, handle] = value
            const fullPath = path + name

            if (handle.kind === 'file') {
                console.log(fullPath)
            } else if (handle.kind === 'directory') {
                await listFilesRecursive(handle, fullPath + '/')
            }

            await processNext()
        }

        await processNext()
    }

    const button = createButton()
    button.addEventListener('click', async () => {
        try {
            const dirHandle = await window.showDirectoryPicker()
            await listFilesRecursive(dirHandle)
        } catch (err) {
            console.error('Error:', err)
        }
    })
}

/*
    No async await
*/
function test() {
    function listFilesRecursive(dirHandle, path) {
        const iterator = dirHandle.entries()
        return processNext(iterator, dirHandle, path)
    }

    function processNext(iterator, dirHandle, path) {
        return iterator.next().then(function ({ value, done }) {
            if (done) return Promise.resolve()

            const [name, handle] = value
            const fullPath = path + name

            if (handle.kind === 'file') {
                console.log(fullPath)
                return processNext(iterator, dirHandle, path)
            } else if (handle.kind === 'directory') {
                return listFilesRecursive(handle, fullPath + '/').then(function () {
                    return processNext(iterator, dirHandle, path)
                })
            }
        })
    }

    const button = createButton()
    button.addEventListener('click', function () {
        window.showDirectoryPicker().then(function (dirHandle) {
            listFilesRecursive(dirHandle, '').then(function () {
                console.log('Done listing files.')
            }).catch(function (err) {
                console.error('Error:', err)
            })
        }).catch(function (err) {
            console.error('Directory picker canceled or failed:', err)
        })
    })
}

test()
