/*
Is there a way to avoid show both of these and show only the first one?

Let site view files?
*** will be able to view files in *** until you close all tabs for this site
View files | Cancel

Save changes to ***?
*** will be able to edit files in *** until you close all tabs for this site
Save changes | Cancel
*/

function test1() {
    const button = createButton()
    button.addEventListener('click', async () => {
        try {
            const dirHandle = await window.showDirectoryPicker()
            console.log(dirHandle)

            // const permission = await dirHandle.requestPermission({ mode: 'readwrite' })
            // if (permission !== 'granted') {
            //     console.log('Permission denied.')
            //     return
            // }
            
            // const fileHandle = await dirHandle.getFileHandle('example2.txt')
            const fileHandle = await dirHandle.getFileHandle('example2.txt', {create: true})
            const writable = await fileHandle.createWritable()
            await writable.write('hello!')
            await writable.close()
        } catch (err) {
            if (err.name === 'AbortError') {
                console.log('User canceled the directory picker.')
            } else if (err.name === 'NotFoundError') {
                console.log('File not found.')
            } else {
                console.log('Error deleting file:', err)
            }
        }
    })
}

function test1() {
    const button = createButton()
    button.addEventListener('click', async () => {
        try {
            const dirHandle = await window.showDirectoryPicker()
            console.log(dirHandle)
            console.log('step 0')
            
            setTimeout(async function() {
                await dirHandle.removeEntry('file1.txt')
                console.log('step 1')
                await dirHandle.removeEntry('file2.txt')
                console.log('step 2')
                await dirHandle.removeEntry('file3.txt')
                console.log('step 3')
            }, 3000)
        } catch (err) {
            if (err.name === 'NotFoundError') {
                console.log('File not found.')
            } else if (err.name === 'AbortError') {
                console.log('User canceled the directory picker.')
            } else {
                console.log('Error deleting file:', err)
            }
        }
    })
}

test()
