/*
    Simple hex dump
*/
function test() {
    const button = createButton()
    button.addEventListener('click', async () => {
        try {
            const [fileHandle] = await window.showOpenFilePicker();
            const file = await fileHandle.getFile();
            const buffer = await file.arrayBuffer();
            const bytes = new Uint8Array(buffer);

            console.log('Hex dump:');
            let line = '';
            for (let i = 0; i < bytes.length; i++) {
                line += bytes[i].toString(16).padStart(2, '0') + ' ';
                if ((i + 1) % 16 === 0) {
                    console.log(line);
                    line = '';
                }
            }
            if (line) console.log(line);
        } catch (err) {
            console.error('Error reading file:', err);
        }
    });
}

test()
