const openedFileHandles = []

async function isFileOpened(fileHandle) {
    for (const handle of openedFileHandles) {
        if (await handle.isSameEntry(fileHandle)) {
            return true
        }
    }
}

/*
    Attempt to open a file with the same name
*/
function test() {
    const button = createButton()
    button.addEventListener('click', async () => {
        try {
            const [fileHandle] = await window.showOpenFilePicker()
            if (await isFileOpened(fileHandle)) {
                console.log('This file is already opened.')
                return
            }
            openedFileHandles.push(fileHandle)
            const file = await fileHandle.getFile()
            const contents = await file.text()
            console.log(contents)
        } catch (err) {
            if (err.name === 'AbortError') {
                console.log('File selection was canceled.')
            } else {
                console.error('Unexpected error:', err)
            }
        }
    })
}

test()
