/*
    Basic example
*/
function test() {
    const button = createButton()
    button.addEventListener('click', async () => {
        try {
            const fileHandle = await window.showSaveFilePicker()
            // const fileHandle = await window.showSaveFilePicker({
            //     suggestedName: 'example.txt',
            // })
            // const [fileHandle] = await window.showOpenFilePicker()
            console.log(fileHandle)
            const writable = await fileHandle.createWritable()
            const buffer = new Uint8Array(5).fill(38)
            await writable.write(buffer)
            await writable.close()
        } catch (err) {
            if (err.name === 'AbortError') {
                console.log('User canceled the save dialog.')
            } else {
                console.error('Error creating file:', err)
            }
        }
    })
}

/*
    Multiple buffers
*/
function test1() {
    const button = createButton()
    button.addEventListener('click', async () => {
        try {
            const fileHandle = await window.showSaveFilePicker({
                suggestedName: 'example.txt',
            })
            const writable = await fileHandle.createWritable()

            let buffer
            buffer = new Uint8Array(5).fill(97)
            await writable.write(buffer)
            await writable.write('\n')
            buffer = new Uint8Array(5).fill(98)
            await writable.write(buffer)
            await writable.write('\n')
            buffer = new Uint8Array(5).fill(99)
            await writable.write(buffer)
            await writable.write('\n')

            await writable.close()
        } catch (err) {
            if (err.name === 'AbortError') {
                console.log('User canceled the save dialog.')
            } else {
                console.error('Error creating file:', err)
            }
        }
    })
}

/*
    Large files
*/
function test1() {
    const button = createButton()
    button.addEventListener('click', async () => {
        try {
            // const largeFile = ['file_1mb.txt', 1_000_000]
            // const largeFile = ['file_10mb.txt', 10_000_000]
            // const largeFile = ['file_100mb.txt', 100_000_000]
            // const largeFile = ['file_1000mb.txt', 1_000_000_000]
            // const largeFile = ['file_2000mb.txt', 2_000_000_000]
            const largeFile = ['file_3000mb.txt', 3_000_000_000] // RangeError

            const fileHandle = await window.showSaveFilePicker({
                suggestedName: largeFile[0],
            })

            const buffer = new Uint8Array(largeFile[1]).fill(42)
            console.log('allocated successfully')
            const writable = await fileHandle.createWritable()
            await writable.write(buffer)
            await writable.close()
        } catch (err) {
            if (err.name === 'AbortError') {
                console.log('User canceled the save dialog.')
            } else {
                console.error('Error creating file:', err)
            }
        }
    })
}

/*
    RangeError: Array buffer allocation failed

    I want to create a buffer with Uint8Array(). what is the max buffer size?
*/
function test1() {
    // const bufSize = 3_000_000_000
    const bufSize = 2_145_386_496 // works
    // const bufSize = 2_145_386_497 // doesn't work
    const buffer = new Uint8Array(bufSize)
    buffer.fill(42)
    console.log('done')
}

/*
    Multiple writes
    But there is a catch: No flush
*/
function test1() {
    const button = createButton()
    button.addEventListener('click', async () => {
        try {
            const fileHandle = await window.showSaveFilePicker({
                suggestedName: 'numbers.txt'
            })

            const writable = await fileHandle.createWritable()

            let count = 1

            const interval = setInterval(async () => {
                await writable.write(count + '\n')
                count++

                if (count > 5) {
                    clearInterval(interval)
                    await writable.close()
                    console.log('File written successfully!')
                }
            }, 1000)

        } catch (err) {
            if (err.name === 'AbortError') {
                console.log('User canceled the save dialog.')
            } else {
                console.error('Error:', err)
            }
        }
    })
}

/*
    Flushing
*/
function test1() {
    const button = createButton()
    button.addEventListener('click', async () => {
        try {
            const fileHandle = await window.showSaveFilePicker({
                suggestedName: 'numbers.txt',
            })

            let count = 1
            let content = ''

            const interval = setInterval(async () => {
                content += count + '\n'

                const writable = await fileHandle.createWritable()
                await writable.write(content)
                await writable.close()

                count++
                if (count > 5) {
                    clearInterval(interval)
                    console.log('Done writing numbers!')
                }
            }, 1000)

        } catch (err) {
            console.error('Error:', err)
        }
    })
}

/*
    Append mode
*/
function test1() {
    const button = createButton()
    button.addEventListener('click', async () => {
        try {
            const fileHandle = await window.showSaveFilePicker({
                suggestedName: 'numbers.txt',
            })

            let count = 1

            const interval = setInterval(async () => {
                const file = await fileHandle.getFile()
                const size = file.size

                const writable = await fileHandle.createWritable({ keepExistingData: true })
                await writable.seek(size)
                await writable.write(count + '\n')
                await writable.close()

                count++
                if (count > 5) {
                    clearInterval(interval)
                    alert('Done appending numbers!')
                }
            }, 1000)

        } catch (err) {
            console.error('Error:', err)
        }
    })
}

/*
    Patching a file
*/
function test1() {
    const button = createButton()
    button.addEventListener('click', async () => {
        try {
            const [fileHandle] = await window.showOpenFilePicker()
            const writable = await fileHandle.createWritable({ keepExistingData: true })
            await writable.seek(4)
            await writable.write('TWO')
            await writable.close()
            console.log('File patched successfully!')
        } catch (err) {
            console.error('Error:', err)
        }
    })
}

/*
    A file with gaps (that are filled with NUL)
*/
function test1() {
    const button = createButton()
    button.addEventListener('click', async () => {
        try {
            const [fileHandle] = await window.showOpenFilePicker()
            const writable = await fileHandle.createWritable()
            await writable.write('Hello')
            await writable.seek(15)
            await writable.write('World')
            await writable.close()
            console.log('done')
        } catch (err) {
            console.error('Error:', err)
        }
    })

}

test()
