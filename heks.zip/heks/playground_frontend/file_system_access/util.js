function createButton(textContent = 'Click me') {
    const button = document.createElement('button')
    button.textContent = textContent
    document.body.appendChild(button)
    button.focus()
    return button
}

function createTextarea() {
    const textarea = document.createElement('textarea')
    textarea.placeholder = 'Open a file to start editing...'
    textarea.style.width = '100%'
    textarea.style.height = '300px'
    document.body.appendChild(textarea)
    return textarea
}
