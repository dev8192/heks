
/*
    Pipe
    lines are not written to disk, all data is accumulated in memory.
    whats the point of using streams here?
*/
function test() {
    const button = createButton()
    button.addEventListener('click', async () => {
        try {
            const fileHandle = await window.showSaveFilePicker({
                suggestedName: 'streamed.txt',
            });

            let count = 1;
            const readableStream = new ReadableStream({
                start(controller) {
                    const interval = setInterval(() => {
                        controller.enqueue(`Line ${count}\n`);
                        count++;
                        if (count > 5) {
                            clearInterval(interval);
                            controller.close();
                        }
                    }, 1000);
                }
            });

            const writableStream = await fileHandle.createWritable();
            await readableStream.pipeTo(writableStream);
            console.log('Streaming complete!');
        } catch (err) {
            console.error('Error:', err);
        }
    });
}

test()


