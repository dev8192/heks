
function createAsciiTable() {
    // const bufSize = 128
    const bufSize = 256
    const arr = new Uint8Array(bufSize)
    for (let i = 0; i < bufSize; i++) {
        arr[i] = i
    }
    return arr.buffer
}

function test() {
    const button = createButton()
    button.addEventListener('click', async () => {
        try {
            const fileHandle = await window.showSaveFilePicker({
                suggestedName: 'example.txt',
            })
            console.log(fileHandle)
            const writable = await fileHandle.createWritable()
            // const buffer = new Uint8Array(5).fill(37)
            const buffer = createAsciiTable()
            await writable.write(buffer)
            await writable.close()
        } catch (err) {
            if (err.name === 'AbortError') {
                console.log('User canceled the save dialog.')
            } else {
                console.error('Error creating file:', err)
            }
        }
    })
}

test()