
/*
    SecurityError: Failed to execute
    We need some sort of user activation
*/
function test1() {
    // showOpenFilePicker()
    window.showOpenFilePicker()
}

/*
    Basic example
*/
function test1() {
    const button = createButton()
    button.addEventListener('click', async () => {
        const fileHandles = await window.showOpenFilePicker()
        console.log(fileHandles)
        const file = await fileHandles[0].getFile()
        const contents = await file.text()
        console.log(contents)
    })
}

/*
    Alternative to click
*/
function test1() {
    addEventListener('keydown', async (event) => {
        console.log(event)
        if (event.code === 'Space') {
            const fileHandles = await window.showOpenFilePicker()
            console.log(fileHandles)
            const file = await fileHandles[0].getFile()
            const contents = await file.text()
            console.log(contents)
        }
    });
}

/*
    Multiple file handles
*/
function test1() {
    const button = createButton()
    button.addEventListener('click', async () => {
        const fileHandles = await window.showOpenFilePicker({
            multiple: true
        })
        console.log(fileHandles)
        for (const fileHandle of fileHandles) {
            const file = await fileHandle.getFile()
            const contents = await file.text()
            console.log(contents)
        }
    })
}

/*
    Catching AbortError
*/
function test1() {
    const button = createButton()
    button.addEventListener('click', async () => {
        try {
            const [fileHandle] = await window.showOpenFilePicker()
            const file = await fileHandle.getFile()
            const contents = await file.text()
            console.log(contents)
        } catch (err) {
            if (err.name === 'AbortError') {
                console.log('File selection was canceled.')
            } else {
                console.error('Unexpected error:', err)
            }
        }
    })
}

/*
    Options
*/
function test1() {
    const button = createButton()
    button.addEventListener('click', async () => {
        try {
            const [fileHandle] = await window.showOpenFilePicker({
                types: [{
                    accept: { 'text/plain': ['.txt'] }
                }],
                // excludeAcceptAllOption: true
                // startIn: 'desktop',
                // startIn: 'documents',
                // startIn: 'downloads',
                // startIn: 'music',
                // startIn: 'pictures',
                // startIn: 'videos',
                // startIn: 'hello', // TypeError
            })
            const file = await fileHandle.getFile()
            const contents = await file.text()
            console.log(contents)
        } catch (err) {
            if (err.name === 'AbortError') {
                console.log('File selection was canceled.')
            } else {
                console.error('Unexpected error:', err)
            }
        }
    })
}

/*
    % has special meaning in console.log
*/
function test1() {
    const button = createButton()
    button.addEventListener('click', async () => {
        const [fileHandle] = await window.showOpenFilePicker()
        const file = await fileHandle.getFile()
        console.log(file.size)
        const contents = await file.text()
        console.log(contents, contents.length)
        console.dir(contents)

        // const buffer = await file.arrayBuffer();
        // const bytes = new Uint8Array(buffer);
        // console.log(bytes);

        // const decoder = new TextDecoder('utf-8', { fatal: false });
        // const text = decoder.decode(buffer);
        // console.log(text);

        // const raw = new Uint8Array(buffer);
        // const text = Array.from(raw).map(b => String.fromCharCode(b)).join('');
        // console.log(text, text.length);
    })
}

function test1() {
    const button = createButton()
    button.addEventListener('click', async () => {
        try {
            const [fileHandle] = await window.showOpenFilePicker({
                types: [{
                    description: 'Text Files',
                    accept: { 'text/plain': ['.txt'] }
                }]
            })

            const file = await fileHandle.getFile()
            const contents = await file.text()
            console.log(contents)
        } catch (err) {
            if (err.name === 'AbortError') {
                console.log('File selection was canceled.')
            } else {
                console.error('Unexpected error:', err)
            }
        }
    })
}

test()
