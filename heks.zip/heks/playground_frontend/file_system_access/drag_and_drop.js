element.addEventListener('drop', async (event) => {
  const item = event.dataTransfer.items[0];
  if ('getAsFileSystemHandle' in item) {
    const handle = await item.getAsFileSystemHandle();
    if (handle.kind === 'file') {
      // handle is a FileSystemFileHandle
    }
  }
});