/*
    queryPermission vs requestPermission
*/

async function printPermssions(handle) {
    let currentPermission
    currentPermission = await handle.queryPermission({mode: 'read'})
    console.log(currentPermission)
    currentPermission = await handle.queryPermission({mode: 'readwrite'})
    console.log(currentPermission)
}

function wait(delay) {
    return new Promise((res) => {
        setTimeout(() => {
            res()
        }, delay)
    } )
}

function test1() {
    const button = createButton()
    button.addEventListener('click', async () => {
        try {
            // const handle = await window.showSaveFilePicker()

            // const [handle] = await window.showOpenFilePicker()

            let handle = await window.showDirectoryPicker()
            handle = await handle.getDirectoryHandle('dir1')
            handle = await handle.getFileHandle('file1.txt')

            await printPermssions(handle)
        } catch (err) {
            if (err.name === 'AbortError') {
                console.log('File selection was canceled.')
            } else {
                console.error('Unexpected error:', err)
            }
        }
    })
}

function test() {
    const button = createButton()
    button.addEventListener('click', async () => {
        try {
            const [handle] = await window.showOpenFilePicker()
            await printPermssions(handle)
            await wait(2000)
            await handle.requestPermission({mode: 'readwrite'})
            await printPermssions(handle)
            // await wait(2000)
            // await handle.requestPermission({mode: 'readwrite'})
            // await printPermssions(handle)
        } catch (err) {
            if (err.name === 'AbortError') {
                console.log('File selection was canceled.')
            } else {
                console.error('Unexpected error:', err)
            }
        }
    })
}

test()
