function test() {
    let val1
    let val2 = undefined
    let val3 = null
    let val4 = false
    console.log(`"${val1}" "${val2}" "${val3}" "${val4}"`)
}

test()