/*
    Multiple functions with the same name
*/

function test() {
    console.log(123)
}

console.log('mark1')
test() // 456, not 123

function test() {
    console.log(456)
}

console.log('mark2')
test() // 456
