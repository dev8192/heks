function test() {
    const buffer = new ArrayBuffer(20);
    const view = new Uint8Array(buffer);

    for (let i = 0; i < view.length; i++) {
        view[i] = i + 1;
    }

    const start = view.length - 5;
    const lastFive = view.slice(start, view.length) // create a copy
    // const lastFive = view.subarray(start, view.length) // do not create a copy

    for (let i = 0; i < 5; i++) {
        lastFive[i] += 100
    }

    console.log(lastFive);
    console.log(view);
}

test()
