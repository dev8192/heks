function test() {
    function printHello(param1, param2) {
        console.log(this)
        console.log(param1)
        console.log(param2)
    }
    printHello()
    // printHello.call(null, 'hello', 'there')
    // printHello.apply(null, ['hello', 'there'])

    // printHello.call(undefined, 'hello', 'there')
    // printHello.apply(undefined, ['hello', 'there'])

    printHello.call({num: 123}, 'hello', 'there')
    printHello.apply({num: 123}, ['hello', 'there'])
}

test()