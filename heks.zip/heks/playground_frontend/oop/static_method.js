class Example {
    static handlers = {
        one: Example.printOne,
        two: Example.printTwo,
    }
    constructor(type, val) {
        this.val = val
        if (Example.handlers[type]) {
            Example.handlers[type].call(this)
        }
    }
    static printOne() {
        console.log('one', this.val)
    }
    static printTwo() {
        console.log('two', this.val)
    }
}

const example1 = new Example('one', 1)
const example2 = new Example('two', 2)
const example3 = new Example('three', 3)
