setTimeout(function() {
    winnerIndex = 1
}, 50)