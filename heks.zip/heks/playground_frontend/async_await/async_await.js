
let users = [
    {
        name: 'Alice',
        balance: 0,
    },
    {
        name: 'Bob',
        balance: 0,
    },
]
let winnerIndex
function selectWinner(userName) {
    for (const user of users) {
        if (user.name === userName) {
            winnerIndex = 0
            break
        }
    }
}
function transferMoneyToWinner(amount) {
    return new Promise(function(res) {
        setTimeout(function() {
            users[winnerIndex].balance += amount
            res()
        }, 100)
    })
}
async function main() {
    selectWinner('Alice')
    await transferMoneyToWinner(5000)
    const winner = users[winnerIndex]
    console.log(`Congrats, ${winner.name}. Your balance is ${winner.balance}`)
}
main()
