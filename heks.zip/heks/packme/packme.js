const fs = require('fs')

class PackMe {
    constructor(opts) {
        this.srcDir = opts.srcDir
        this.fileNames = opts.fileNames
        this.outDir = opts.outDir
        this.separator = opts.separator
    }
    packSync() {
        try {
            let styleData = []
            let scriptData = []
            for (let i = 0; i < this.fileNames.length; i++) {
                const filePath = this.srcDir + this.fileNames[i]
                const arr = filePath.split('.')
                if (arr.length === 1) {
                    styleData.push(fs.readFileSync(filePath + '.css'))
                    scriptData.push(fs.readFileSync(filePath + '.js'))
                } else if (arr.length === 2) {
                    if (arr[1] === 'css') {
                        styleData.push(fs.readFileSync(filePath))
                    } else if (arr[1] === 'js') {
                        scriptData.push(fs.readFileSync(filePath))
                    }
                } else {
                    throw new Error('Illegal file name')
                }
            }
            fs.writeFileSync(this.outDir + 'style.css', styleData.join(this.separator))
            fs.writeFileSync(this.outDir + 'script.js', scriptData.join(this.separator))
        } catch (err) {
            // console.log(err)
            throw err
        }
    }
}

const app = new PackMe({
    srcDir: 'C:/heks/src/',
    fileNames: [
        'core/EventEmitter.js',
        'widget/Widget',
        'widget/Dialog',
        'core/AppSettings.js',
        'core/Buffer.js',
        'core/FileInfo.js',
        'core/KeyboardManager.js',
        'core/MovementManager.js',
        'core/PositionManager.js',
        'core/StyleManager.js',
        'core/TextModes',
        'core/WorkspaceManager.js',
        'backend/BaseBackend.js',
        'backend/FileSystemAccessBackend.js',
        'backend/LocalStorageBackend.js',
        'backend/IndexedDBBackend.js',
        'backend/InMemoryBackend.js',
        'editor/BitsWidget',
        'editor/EditorView',
        'editor/HexEditor.js',
        'tree_view/TreeViewBase',
        'tree_view/TreeViewFlat',
        'tree_view/TreeViewNested',
        'widget/WorkspaceDialog',
        'widget/WorkspaceInfo',
        'view/View',
        'view/SimpleView',
        'view/ColorPicker',
        'view/FileExplorer',
        'view/MainView',
        'view/NewFileDialog.js',
        'view/WorkspaceView',
        'widget/SettingItem.js',
        'view/SettingsView',
        'view/StartDialog',
        'widget/AddCellButton',
        'widget/BufSizeWidget.js',
        'widget/ButtonGroup',
        'widget/Breadcrumbs',
        'widget/CellEditor.js',
        'widget/CheckboxGroup.js',
        'widget/DetailsPane',
        'widget/MessageWidget.js',
        'widget/OffsetWidget',
        'widget/SaveFileDialog.js',
        'widget/TableWidget',
        'widget/TabsWidget',
        'widget/Text.js',
        'widget/TextGrid.js',
        'widget/TextInput',
        'widget/VisualWindow',
        'wasm/opcodes.js',
        'wasm/OpcodesWidget',
        'wasm/TypeList',
        'wasm/TypeEditor',
        'wasm/FunctionList',
        'wasm/FunctionEditor',
        'wasm/CodeEditor',
        'wasm/WasmView',
        'wasm/WasmBuilder',
        'wasm/WasmProgram.js',
        'wasm/WasmViewer',
        'wasm/WasmRunner',
        'wasm/WasmParser.js',
        'core/Heks.js',
        'style.css',
        'util.js',
        'main/nodejs_backend_main.js',
        // 'main/wasm/parse.js',
    ],
    outDir: 'C:/heks/out/',
    separator: '\n',
})
app.packSync()
console.log('done packing')

