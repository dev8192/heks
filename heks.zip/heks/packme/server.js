const http = require('http')
const fs = require('fs')
const path = require('path')
const { fork } = require('child_process')

const outDir = 'C:/heks/out'
const packmeDir = 'C:/heks/packme/'

const contentTypes = {
    'html': 'text/html',
    'css': 'text/css',
    'js': 'application/javascript',
}
function sendFile(req, res, fileName) {
    if (fileName === undefined) {
        fileName = req.url
    }
    const filePath = path.join(outDir, fileName)
    fs.readFile(filePath, (err, data) => {
        if (err) throw err
        const fileExtension = fileName.split('.')[1]
        res.writeHead(200, { 'Content-Type': contentTypes[fileExtension] })
        res.end(data)
    })
}

function onError(res) {
    res.writeHead(200, { 'Content-Type': 'text/html' })
    res.end('<h1>Something went wrong. Check the terminal for details</h1>')
}

const server = http.createServer((req, res) => {
    if (req.url === '/') {
        const filePath = path.join(packmeDir, 'packme.js')
        const child = fork(filePath)
        child.on('close', (code) => {
            if (code === 0) {
                sendFile(req, res, 'index.html')
            } else {
                onError(res)
            }
        })
        child.on('error', () => {
            onError(res)
        })
    } else if (req.url === '/style.css') {
        sendFile(req, res)
    } else if (req.url === '/script.js') {
        sendFile(req, res)
    } else {
        res.writeHead(200, { 'Content-Type': 'text/html' })
        res.end('<h1>404 Not Found</h1>')
    }
})
server.listen(8000)
